// Bullet and projectile mechanics for player and enemies
export class Bullet {
  constructor({
    x,
    y,
    vx,
    vy,
    damage = 20,
    radius = 5,
    isPlayer = true,
    color = '#ffcc00',
    type = 'normal',
    lifetime = 3.0,
    bounces = 0,
    pierce = 1,
    homing = false,
    target = null
  }) {
    this.x = x;
    this.y = y;
    this.vx = vx;
    this.vy = vy;
    this.damage = damage;
    this.radius = radius;
    this.isPlayer = isPlayer;
    this.color = color;
    this.type = type;
    this.lifetime = lifetime;
    this.remainingLifetime = lifetime;
    this.bounces = bounces;
    this.pierce = pierce;
    this.homing = homing;
    this.target = target;
    this.markedForDeletion = false;

    // Trail history for motion blur / laser lines
    this.trail = [];
    this.maxTrail = 4;
  }

  update(dt, particles) {
    this.remainingLifetime -= dt;
    if (this.remainingLifetime <= 0) {
      this.markedForDeletion = true;
      return;
    }

    // Save trail point
    this.trail.unshift({ x: this.x, y: this.y });
    if (this.trail.length > this.maxTrail) {
      this.trail.pop();
    }

    // Homing behavior
    if (this.homing && this.target && !this.target.isDead) {
      const angleToTarget = Math.atan2(this.target.y - this.y, this.target.x - this.x);
      const currentAngle = Math.atan2(this.vy, this.vx);
      const speed = Math.hypot(this.vx, this.vy);

      // Smooth turn toward target (safe angle normalization without while loops)
      let diff = angleToTarget - currentAngle;
      diff = Math.atan2(Math.sin(diff), Math.cos(diff));

      const newAngle = currentAngle + Math.sign(diff) * Math.min(Math.abs(diff), 4.5 * dt);
      this.vx = Math.cos(newAngle) * speed;
      this.vy = Math.sin(newAngle) * speed;
    }

    // Move
    this.x += this.vx * dt;
    this.y += this.vy * dt;

    // Rocket smoke particles
    if (this.type === 'rocket' && particles && Math.random() < 0.6) {
      particles.createSmoke(this.x, this.y, 4, '#888888');
    }

    // Flame particles
    if (this.type === 'flame' && particles && Math.random() < 0.7) {
      particles.createFireSpark(this.x, this.y, this.radius * 0.7);
    }
  }

  render(ctx) {
    ctx.save();

    // Render trail (not needed for full-screen katana slash)
    if (this.trail.length > 1 && this.type !== 'katana_slash') {
      ctx.beginPath();
      ctx.moveTo(this.trail[0].x, this.trail[0].y);
      for (let i = 1; i < this.trail.length; i++) {
        ctx.lineTo(this.trail[i].x, this.trail[i].y);
      }
      ctx.strokeStyle = this.color;
      ctx.globalAlpha = 0.4;
      ctx.lineWidth = this.radius * 1.5;
      ctx.stroke();
      ctx.globalAlpha = 1.0;
    }

    // Main Bullet Body
    ctx.shadowBlur = 10;
    ctx.shadowColor = this.color;

    if (this.type === 'katana_slash') {
      // Sweeping energetic crescent blade slice
      const angle = Math.atan2(this.vy, this.vx);
      const lifeRatio = Math.max(0, this.remainingLifetime / this.lifetime);
      ctx.translate(this.x, this.y);
      ctx.rotate(angle);

      ctx.globalAlpha = Math.min(1.0, lifeRatio * 1.4);

      // Outer energy arc
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 6;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.arc(0, 0, this.radius, -Math.PI * 0.45, Math.PI * 0.45, false);
      ctx.stroke();

      // Sharp glowing white inner blade
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(-2, 0, this.radius - 2, -Math.PI * 0.4, Math.PI * 0.4, false);
      ctx.stroke();

      // Energy wave fill
      ctx.fillStyle = 'rgba(56, 189, 248, 0.25)';
      ctx.beginPath();
      ctx.arc(0, 0, this.radius, -Math.PI * 0.45, Math.PI * 0.45, false);
      ctx.quadraticCurveTo(this.radius * 0.3, 0, 0, 0);
      ctx.fill();
    } else if (this.type === 'laser') {
      // Piercing continuous photon beam
      const angle = Math.atan2(this.vy, this.vx);
      ctx.translate(this.x, this.y);
      ctx.rotate(angle);

      // Outer laser glow
      ctx.fillStyle = '#00ffff';
      ctx.fillRect(-22, -4, 44, 8);

      // Supercharged white laser core
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(-26, -1.8, 52, 3.6);
    } else if (this.type === 'flame') {
      // Fiery expanding flame burst
      const progress = 1 - (this.remainingLifetime / this.lifetime);
      const curRadius = this.radius * (0.8 + progress * 0.7);
      ctx.globalAlpha = Math.max(0.2, 1 - progress * 0.75);

      // Outer red-orange fireball
      ctx.beginPath();
      ctx.arc(this.x, this.y, curRadius, 0, Math.PI * 2);
      ctx.fillStyle = progress > 0.4 ? '#ef4444' : '#f97316';
      ctx.fill();

      // Inner white-hot yellow core
      ctx.beginPath();
      ctx.arc(this.x, this.y, curRadius * 0.55, 0, Math.PI * 2);
      ctx.fillStyle = '#fef08a';
      ctx.fill();
    } else if (this.type === 'sniper') {
      // Piercing beam projectile
      const angle = Math.atan2(this.vy, this.vx);
      ctx.translate(this.x, this.y);
      ctx.rotate(angle);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(-16, -2, 32, 4);
      ctx.fillStyle = this.color;
      ctx.fillRect(-12, -4, 24, 8);
    } else if (this.type === 'rocket' || this.type === 'enemy_rocket') {
      // Missile shape
      const angle = Math.atan2(this.vy, this.vx);
      ctx.translate(this.x, this.y);
      ctx.rotate(angle);
      ctx.fillStyle = this.color;
      ctx.beginPath();
      ctx.moveTo(12, 0);
      ctx.lineTo(-10, -6);
      ctx.lineTo(-6, 0);
      ctx.lineTo(-10, 6);
      ctx.closePath();
      ctx.fill();
    } else {
      // Glowing orb bullet (classic Gungeon bullet hell look)
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
      ctx.fillStyle = this.color;
      ctx.fill();

      // Bright white inner core
      ctx.beginPath();
      ctx.arc(this.x, this.y, Math.max(1.5, this.radius * 0.45), 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
    }

    ctx.restore();
  }
}
