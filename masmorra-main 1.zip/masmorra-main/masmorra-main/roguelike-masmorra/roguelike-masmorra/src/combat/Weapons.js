import { Bullet } from './Bullet.js';

export const WeaponTypes = {
  PISTOL: {
    id: 'pistol',
    name: 'Pistola de Serviço',
    emoji: '🔫',
    damage: 18,
    bulletSpeed: 620,
    fireRate: 0.22, // Seconds between shots
    clipSize: 10,
    maxAmmo: Infinity,
    isStarter: true,
    reloadTime: 1.1,
    spread: 0.04,
    pellets: 1,
    bulletType: 'normal',
    bulletColor: '#ffdd33',
    bulletRadius: 5,
    sound: 'pistol',
    screenShake: 0.12
  },
  SHOTGUN: {
    id: 'shotgun',
    name: 'Espingarda Caçadeira',
    emoji: '💥',
    damage: 14, // per pellet * 6 = 84 total max
    bulletSpeed: 520,
    fireRate: 0.65,
    clipSize: 6,
    maxAmmo: 60,
    reloadTime: 1.8,
    spread: 0.24,
    pellets: 6,
    bulletType: 'pellet',
    bulletColor: '#ffaa22',
    bulletRadius: 4,
    sound: 'shotgun',
    screenShake: 0.35
  },
  AK47: {
    id: 'ak47',
    name: 'Fuzil AK-Myth',
    emoji: '⚡',
    damage: 16,
    bulletSpeed: 700,
    fireRate: 0.11,
    clipSize: 30,
    maxAmmo: 180,
    reloadTime: 1.4,
    spread: 0.08,
    pellets: 1,
    bulletType: 'normal',
    bulletColor: '#ffe066',
    bulletRadius: 4.5,
    sound: 'rifle',
    screenShake: 0.14
  },
  SNIPER: {
    id: 'sniper',
    name: 'Rifle Sniper M99',
    emoji: '🎯',
    damage: 90,
    bulletSpeed: 1200,
    fireRate: 0.95,
    clipSize: 4,
    maxAmmo: 32,
    reloadTime: 2.0,
    spread: 0.005,
    pellets: 1,
    bulletType: 'sniper',
    bulletColor: '#00ffff',
    bulletRadius: 6,
    sound: 'sniper',
    screenShake: 0.45,
    pierce: 3
  },
  RPG: {
    id: 'rpg',
    name: 'Lança-Foguetes Hades',
    emoji: '🚀',
    damage: 150,
    bulletSpeed: 420,
    fireRate: 1.1,
    clipSize: 1,
    maxAmmo: 14,
    reloadTime: 2.2,
    spread: 0.02,
    pellets: 1,
    bulletType: 'rocket',
    bulletColor: '#ff3300',
    bulletRadius: 8,
    sound: 'rocket',
    screenShake: 0.65
  },
  PLASMA: {
    id: 'plasma',
    name: 'Canhão de Plasma',
    emoji: '🔮',
    damage: 30,
    bulletSpeed: 560,
    fireRate: 0.24,
    clipSize: 14,
    maxAmmo: 84,
    reloadTime: 1.5,
    spread: 0.04,
    pellets: 1,
    bulletType: 'plasma',
    bulletColor: '#33ffdd',
    bulletRadius: 7,
    sound: 'plasma',
    screenShake: 0.18,
    bounces: 2
  },
  KATANA: {
    id: 'katana',
    name: 'Katana Espectral',
    emoji: '⚔️',
    damage: 60,
    bulletSpeed: 420,
    fireRate: 0.28,
    clipSize: 16,
    maxAmmo: Infinity, // Armas brancas místicas possuem essência infinita com recarga rítmica
    isMelee: true,
    reloadTime: 0.7,
    spread: 0.35,
    pellets: 1,
    bulletType: 'katana_slash',
    bulletColor: '#38bdf8',
    bulletRadius: 36, // Hitbox em arco cortante em área
    sound: 'katana',
    screenShake: 0.25,
    pierce: 999, // Atravessa e corta tudo em área
    lifetime: 0.22
  },
  LASER: {
    id: 'laser',
    name: 'Canhão de Fótons (Laser)',
    emoji: '💠',
    damage: 22,
    bulletSpeed: 1400,
    fireRate: 0.08,
    clipSize: 40,
    maxAmmo: 240,
    reloadTime: 1.2,
    spread: 0.015,
    pellets: 1,
    bulletType: 'laser',
    bulletColor: '#00ffff',
    bulletRadius: 5,
    sound: 'laser',
    screenShake: 0.08,
    pierce: 4
  },
  MINIGUN: {
    id: 'minigun',
    name: 'Gatling Vulcano (Minigun)',
    emoji: '🌪️',
    damage: 13,
    bulletSpeed: 820,
    fireRate: 0.06, // 16.6 disparos/segundo
    clipSize: 90,
    maxAmmo: 360,
    reloadTime: 2.2,
    spread: 0.15,
    pellets: 1,
    bulletType: 'normal',
    bulletColor: '#ff9900',
    bulletRadius: 4.5,
    sound: 'minigun',
    screenShake: 0.12
  },
  FLAMETHROWER: {
    id: 'flamethrower',
    name: 'Lança-Chamas do Tártaro',
    emoji: '🔥',
    damage: 12,
    bulletSpeed: 420,
    fireRate: 0.05,
    clipSize: 75,
    maxAmmo: 300,
    reloadTime: 1.8,
    spread: 0.32,
    pellets: 2,
    bulletType: 'flame',
    bulletColor: '#ff4400',
    bulletRadius: 16, // Projétil de fogo em cone com dano em área
    sound: 'flame',
    screenShake: 0.05,
    pierce: 999,
    lifetime: 0.36
  }
};

export class Weapon {
  constructor(def) {
    this.def = def;
    this.id = def.id;
    this.name = def.name;
    this.emoji = def.emoji;

    this.currentClip = def.clipSize;
    this.reserveAmmo = def.maxAmmo;
    this.isReloading = false;
    this.reloadTimer = 0;
    this.fireTimer = 0;
    this.kickback = 0;
  }

  update(dt, audio) {
    if (this.fireTimer > 0) {
      this.fireTimer -= dt;
    }

    if (this.kickback > 0) {
      this.kickback = Math.max(0, this.kickback - dt * 25);
    }

    if (this.isReloading) {
      this.reloadTimer += dt;
      if (this.reloadTimer >= this.def.reloadTime) {
        this.finishReload();
      }
    }
  }

  startReload(audio) {
    if (this.isReloading) return;
    if (this.currentClip >= this.def.clipSize) return; // Full clip
    if (this.reserveAmmo <= 0 && this.def.maxAmmo !== Infinity) return; // No ammo left

    this.isReloading = true;
    this.reloadTimer = 0;
    if (audio) audio.playReload();
  }

  finishReload() {
    this.isReloading = false;
    this.reloadTimer = 0;

    const needed = this.def.clipSize - this.currentClip;
    if (this.def.maxAmmo === Infinity) {
      this.currentClip = this.def.clipSize;
    } else {
      const reloadAmount = Math.min(needed, this.reserveAmmo);
      this.currentClip += reloadAmount;
      this.reserveAmmo -= reloadAmount;
    }
  }

  canShoot() {
    return !this.isReloading && this.fireTimer <= 0 && this.currentClip > 0;
  }

  shoot(originX, originY, targetX, targetY, audio, camera) {
    if (!this.canShoot()) {
      if (this.currentClip === 0 && !this.isReloading) {
        if (this.reserveAmmo <= 0 && this.def.maxAmmo !== Infinity) {
          // Out of ammo: Play dry-fire click sound (Enter the Gungeon empty gun cue)
          if (this.fireTimer <= 0) {
            this.fireTimer = 0.28;
            if (audio) audio.playEmptyClick();
          }
        } else {
          this.startReload(audio);
        }
      }
      return [];
    }

    this.fireTimer = this.def.fireRate;
    this.currentClip--;
    this.kickback = 8; // Visual kickback recoil

    if (audio) audio.playShoot(this.def.sound);
    if (camera) camera.addTrauma(this.def.screenShake);

    const baseAngle = Math.atan2(targetY - originY, targetX - originX);
    const bullets = [];

    for (let i = 0; i < this.def.pellets; i++) {
      // Calculate spread angle
      const spreadAngle = (Math.random() - 0.5) * this.def.spread * Math.PI;
      const angle = baseAngle + spreadAngle;

      const speed = this.def.bulletSpeed * (0.95 + Math.random() * 0.1);
      const vx = Math.cos(angle) * speed;
      const vy = Math.sin(angle) * speed;

      bullets.push(new Bullet({
        x: originX + Math.cos(angle) * 16,
        y: originY + Math.sin(angle) * 16,
        vx,
        vy,
        damage: this.def.damage,
        radius: this.def.bulletRadius,
        isPlayer: true,
        color: this.def.bulletColor,
        type: this.def.bulletType,
        bounces: this.def.bounces || 0,
        pierce: this.def.pierce || 1,
        lifetime: this.def.lifetime || 3.0
      }));
    }

    // Auto-reload if clip emptied
    if (this.currentClip === 0) {
      this.startReload(audio);
    }

    return bullets;
  }

  getReloadProgress() {
    if (!this.isReloading) return 0;
    return Math.min(1.0, this.reloadTimer / this.def.reloadTime);
  }
}
