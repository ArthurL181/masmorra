import { audio } from './core/Audio.js';
import { input } from './core/Input.js';
import { Camera } from './core/Camera.js';
import { DungeonGenerator } from './dungeon/DungeonGenerator.js';
import { DungeonRenderer } from './dungeon/TileMap.js';
import { RoomType, Portal } from './dungeon/Room.js';
import { Player } from './entities/Player.js';
import { spawnEnemiesForFloor } from './entities/Enemy.js';
import { Boss } from './entities/Bosses.js';
import { ParticleSystem } from './effects/ParticleSystem.js';
import { CanvasUI } from './ui/CanvasUI.js';
import { WeaponTypes } from './combat/Weapons.js';
import { Pickup, PickupType } from './dungeon/Pickup.js';
import { gameState, SKIN_CATALOG, SHOP_ATTRIBUTES } from './core/GameState.js';

// Floor Names and Lore Data
const FLOOR_INFO = {
  1: {
    name: 'As Catacumbas de Creta',
    bossName: 'Minotauro de Creta',
    bossTitle: 'O Guardião do Labirinto',
    enemiesDesc: ['Pistoleiro (Pistol Kin) - Disparos pontuais']
  },
  2: {
    name: 'As Tumbas de Anúbis',
    bossName: 'Anúbis',
    bossTitle: 'O Juiz das Almas',
    enemiesDesc: [
      'Pistoleiro (Pistol Kin)',
      'Atirador de Metralhadora (SMG Kin) - Rajadas rápidas',
      'Franco-Atirador (Sniper Deadeye) - Mira laser telegrafada'
    ]
  },
  3: {
    name: 'A Fortaleza de Fenrir',
    bossName: 'Fenrir',
    bossTitle: 'O Devorador de Deuses',
    enemiesDesc: [
      'Pistoleiro, Metralhadora & Sniper',
      'Bombardeiro de Bazuca (Rocket Kin) - Mísseis que explodem em estilhaços'
    ]
  },
  4: {
    name: 'O Sanctum de Hades',
    bossName: 'Hades',
    bossTitle: 'O Lorde do Submundo',
    enemiesDesc: [
      'Todas as tropas anteriores',
      'Bruto de Gatling (Heavy Behemoth) - Chuva contínua de balas'
    ]
  },
  5: {
    name: 'O Covil Ancestral de Fáfnir',
    bossName: 'Fáfnir, o Dragão Ancião',
    bossTitle: 'Senhor do Ouro e do Caos',
    enemiesDesc: [
      'Tropas de Elite combinadas em força total',
      'O Dragão Ancião cospe labaredas e anéis de fogo'
    ]
  },
  6: {
    name: 'O Cume Tempestuoso do Olimpo',
    bossName: 'Zeus, o Soberano dos Raios',
    bossTitle: 'O Rei do Monte Olimpo',
    enemiesDesc: [
      'Mago Arcano (Mage Kin) - Disparos arcanos teleguiados e teleporte',
      'Granadeiro (Bomber Kin) - Corrida kamikaze com explosão de estilhaços',
      'Escudeiro de Falange (Shield Kin) - Escudo frontal blindado'
    ]
  },
  7: {
    name: 'O Vazio Cósmico de Cronos',
    bossName: 'Cronos, o Titã do Tempo e Caos',
    bossTitle: 'O Devorador de Éons',
    enemiesDesc: [
      'Cuspidor Ácido (Slime Kin) - Dispara lodo cáustico no solo',
      'Tropas Primordiais combinadas em força absoluta',
      'O TITÃ SUPREMO DO TEMPO AGUARDA NO VÁCUO FINAL!'
    ]
  }
};

class Game {
  constructor() {
    this.canvas = document.getElementById('game-canvas');
    this.ctx = this.canvas.getContext('2d');

    this.ui = new CanvasUI();
    this.dungeonRenderer = new DungeonRenderer();
    this.dungeonGen = new DungeonGenerator();
    this.particles = new ParticleSystem();

    this.camera = null;
    this.player = null;
    this.dungeon = null;
    this.currentRoom = null;
    this.activeBoss = null;

    this.bullets = [];
    this.currentFloor = 1;
    this.maxFloors = 7;

    // Statistics
    this.totalKills = 0;
    this.totalDamageDealt = 0;
    this.startTime = 0;

    // FPS tracking
    this.fps = 0;
    this.fpsTimer = 0;
    this.fpsFrameCount = 0;

    // Volume slider drag state
    this._volSliderDragging = false;

    // Game States: 'MAIN_MENU', 'PLAYING', 'FLOOR_TRANSITION', 'GAMEOVER', 'VICTORY',
    //              'INVENTORY', 'SHOP', 'OPTIONS'
    this.state = 'MAIN_MENU';
    this.interactionPrompt = null;

    this.lastTime = 0;
  }

  init() {
    this.resizeCanvas();
    window.addEventListener('resize', () => this.resizeCanvas());

    this.camera = new Camera(this.canvas.width, this.canvas.height);
    input.init(this.canvas);

    // Apply saved volume & mute settings
    audio.init(gameState.volume);
    audio.setMuted(gameState.isMuted);

    // Canvas click & drag events for UI buttons & slider
    window.addEventListener('mousedown', (e) => {
      audio.ensureContext();
      if (this.state === 'OPTIONS') {
        const btn = this.ui.buttons.find(b => b.id === 'vol-slider');
        if (btn && e.clientX >= btn.x && e.clientX <= btn.x + btn.width &&
            e.clientY >= btn.y && e.clientY <= btn.y + btn.height) {
          this._volSliderDragging = true;
          btn.onClick({ _rawX: e.clientX, _rawY: e.clientY });
        }
      }
    });

    window.addEventListener('mousemove', (e) => {
      if (this._volSliderDragging && this.state === 'OPTIONS') {
        const btn = this.ui.buttons.find(b => b.id === 'vol-slider');
        if (btn) {
          btn.onClick({ _rawX: e.clientX, _rawY: e.clientY });
        }
      }
    });

    window.addEventListener('mouseup', () => {
      this._volSliderDragging = false;
    });

    window.addEventListener('click', (e) => {
      audio.ensureContext();
      // Pass raw X for volume slider
      const syntheticE = { _rawX: e.clientX, _rawY: e.clientY };
      // Try slider buttons with raw coords
      for (const btn of this.ui.buttons) {
        if (btn.id === 'vol-slider') {
          if (e.clientX >= btn.x && e.clientX <= btn.x + btn.width &&
              e.clientY >= btn.y && e.clientY <= btn.y + btn.height) {
            btn.onClick(syntheticE);
            return;
          }
        }
      }
      this.ui.handleClick(e.clientX, e.clientY, audio);
    });

    this.lastTime = performance.now();
    requestAnimationFrame((t) => this.loop(t));
  }

  resizeCanvas() {
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
    if (this.camera) {
      this.camera.resize(this.canvas.width, this.canvas.height);
    }
  }

  startRun() {
    this.currentFloor = 1;
    this.totalKills = 0;
    this.totalDamageDealt = 0;
    this.startTime = Date.now();
    this.hasHandledDeath = false;

    // Reset player so loadFloor creates a fresh one with current GameState bonuses
    this.player = null;

    this.loadFloor(1);
    this.state = 'FLOOR_TRANSITION';
    audio.playBossRoar();
  }

  loadFloor(floorNumber) {
    this.currentFloor = floorNumber;
    this.bullets = [];
    this.activeBoss = null;
    this.bossDefeated = false;

    // Procedural dungeon generation
    this.dungeon = this.dungeonGen.generate(floorNumber);
    const startRoom = this.dungeon.startRoom;

    // Spawn player in center of start room
    const playerX = startRoom.x + startRoom.width / 2;
    const playerY = startRoom.y + startRoom.height / 2;

    if (!this.player) {
      // First floor: create player with GameState bonuses and chosen skin
      const bonuses = gameState.getPlayerBonuses();
      const skinData = gameState.getActiveSkinData();
      this.player = new Player(playerX, playerY, {
        extraHealth: bonuses.extraHealth,
        extraBlanks: bonuses.extraBlanks,
        extraSpeed: bonuses.extraSpeed,
        startKatana: bonuses.startKatana,
        startLaser: bonuses.startLaser,
        startMinigun: bonuses.startMinigun,
        startFlamethrower: bonuses.startFlamethrower,
        startShotgun: bonuses.startShotgun,
        startAK47: bonuses.startAK47,
        startSniper: bonuses.startSniper,
        skinData: {
          bodyColor: skinData.bodyColor,
          capeColor: skinData.capeColor,
          helmetColor: skinData.helmetColor
        }
      });
    } else {
      // Retain weapons, refill blanks to 2 if depleted, restore 2 HP
      this.player.x = playerX;
      this.player.y = playerY;
      this.player.vx = 0;
      this.player.vy = 0;
      this.player.blanks = Math.max(2, this.player.blanks);
      this.player.health = Math.min(this.player.maxHealth, this.player.health + 2);
    }

    this.currentRoom = startRoom;
    this.currentRoom.visited = true;

    // Prepare weapon drop for chest room
    if (this.dungeon.chestRoom && this.dungeon.chestRoom.chest) {
      const chest = this.dungeon.chestRoom.chest;
      const weaponPool = [
        WeaponTypes.SHOTGUN,
        WeaponTypes.AK47,
        WeaponTypes.SNIPER,
        WeaponTypes.RPG,
        WeaponTypes.PLASMA,
        WeaponTypes.KATANA,
        WeaponTypes.LASER,
        WeaponTypes.MINIGUN,
        WeaponTypes.FLAMETHROWER
      ];
      const unowned = weaponPool.filter(w => !this.player.weapons.some(pw => pw.id === w.id));
      chest.weaponDrop = unowned.length > 0
        ? unowned[Math.floor(Math.random() * unowned.length)]
        : weaponPool[Math.floor(Math.random() * weaponPool.length)];
    }
  }

  loop(currentTime) {
    const dt = Math.min(0.1, (currentTime - this.lastTime) / 1000);
    this.lastTime = currentTime;

    // FPS counter
    this.fpsFrameCount++;
    this.fpsTimer += dt;
    if (this.fpsTimer >= 1.0) {
      this.fps = this.fpsFrameCount;
      this.fpsFrameCount = 0;
      this.fpsTimer = 0;
    }

    try {
      // Update UI button hover states
      this.ui.handleMouseMove(input.mouse.screenX, input.mouse.screenY);
      this.ui.updateToast(dt);

      if (this.state === 'PLAYING') {
        this.update(dt);
      }

      this.render(dt);
    } catch (err) {
      console.error('Game loop error:', err);
    } finally {
      input.resetFrameTriggers();
      requestAnimationFrame((t) => this.loop(t));
    }
  }

  update(dt) {
    // 1. Camera & Mouse Coordinates
    this.camera.update(this.player, input.mouse.screenX, input.mouse.screenY, dt);
    input.updateWorldMouse(this.camera);

    // 2. Systems
    this.dungeonRenderer.update(dt);
    this.particles.update(dt);

    // 3. Player
    this.player.update(dt, input, audio, this.particles, this.camera);
    this.player.resolveEnvironmentCollisions(this.currentRoom, this.dungeon.rooms);

    // Enter the Gungeon Weapon Dropping (Key 'G')
    if (this.player.droppedWeaponEvent) {
      const droppedW = this.player.droppedWeaponEvent;
      const dropP = new Pickup(this.player.x, this.player.y, PickupType.WEAPON, droppedW);
      dropP.vx = Math.cos(this.player.aimAngle) * 140;
      dropP.vy = Math.sin(this.player.aimAngle) * 140;
      if (this.currentRoom) {
        if (!this.currentRoom.pickups) this.currentRoom.pickups = [];
        this.currentRoom.pickups.push(dropP);
      }
      this.ui.showToast(`Arma dropada: ${droppedW.name}!`);
    }

    // 4. Room Tracking
    this.updateRoomTracking();

    // 5. Shooting
    if (input.mouse.leftDown && !this.player.isRolling && !this.player.isDying && !this.player.isDead) {
      const newBullets = this.player.activeWeapon.shoot(
        this.player.x,
        this.player.y,
        input.mouse.worldX,
        input.mouse.worldY,
        audio,
        this.camera
      );

      if (newBullets.length > 0) {
        this.bullets.push(...newBullets);
        this.particles.createMuzzleFlash(this.player.x, this.player.y, this.player.aimAngle);
        this.particles.createShell(this.player.x, this.player.y, this.player.aimAngle);
      }
    }

    // 6. Blank (Q / Middle click)
    if (input.mouse.justBlankDown && !this.player.isDying && !this.player.isDead) {
      const roomEnemies = this.currentRoom ? [...this.currentRoom.enemies] : [];
      if (this.activeBoss && !this.activeBoss.isDead) roomEnemies.push(this.activeBoss);
      this.player.triggerBlank(audio, this.particles, this.camera, this.bullets, roomEnemies);
    }

    // 7. Enemies in Room
    if (this.currentRoom && this.currentRoom.enemies.length > 0) {
      // Physical separation: prevent enemies from stacking on each other or on player
      for (let i = 0; i < this.currentRoom.enemies.length; i++) {
        const e1 = this.currentRoom.enemies[i];
        for (let j = i + 1; j < this.currentRoom.enemies.length; j++) {
          e1.resolveSeparation(this.currentRoom.enemies[j], 6);
        }
        e1.resolveSeparation(this.player, 8);
      }

      for (let i = this.currentRoom.enemies.length - 1; i >= 0; i--) {
        const enemy = this.currentRoom.enemies[i];
        // Pass currentRoom for pillar avoidance and smart steering!
        enemy.update(dt, this.player, this.bullets, audio, this.particles, this.currentRoom);
        enemy.resolveEnvironmentCollisions(this.currentRoom, this.dungeon.rooms);

        if (enemy.isDead) {
          this.totalKills++;
          this.particles.createBlood(enemy.x, enemy.y, 16, '#ff3344');
          this.particles.createExplosion(enemy.x, enemy.y, 25);
          if (audio) audio.playHit();
          this.currentRoom.enemies.splice(i, 1);

          if (!this.currentRoom.pickups) this.currentRoom.pickups = [];

          // Balanced Enemy Loot Drops: halved ammo & health frequency
          const dropRoll = Math.random();
          if (dropRoll < 0.10) {
            // Ammo Box drop (halved from 0.20)
            this.currentRoom.pickups.push(new Pickup(enemy.x, enemy.y, PickupType.AMMO));
          } else if (dropRoll < 0.16 && this.player.health < this.player.maxHealth) {
            // Heart recovery (halved from 0.12 chance to 0.06 chance)
            this.currentRoom.pickups.push(new Pickup(enemy.x, enemy.y, PickupType.HEALTH));
          } else if (dropRoll < 0.19) {
            // Blank drop (halved from 0.06 to 0.03 chance)
            this.currentRoom.pickups.push(new Pickup(enemy.x, enemy.y, PickupType.BLANK));
          } else if (dropRoll < 0.65) {
            // Gold coin casings
            this.currentRoom.pickups.push(new Pickup(enemy.x, enemy.y, PickupType.COIN, { amount: 2 + Math.floor(Math.random() * 3) }));
          }
        }
      }

      // Room Clear: unlocks doors & drops a room reward
      if (this.currentRoom.enemies.length === 0 && !this.currentRoom.cleared) {
        this.currentRoom.cleared = true;
        this.currentRoom.unlockDoors();
        this.ui.showToast('SALA LIMPA! RECOMPENSA DEPOSITADA!');
        audio.playVictory();

        if (!this.currentRoom.pickups) this.currentRoom.pickups = [];
        const cx = this.currentRoom.x + this.currentRoom.width / 2;
        const cy = this.currentRoom.y + this.currentRoom.height / 2;

        const clearRoll = Math.random();
        if (clearRoll < 0.22) {
          this.currentRoom.pickups.push(new Pickup(cx, cy, PickupType.AMMO));
        } else if (clearRoll < 0.37) {
          this.currentRoom.pickups.push(new Pickup(cx, cy, PickupType.HEALTH));
        } else if (clearRoll < 0.48) {
          this.currentRoom.pickups.push(new Pickup(cx, cy, PickupType.BLANK));
        } else {
          this.currentRoom.pickups.push(new Pickup(cx, cy, PickupType.COIN, { amount: 3 + Math.floor(Math.random() * 3) }));
        }
      }
    }

    // 7.2. Floor Pickups & Weapons in Room
    if (this.currentRoom && this.currentRoom.pickups) {
      for (let i = this.currentRoom.pickups.length - 1; i >= 0; i--) {
        const p = this.currentRoom.pickups[i];
        p.update(dt, this.player, audio, this.particles, this.ui, input);
        if (p.isCollected) {
          this.currentRoom.pickups.splice(i, 1);
        }
      }
    }

    // 7.5. Room Traps & Environmental Hazards
    if (this.currentRoom && this.currentRoom.traps) {
      for (const trap of this.currentRoom.traps) {
        trap.update(dt, this.player, this.particles, audio);

        // Player collision
        if (trap.isActiveHazardAt(this.player.x, this.player.y, this.player.radius)) {
          if (!this.player.isRolling && !this.player.isInvulnerable) {
            this.player.takeDamage(1);
            audio.playPlayerHurt();
            this.camera.addTrauma(0.45);
            this.particles.createBlood(this.player.x, this.player.y, 10);
          }
        }

        // Enemy collision with active traps
        if (this.currentRoom.enemies) {
          for (const enemy of this.currentRoom.enemies) {
            if (!enemy.isDead && trap.isActiveHazardAt(enemy.x, enemy.y, enemy.radius)) {
              enemy.takeDamage(14);
              this.particles.createBlood(enemy.x, enemy.y, 5, '#ff3344');
            }
          }
        }
      }
    }

    // 8. Boss
    if (this.activeBoss && !this.activeBoss.isDead) {
      this.activeBoss.update(dt, this.player, this.bullets, audio, this.particles, this.camera);
      this.activeBoss.resolveEnvironmentCollisions(this.currentRoom, this.dungeon.rooms);

      // PHYSICAL COLLISION: Boss CANNOT sit on top of the player!
      const bdx = this.player.x - this.activeBoss.x;
      const bdy = this.player.y - this.activeBoss.y;
      const bdist = Math.hypot(bdx, bdy);
      const minBossDist = this.player.radius + this.activeBoss.radius + 14;

      if (bdist < minBossDist && bdist > 0.001) {
        const overlap = minBossDist - bdist;
        const nx = bdx / bdist;
        const ny = bdy / bdist;

        // Push player away strongly from boss
        this.player.x += nx * overlap;
        this.player.y += ny * overlap;
        this.activeBoss.x -= nx * (overlap * 0.2);
        this.activeBoss.y -= ny * (overlap * 0.2);

        // Contact damage & knockback if player is not rolling and not invulnerable
        if (!this.player.isRolling && !this.player.isInvulnerable) {
          this.player.takeDamage(1);
          audio.playPlayerHurt();
          this.camera.addTrauma(0.45);
          this.particles.createBlood(this.player.x, this.player.y, 10);
          this.player.vx += nx * 380;
          this.player.vy += ny * 380;
        }
      }

      if (this.activeBoss.health <= 0) {
        this.handleBossDefeat();
      }
    }

    // 9. Chest, Portal & Elevator
    if (this.currentRoom) {
      if (this.currentRoom.chest) this.currentRoom.chest.update(dt);
      if (this.currentRoom.portal) this.currentRoom.portal.update(dt);
      if (this.currentRoom.elevator) this.currentRoom.elevator.update(dt);
    }

    // 10. Bullets & Collisions
    this.updateBullets(dt);

    // 11. Interactions
    this.updateInteractions();

    // 12. Player Death
    if (this.player.isDead) {
      if (!this.hasHandledDeath) {
        this.hasHandledDeath = true;
        if (this.player.coins > 0) {
          gameState.addCoins(this.player.coins);
        }
      }
      this.state = 'GAMEOVER';
      audio.playPlayerHurt();
    }
  }

  updateRoomTracking() {
    for (const room of this.dungeon.rooms) {
      if (room.contains(this.player.x, this.player.y)) {
        if (this.currentRoom !== room) {
          this.currentRoom = room;
          if (this.player) this.player._currentRoom = room;
          room.visited = true;

          if (!room.cleared) {
            room.lockDoors();

            if (room.type === RoomType.COMBAT) {
              room.enemies = spawnEnemiesForFloor(this.currentFloor, room);
            } else if (room.type === RoomType.BOSS) {
              if (!this.activeBoss) {
                this.activeBoss = new Boss(
                  room.x + room.width / 2,
                  room.y + room.height / 2,
                  this.currentFloor
                );
                audio.playBossRoar();
                this.camera.addTrauma(0.5);
              }
            }
          }
        }
        break;
      }
    }
  }

  updateBullets(dt) {
    const spawnedBullets = [];

    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      b.update(dt, this.particles);

      if (b.markedForDeletion) {
        if (b.onDetonate) b.onDetonate(spawnedBullets);
        this.bullets.splice(i, 1);
        continue;
      }

      // Pillar collision
      if (this.currentRoom && this.currentRoom.pillars) {
        let hitPillar = false;
        for (const p of this.currentRoom.pillars) {
          const dist = Math.hypot(b.x - p.x, b.y - p.y);
          if (dist < b.radius + p.radius) {
            hitPillar = true;
            break;
          }
        }

        if (hitPillar) {
          this.particles.createHitSparks(b.x, b.y, b.color);
          if (b.onDetonate) b.onDetonate(spawnedBullets);
          this.bullets.splice(i, 1);
          continue;
        }
      }

      // Wall collision
      if (this.currentRoom) {
        const minX = this.currentRoom.x;
        const maxX = this.currentRoom.x + this.currentRoom.width;
        const minY = this.currentRoom.y;
        const maxY = this.currentRoom.y + this.currentRoom.height;

        if (b.x < minX || b.x > maxX || b.y < minY || b.y > maxY) {
          if (b.bounces > 0) {
            b.bounces--;
            if (b.x < minX || b.x > maxX) b.vx = -b.vx;
            if (b.y < minY || b.y > maxY) b.vy = -b.vy;
            this.particles.createHitSparks(b.x, b.y, b.color);
          } else {
            this.particles.createHitSparks(b.x, b.y, b.color);
            if (b.onDetonate) b.onDetonate(spawnedBullets);
            this.bullets.splice(i, 1);
            continue;
          }
        }
      }

      // Katana Special Blade Strike: Cuts and deflects enemy bullets in its sweeping arc!
      if (b.isPlayer && b.type === 'katana_slash') {
        for (const enemyB of this.bullets) {
          if (!enemyB.isPlayer && !enemyB.markedForDeletion) {
            const cutDist = Math.hypot(b.x - enemyB.x, b.y - enemyB.y);
            if (cutDist < b.radius + enemyB.radius + 14) {
              enemyB.markedForDeletion = true;
              this.particles.createHitSparks(enemyB.x, enemyB.y, '#38bdf8');
              if (audio) audio.playHit();
            }
          }
        }
      }

      // Player bullets vs Enemies & Boss
      if (b.isPlayer) {
        let hitTarget = false;

        if (this.currentRoom && this.currentRoom.enemies) {
          for (const enemy of this.currentRoom.enemies) {
            if (enemy.isDead) continue;
            const dist = Math.hypot(b.x - enemy.x, b.y - enemy.y);
            if (dist < b.radius + enemy.radius) {
              const isCrit = Math.random() < 0.2;
              const actualDmg = isCrit ? Math.round(b.damage * 1.6) : b.damage;
              const knockback = b.damage * 8.5;
              const dealt = enemy.takeDamage(actualDmg, b.x, b.y, knockback);

              if (dealt > 0) {
                this.totalDamageDealt += dealt;
                this.particles.createBlood(b.x, b.y, 8);
                this.particles.createDamageText(b.x, b.y, dealt, isCrit);
                if (audio) audio.playHit();
              } else {
                // Shield blocked the shot!
                this.particles.createHitSparks(b.x, b.y, '#e2e8f0');
                if (audio) audio.playReload();
              }

              hitTarget = true;
              break;
            }
          }
        }

        if (!hitTarget && this.activeBoss && !this.activeBoss.isDead) {
          const dist = Math.hypot(b.x - this.activeBoss.x, b.y - this.activeBoss.y);
          if (dist < b.radius + this.activeBoss.radius) {
            const isCrit = Math.random() < 0.15;
            const actualDmg = isCrit ? Math.round(b.damage * 1.5) : b.damage;
            this.activeBoss.takeDamage(actualDmg);

            this.totalDamageDealt += actualDmg;
            this.particles.createHitSparks(b.x, b.y, '#ffaa00');
            this.particles.createDamageText(b.x, b.y, actualDmg, isCrit);
            if (audio) audio.playHit();

            if (this.activeBoss.health <= 0) {
              this.handleBossDefeat();
            }

            hitTarget = true;
          }
        }

        if (hitTarget) {
          b.pierce--;
          if (b.pierce <= 0) {
            if (b.onDetonate) b.onDetonate(spawnedBullets);
            this.bullets.splice(i, 1);
            continue;
          }
        }
      } else {
        // Enemy bullets vs Player
        const dist = Math.hypot(b.x - this.player.x, b.y - this.player.y);
        if (dist < b.radius + this.player.radius) {
          if (!this.player.isRolling && !this.player.isInvulnerable) {
            this.player.takeDamage(b.damage);
            audio.playPlayerHurt();
            this.camera.addTrauma(0.5);
            this.particles.createBlood(this.player.x, this.player.y, 14);

            this.bullets.splice(i, 1);
            continue;
          }
        }
      }
    }

    if (spawnedBullets.length > 0) {
      this.bullets.push(...spawnedBullets);
    }
  }

  handleBossDefeat() {
    if (this.bossDefeated) return;
    this.bossDefeated = true;
    if (this.activeBoss) this.activeBoss.isDead = true;
    this.totalKills++;

    const bX = this.activeBoss ? this.activeBoss.x : this.player.x;
    const bY = this.activeBoss ? this.activeBoss.y : this.player.y;

    this.particles.createExplosion(bX, bY, 160);
    this.particles.createShockwave(bX, bY, 600, '#ffd700', 900);
    audio.playVictory();

    const bName = this.activeBoss ? this.activeBoss.name.toUpperCase() : 'CHEFE';
    this.ui.showToast(`O ${bName} FOI DERROTADO!`, 3.0);

    // Reward loot: coins and full heart recovery
    this.player.coins += 40;
    this.player.health = Math.min(this.player.maxHealth, this.player.health + 2);

    // *** DROP RUNAS MÍTICAS (meta-currency) ***
    // Scale: 5 runas no floor 1, +5 por floor (5, 10, 15, 20, 25)
    const runesDrop = this.currentFloor * 5;
    gameState.addRunes(runesDrop);
    this.ui.showToast(`${bName} DERROTADO! +${runesDrop} 🔮 Runas!`, 3.5);

    // UNLOCK ALL DOORS in boss room AND unlock the BossExitGate leading into Elevator Room!
    if (this.currentRoom) {
      this.currentRoom.cleared = true;
      this.currentRoom.doors.forEach(d => d.isLocked = false);
    }
    if (this.dungeon && this.dungeon.bossRoom) {
      this.dungeon.bossRoom.cleared = true;
      this.dungeon.bossRoom.doors.forEach(d => d.isLocked = false);
    }

    // Reveal Elevator Room on minimap
    if (this.dungeon && this.dungeon.elevatorRoom) {
      this.dungeon.elevatorRoom.visited = true;
    }

    // Spawn an extra Backup Portal right on the floor too
    if (this.currentRoom) {
      this.currentRoom.portal = new Portal(bX, bY);
      this.currentRoom.portal.active = true;
    }

    setTimeout(() => {
      this.ui.showToast('PORTÃO DO ELEVADOR ABERTO! SIGA PARA A SALA DE SAÍDA!', 4.0);
    }, 1800);
  }

  updateInteractions() {
    this.interactionPrompt = null;

    // 0. Floor Weapon Pickups Interaction (Press [E] to pick up dropped gun)
    if (this.currentRoom && this.currentRoom.pickups) {
      for (const p of this.currentRoom.pickups) {
        if (!p.isCollected && p.type === PickupType.WEAPON) {
          const dist = Math.hypot(this.player.x - p.x, this.player.y - p.y);
          if (dist < 64) {
            const wName = (p.extraData && (p.extraData.name || (p.extraData.def && p.extraData.def.name))) || 'Arma';
            this.interactionPrompt = `Pressione [E] para Pegar ${wName}`;
            break;
          }
        }
      }
    }

    // 1. Chest Interaction
    if (this.currentRoom && this.currentRoom.chest && !this.currentRoom.chest.isOpen) {
      const chest = this.currentRoom.chest;
      const dist = Math.hypot(this.player.x - chest.x, this.player.y - chest.y);

      if (dist < 64) {
        this.interactionPrompt = 'Pressione [E] para Abrir Baú';

        if (input.mouse.justInteractDown) {
          chest.isOpen = true;
          audio.playChestOpen();
          this.particles.createExplosion(chest.x, chest.y, 35);

          if (chest.weaponDrop) {
            const res = this.player.equipWeapon(chest.weaponDrop);
            if (res.discarded) {
              if (!this.currentRoom.pickups) this.currentRoom.pickups = [];
              const dropP = new Pickup(chest.x + 36, chest.y + 10, PickupType.WEAPON, {
                def: res.discarded.def,
                name: res.discarded.name,
                emoji: res.discarded.emoji,
                currentClip: res.discarded.currentClip,
                reserveAmmo: res.discarded.reserveAmmo
              });
              dropP.pickupDelay = 0.5;
              this.currentRoom.pickups.push(dropP);
              this.ui.showToast(`SUBSTITUIU ${res.discarded.name.toUpperCase()} POR ${chest.weaponDrop.name.toUpperCase()}!`);
            } else if (res.isRefill) {
              this.ui.showToast(`MUNIÇÃO CHEIA: ${chest.weaponDrop.name.toUpperCase()}!`);
            } else {
              this.ui.showToast(`ARMA OBTIDA: ${chest.weaponDrop.name.toUpperCase()}!`);
            }
            // Chest bonus: drop an Ammo Box next to the chest too
            if (!this.currentRoom.pickups) this.currentRoom.pickups = [];
            this.currentRoom.pickups.push(new Pickup(chest.x - 28, chest.y + 10, PickupType.AMMO));
          }
        }
      }
    }

    // 2. Elevator Chamber Interaction (The dedicated Exit Chamber!)
    let elevatorObj = null;
    if (this.currentRoom && this.currentRoom.elevator) {
      elevatorObj = this.currentRoom.elevator;
    } else if (this.dungeon && this.dungeon.elevatorRoom && this.dungeon.elevatorRoom.elevator) {
      elevatorObj = this.dungeon.elevatorRoom.elevator;
    }

    if (elevatorObj && this.bossDefeated) {
      const dist = Math.hypot(this.player.x - elevatorObj.x, this.player.y - elevatorObj.y);
      const inElevatorRoom = (this.currentRoom && this.currentRoom.type === RoomType.ELEVATOR);

      if (dist < 110 || inElevatorRoom) {
        if (this.currentFloor === this.maxFloors) {
          this.interactionPrompt = 'Pressione [E] ou Pise no Elevador para a Vitória!';
        } else {
          this.interactionPrompt = `Pressione [E] ou Pise no Elevador para Descer ao Andar ${this.currentFloor + 1}`;
        }

        // Stepping onto elevator platform (dist < 65) OR pressing E triggers descent!
        if (input.mouse.justInteractDown || dist < 65) {
          if (this.currentFloor === this.maxFloors) {
            this.state = 'VICTORY';
            audio.playVictory();
          } else {
            audio.playChestOpen();
            this.nextFloor();
          }
        }
      }
    }

    // 3. Backup Portal Interaction
    if (this.currentRoom && this.currentRoom.portal && this.currentRoom.portal.active) {
      const portal = this.currentRoom.portal;
      const dist = Math.hypot(this.player.x - portal.x, this.player.y - portal.y);

      if (dist < 85) {
        if (this.currentFloor === this.maxFloors) {
          this.interactionPrompt = 'Pressione [E] ou Pise no Portal para a Vitória!';
        } else {
          this.interactionPrompt = `Pressione [E] ou Pise no Portal para Ir ao Andar ${this.currentFloor + 1}`;
        }

        if (input.mouse.justInteractDown || (dist < 46 && (portal.spawnTimer === undefined || portal.spawnTimer >= 1.2))) {
          if (this.currentFloor === this.maxFloors) {
            this.state = 'VICTORY';
            audio.playVictory();
          } else {
            this.nextFloor();
          }
        }
      }
    }
  }

  nextFloor() {
    const nextF = this.currentFloor + 1;
    this.loadFloor(nextF);
    this.state = 'FLOOR_TRANSITION';
    audio.playBossRoar();
  }

  render(dt) {
    const ctx = this.ctx;
    const width = this.canvas.width;
    const height = this.canvas.height;

    ctx.clearRect(0, 0, width, height);

    // 1. STATE: MAIN MENU
    if (this.state === 'MAIN_MENU') {
      this.ui.drawMainMenu(ctx, width, height, dt, {
        onPlay: () => this.startRun(),
        onInventory: () => { this.state = 'INVENTORY'; },
        onShop: () => { this.state = 'SHOP'; },
        onOptions: () => { this.state = 'OPTIONS'; },
        runes: gameState.runes
      });
      this.ui.drawCrosshair(ctx, input.mouse.screenX, input.mouse.screenY, false);
      return;
    }

    // 2. STATE: INVENTORY
    if (this.state === 'INVENTORY') {
      this.ui.drawInventory(ctx, width, height, gameState, SKIN_CATALOG, {
        onSelectSkin: (id) => { gameState.selectSkin(id); },
        onToggleStartWeapon: (wId) => {
          gameState.toggleStartWeapon(wId);
          this.ui.showToast('Armamento inicial atualizado!');
        },
        onBack: () => { this.state = 'MAIN_MENU'; }
      });
      this.ui.drawCrosshair(ctx, input.mouse.screenX, input.mouse.screenY, false);
      return;
    }

    // 3. STATE: SHOP
    if (this.state === 'SHOP') {
      this.ui.drawShop(ctx, width, height, gameState, SKIN_CATALOG, SHOP_ATTRIBUTES, {
        onBuySkin: (id) => {
          const res = gameState.buySkin(id);
          if (res.success) {
            const sym = res.currency === 'coins' ? '🪙 Moedas' : '🔮 Runas';
            this.ui.showToast(`Skin desbloqueada! (-${res.amount} ${sym}) 🎉`);
          } else {
            this.ui.showToast(res.reason || 'Saldo insuficiente! ❌');
          }
        },
        onBuyAttr: (id) => {
          const res = gameState.buyAttribute(id);
          if (res.success) {
            const sym = res.currency === 'coins' ? '🪙 Moedas' : '🔮 Runas';
            this.ui.showToast(`Comprado com sucesso! (-${res.amount} ${sym}) ✅`);
          } else {
            this.ui.showToast(res.reason || 'Saldo insuficiente! ❌');
          }
        },
        onBack: () => { this.state = 'MAIN_MENU'; }
      });
      this.ui.drawCrosshair(ctx, input.mouse.screenX, input.mouse.screenY, false);
      return;
    }

    // 4. STATE: OPTIONS
    if (this.state === 'OPTIONS') {
      this.ui.drawOptions(ctx, width, height, gameState, audio, {
        onVolumeChange: (v) => {
          gameState.setVolume(v);
          audio.setVolume(v);
          if (gameState.isMuted) {
            gameState.toggleMute(); // unmute when slider moved
            audio.setMuted(false);
          }
        },
        onToggleMute: () => {
          const muted = gameState.toggleMute();
          audio.setMuted(muted);
        },
        onToggleDark: () => { gameState.toggleDarkMode(); },
        onToggleParticles: () => { gameState.toggleParticles(); },
        onToggleFPS: () => { gameState.toggleFPS(); },
        onBack: () => { this.state = 'MAIN_MENU'; }
      });
      this.ui.drawCrosshair(ctx, input.mouse.screenX, input.mouse.screenY, false);
      return;
    }

    // 5. IN-GAME WORLD RENDERING
    ctx.save();
    const offset = this.camera.getRenderOffset();
    ctx.translate(-offset.x, -offset.y);

    if (this.dungeon) {
      this.dungeonRenderer.render(ctx, this.dungeon, this.currentFloor, this.player);
    }

    // Render Traps on the room floor (below entities)
    if (this.currentRoom && this.currentRoom.traps) {
      this.currentRoom.traps.forEach(t => t.render(ctx));
    }

    // Render Floor Pickups (Ammo boxes, Medkits, Blanks, Dropped weapons)
    if (this.currentRoom && this.currentRoom.pickups) {
      this.currentRoom.pickups.forEach(p => p.render(ctx));
    }

    // Particles (only if enabled)
    if (gameState.particlesEnabled) {
      this.particles.render(ctx);
    }

    if (this.currentRoom && this.currentRoom.enemies) {
      this.currentRoom.enemies.forEach(e => e.render(ctx));
    }

    if (this.activeBoss && !this.activeBoss.isDead) {
      this.activeBoss.render(ctx);
    }

    if (this.player) {
      this.player.render(ctx);
    }

    this.bullets.forEach(b => b.render(ctx));
    ctx.restore();

    // 6. IN-GAME HUD
    if (this.state === 'PLAYING') {
      const floorInfo = FLOOR_INFO[this.currentFloor];
      this.ui.drawHUD(
        ctx,
        this.player,
        this.currentFloor,
        floorInfo,
        this.activeBoss,
        this.dungeon,
        this.currentRoom,
        this.interactionPrompt,
        this.bossDefeated,
        {
          onSelectWeapon: (idx) => {
            if (this.player) this.player.selectWeapon(idx, audio);
          }
        }
      );

      // FPS Display
      if (gameState.showFPS) {
        ctx.save();
        ctx.font = "bold 11px 'Press Start 2P', monospace";
        ctx.fillStyle = '#22c55e';
        ctx.textAlign = 'left';
        ctx.fillText(`FPS: ${this.fps}`, 20, height - 20);
        ctx.restore();
      }

      // Rune balance badge in HUD
      ctx.save();
      ctx.fillStyle = 'rgba(80,30,120,0.75)';
      ctx.strokeStyle = '#a855f7';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(20, height - 48, 160, 28, 14);
      ctx.fill();
      ctx.stroke();
      ctx.font = "bold 12px 'Rajdhani', sans-serif";
      ctx.fillStyle = '#e9d5ff';
      ctx.textAlign = 'left';
      ctx.fillText(`🔮 ${gameState.runes} Runas`, 34, height - 29);
      ctx.restore();
    }

    // 7. STATE: FLOOR TRANSITION OVERLAY
    if (this.state === 'FLOOR_TRANSITION') {
      const floorInfo = FLOOR_INFO[this.currentFloor];
      this.ui.drawFloorTransition(ctx, width, height, this.currentFloor, floorInfo, () => {
        this.state = 'PLAYING';
      });
    }

    // 8. STATE: GAME OVER OVERLAY
    if (this.state === 'GAMEOVER') {
      this.ui.drawGameOver(
        ctx,
        width,
        height,
        {
          floor: this.currentFloor,
          kills: this.totalKills,
          damage: this.totalDamageDealt,
          weapon: this.player ? this.player.activeWeapon.name : 'Pistola',
          coinsCollected: this.player ? this.player.coins : 0,
          totalCoins: gameState.coins,
          runes: gameState.runes
        },
        {
          onRestart: () => this.startRun(),
          onMenu: () => { this.state = 'MAIN_MENU'; },
          onShop: () => { this.state = 'SHOP'; },
          onInventory: () => { this.state = 'INVENTORY'; }
        }
      );
    }

    // 9. STATE: VICTORY OVERLAY
    if (this.state === 'VICTORY') {
      if (!this.hasHandledDeath) {
        this.hasHandledDeath = true;
        if (this.player && this.player.coins > 0) {
          gameState.addCoins(this.player.coins);
        }
      }
      const elapsedSeconds = Math.floor((Date.now() - this.startTime) / 1000);
      const mins = String(Math.floor(elapsedSeconds / 60)).padStart(2, '0');
      const secs = String(elapsedSeconds % 60).padStart(2, '0');

      this.ui.drawVictory(
        ctx,
        width,
        height,
        {
          time: `${mins}:${secs}`,
          kills: this.totalKills,
          coinsCollected: this.player ? this.player.coins : 0,
          totalCoins: gameState.coins,
          runes: gameState.runes
        },
        {
          onRestart: () => this.startRun(),
          onMenu: () => { this.state = 'MAIN_MENU'; },
          onShop: () => { this.state = 'SHOP'; }
        }
      );
    }

    // 10. Tactical Crosshair
    this.ui.drawCrosshair(ctx, input.mouse.screenX, input.mouse.screenY, input.mouse.leftDown);
  }
}

window.addEventListener('DOMContentLoaded', () => {
  const game = new Game();
  game.init();
});
