// Collectible Pickups: Health Crates, Ammo Boxes, Blanks, and Floor Weapons (Enter the Gungeon style)
export const PickupType = {
  HEALTH: 'health',
  AMMO: 'ammo',
  BLANK: 'blank',
  COIN: 'coin',
  WEAPON: 'weapon'
};

export class Pickup {
  constructor(x, y, type = PickupType.HEALTH, extraData = null) {
    this.x = x;
    this.y = y;
    this.type = type;
    this.extraData = extraData; // For WEAPON type: Weapon instance or weaponDef
    this.radius = type === PickupType.WEAPON ? 22 : 16;
    this.timer = Math.random() * Math.PI * 2;
    this.isCollected = false;

    // Initial drift / toss velocity
    this.vx = (Math.random() - 0.5) * 60;
    this.vy = (Math.random() - 0.5) * 60;
    this.pickupDelay = type === PickupType.WEAPON ? 0.4 : 0.05; // Prevent immediate pickup on toss
  }

  update(dt, player, audio, particles, ui, input = null) {
    if (this.isCollected || !player || player.isDead) return;

    this.timer += dt * 4;
    if (this.pickupDelay > 0) this.pickupDelay -= dt;

    // Drift physics with friction
    this.x += this.vx * dt;
    this.y += this.vy * dt;
    this.vx *= Math.max(0, 1 - 7 * dt);
    this.vy *= Math.max(0, 1 - 7 * dt);

    const dist = Math.hypot(player.x - this.x, player.y - this.y);

    if (this.type === PickupType.WEAPON) {
      // Weapons on floor require pressing [E] to pick up (tactical control)
      if (this.pickupDelay <= 0 && dist < 58) {
        const wName = (this.extraData && this.extraData.name) || 'Arma';
        if (ui) ui.interactionPrompt = `Pressione [E] para pegar ${wName}`;

        if (input && input.mouse.justInteractDown) {
          this.collectWeapon(player, audio, particles, ui);
        }
      }
      return;
    }

    // Magnetic pull for consumable items (Health, Ammo, Blanks, Coins)
    if (dist < 90 && dist > 0.001) {
      const pullSpeed = (90 - dist) * 5.0;
      this.x += ((player.x - this.x) / dist) * pullSpeed * dt;
      this.y += ((player.y - this.y) / dist) * pullSpeed * dt;
    }

    // Collection collision
    if (dist < (this.radius + player.radius + 6)) {
      this.collect(player, audio, particles, ui);
    }
  }

  collectWeapon(player, audio, particles, ui) {
    if (this.isCollected || !this.extraData) return;
    this.isCollected = true;

    const wDef = this.extraData.def || this.extraData;
    const clip = this.extraData.currentClip !== undefined ? this.extraData.currentClip : wDef.clipSize;
    const reserve = this.extraData.reserveAmmo !== undefined ? this.extraData.reserveAmmo : wDef.maxAmmo;

    const res = player.equipWeapon(wDef, clip, reserve);

    if (audio) audio.playWeaponPickup();
    if (particles) {
      particles.createShockwave(this.x, this.y, 60, '#ffcc00', 250);
      particles.createHitSparks(this.x, this.y, '#ffd700');
    }

    // If a weapon was swapped out, drop it on the floor
    if (res.discarded && player._currentRoom && player._currentRoom.pickups) {
      const dropP = new Pickup(this.x, this.y, PickupType.WEAPON, {
        def: res.discarded.def,
        name: res.discarded.name,
        emoji: res.discarded.emoji,
        currentClip: res.discarded.currentClip,
        reserveAmmo: res.discarded.reserveAmmo
      });
      dropP.pickupDelay = 0.5;
      player._currentRoom.pickups.push(dropP);
    }

    if (ui) {
      if (res.isRefill) {
        ui.showToast(`MUNIÇÃO REABASTECIDA: ${wDef.name.toUpperCase()}!`);
      } else if (res.discarded) {
        ui.showToast(`SUBSTITUIU ${res.discarded.name.toUpperCase()} POR ${wDef.name.toUpperCase()}!`);
      } else {
        ui.showToast(`ARMA COLETADA: ${wDef.name.toUpperCase()}!`);
      }
    }
  }

  collect(player, audio, particles, ui) {
    if (this.isCollected) return;

    if (this.type === PickupType.HEALTH) {
      // --- CAIXA DE VIDA / CORAÇÃO ---
      if (player.health >= player.maxHealth) {
        // Full health: gives bonus coins
        player.coins += 4;
        this.isCollected = true;
        if (audio) audio.playHit();
        if (particles) {
          particles.createHitSparks(this.x, this.y, '#ffd700');
          particles.createDamageText(player.x, player.y - 14, '+4 🪙', false);
        }
        if (ui) ui.showToast('Vida Cheia! +4 Moedas!');
      } else {
        const heal = Math.min(2, player.maxHealth - player.health);
        player.health += heal;
        this.isCollected = true;
        if (audio) audio.playChestOpen();
        if (particles) {
          particles.createShockwave(this.x, this.y, 50, '#22c55e', 180);
          particles.createHitSparks(this.x, this.y, '#4ade80');
          particles.createDamageText(player.x, player.y - 14, `+${heal} HP ❤️`, false);
        }
        if (ui) ui.showToast(`Coração Restaurado! (+${heal} HP)`);
      }
    } else if (this.type === PickupType.AMMO) {
      // --- CAIXA DE MUNIÇÃO (50% de recarga equilibrada) ---
      let targetWeapon = null;
      if (player.activeWeapon && player.activeWeapon.def.maxAmmo !== Infinity && player.activeWeapon.reserveAmmo < player.activeWeapon.def.maxAmmo) {
        targetWeapon = player.activeWeapon;
      } else {
        // Find non-infinite weapon with highest missing ammo
        let minRatio = 1.0;
        for (const w of player.weapons) {
          if (w.def.maxAmmo !== Infinity) {
            const ratio = (w.reserveAmmo + w.currentClip) / (w.def.maxAmmo + w.def.clipSize);
            if (ratio < minRatio) {
              minRatio = ratio;
              targetWeapon = w;
            }
          }
        }
      }

      if (targetWeapon) {
        // Refill 50% max reserve ammo for target weapon + top up all guns slightly (15%)
        const refillAmt = Math.ceil(targetWeapon.def.maxAmmo * 0.5);
        targetWeapon.reserveAmmo = Math.min(targetWeapon.def.maxAmmo, targetWeapon.reserveAmmo + refillAmt);

        // Also give 15% ammo refill to all other guns
        player.weapons.forEach(w => {
          if (w !== targetWeapon && w.def.maxAmmo !== Infinity) {
            w.reserveAmmo = Math.min(w.def.maxAmmo, w.reserveAmmo + Math.ceil(w.def.maxAmmo * 0.15));
          }
        });

        this.isCollected = true;
        if (audio) audio.playAmmoPickup();
        if (particles) {
          particles.createShockwave(this.x, this.y, 60, '#f59e0b', 240);
          particles.createHitSparks(this.x, this.y, '#fbbf24');
          particles.createDamageText(player.x, player.y - 14, '+50% MUNIÇÃO! ⚡', true);
        }
        if (ui) ui.showToast(`+50% MUNIÇÃO: ${targetWeapon.name.toUpperCase()}!`);
      } else {
        // All weapons already full or only pistol: award bonus 4 coins
        player.coins += 4;
        this.isCollected = true;
        if (audio) audio.playAmmoPickup();
        if (particles) {
          particles.createHitSparks(this.x, this.y, '#ffd700');
          particles.createDamageText(player.x, player.y - 14, '+6 🪙', false);
        }
        if (ui) ui.showToast('Munição Já Completa! +6 Moedas!');
      }
    } else if (this.type === PickupType.BLANK) {
      // --- BLANK (BOMBA DE FESTIM) ---
      player.blanks += 1;
      this.isCollected = true;
      if (audio) audio.playChestOpen();
      if (particles) {
        particles.createShockwave(this.x, this.y, 50, '#00ddff', 200);
        particles.createHitSparks(this.x, this.y, '#38bdf8');
        particles.createDamageText(player.x, player.y - 14, '+1 BLANK 🛡️', true);
      }
      if (ui) ui.showToast('Bomba de Festim Coletada! (+1 Blank)');
    } else if (this.type === PickupType.COIN) {
      // --- MOEDA DE OURO / CÁPSULA ---
      const amount = (this.extraData && this.extraData.amount) || (2 + Math.floor(Math.random() * 3));
      player.coins += amount;
      this.isCollected = true;
      if (audio) audio.playHit();
      if (particles) {
        particles.createHitSparks(this.x, this.y, '#ffd700');
        particles.createDamageText(player.x, player.y - 14, `+${amount} 🪙`, false);
      }
    }
  }

  render(ctx) {
    if (this.isCollected) return;

    ctx.save();
    const bobbingY = Math.sin(this.timer) * 3;
    ctx.translate(this.x, this.y + bobbingY);

    if (this.type === PickupType.HEALTH) {
      // --- CAIXA DE VIDA (MEDKIT) ---
      ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
      ctx.beginPath();
      ctx.ellipse(0, 14 - bobbingY, 14, 6, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.shadowBlur = 12;
      ctx.shadowColor = '#22c55e';

      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(-13, -10, 26, 20);

      ctx.strokeStyle = '#22c55e';
      ctx.lineWidth = 2;
      ctx.strokeRect(-13, -10, 26, 20);

      ctx.fillStyle = '#64748b';
      ctx.fillRect(-5, -14, 10, 4);

      ctx.fillStyle = '#ef4444';
      ctx.fillRect(-3, -7, 6, 14);
      ctx.fillRect(-7, -3, 14, 6);
      ctx.shadowBlur = 0;
    } else if (this.type === PickupType.AMMO) {
      // --- CAIXA DE MUNIÇÃO (ENTER THE GUNGEON AMMO BOX) ---
      ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
      ctx.beginPath();
      ctx.ellipse(0, 14 - bobbingY, 16, 6, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.shadowBlur = 16;
      ctx.shadowColor = '#f59e0b';

      // Olive Drab Metal Box
      ctx.fillStyle = '#14532d';
      ctx.fillRect(-15, -12, 30, 24);

      ctx.strokeStyle = '#eab308';
      ctx.lineWidth = 2;
      ctx.strokeRect(-15, -12, 30, 24);

      // Steel latches
      ctx.fillStyle = '#94a3b8';
      ctx.fillRect(-13, -9, 4, 18);
      ctx.fillRect(9, -9, 4, 18);

      // Golden Bullet Belt emblem
      ctx.fillStyle = '#fbbf24';
      for (let b = -2; b <= 2; b++) {
        ctx.fillRect(b * 4 - 1.5, -4, 3, 8);
        ctx.fillStyle = '#d97706';
        ctx.fillRect(b * 4 - 1.5, -6, 3, 2);
        ctx.fillStyle = '#fbbf24';
      }

      ctx.shadowBlur = 0;
      // Header tag
      ctx.font = "bold 9px 'Press Start 2P', monospace";
      ctx.fillStyle = '#fbbf24';
      ctx.textAlign = 'center';
      ctx.fillText('AMMO', 0, -18);
    } else if (this.type === PickupType.BLANK) {
      // --- BLANK PICKUP ---
      ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
      ctx.beginPath();
      ctx.ellipse(0, 14 - bobbingY, 12, 5, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.shadowBlur = 14;
      ctx.shadowColor = '#00ddff';

      ctx.fillStyle = '#0284c7';
      ctx.beginPath();
      ctx.arc(0, 0, 12, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.font = "12px sans-serif";
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('🛡️', 0, 0);
      ctx.shadowBlur = 0;
    } else if (this.type === PickupType.COIN) {
      // --- COIN PICKUP ---
      ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
      ctx.beginPath();
      ctx.ellipse(0, 8 - bobbingY, 8, 4, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.shadowBlur = 8;
      ctx.shadowColor = '#ffd700';

      ctx.fillStyle = '#ffd700';
      ctx.beginPath();
      ctx.arc(0, 0, 7, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = '#b45309';
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.shadowBlur = 0;
    } else if (this.type === PickupType.WEAPON) {
      // --- DROPPED WEAPON ON THE FLOOR (Gungeon style) ---
      const wDef = (this.extraData && (this.extraData.def || this.extraData)) || {};
      const wName = wDef.name || 'Arma';
      const wEmoji = wDef.emoji || '🔫';
      const clip = this.extraData && this.extraData.currentClip !== undefined ? this.extraData.currentClip : (wDef.clipSize || 10);
      const res = this.extraData && this.extraData.reserveAmmo !== undefined ? (this.extraData.reserveAmmo === Infinity ? '∞' : this.extraData.reserveAmmo) : (wDef.maxAmmo === Infinity ? '∞' : wDef.maxAmmo || 0);

      // Golden aura shadow on floor
      ctx.fillStyle = 'rgba(255, 204, 0, 0.2)';
      ctx.beginPath();
      ctx.ellipse(0, 16 - bobbingY, 26, 10, 0, 0, Math.PI * 2);
      ctx.fill();

      // Pedestal glow ring
      ctx.strokeStyle = '#ffcc00';
      ctx.lineWidth = 2;
      ctx.shadowBlur = 15;
      ctx.shadowColor = '#ffcc00';
      ctx.beginPath();
      ctx.arc(0, 0, 20, 0, Math.PI * 2);
      ctx.stroke();

      // Weapon Icon
      ctx.font = "24px sans-serif";
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(wEmoji, 0, -2);

      // Name & Ammo Tag above weapon
      ctx.shadowBlur = 4;
      ctx.shadowColor = '#000000';
      ctx.font = "bold 10px 'Rajdhani', sans-serif";
      ctx.fillStyle = '#ffd700';
      ctx.fillText(wName, 0, -26);

      ctx.font = "bold 9px 'Press Start 2P', monospace";
      ctx.fillStyle = '#ffffff';
      ctx.fillText(`${clip}/${res}`, 0, -14);
      ctx.shadowBlur = 0;
    }

    ctx.restore();
  }
}
