// Persistent Game State Manager — stores meta-progression across runs
// Uses localStorage for persistence between sessions

const SAVE_KEY = 'gungeon_mythos_save';

const SKIN_CATALOG = [
  {
    id: 'default',
    name: 'Explorador',
    desc: 'O aventureiro clássico da Masmorra.',
    price: 0,
    coinPrice: 0,
    bodyColor: '#2b6cb0',
    capeColor: '#1c3d5a',
    helmetColor: '#3182ce',
    emoji: '🔵'
  },
  {
    id: 'crimson',
    name: 'Guerreiro Carmesim',
    desc: 'Nascido no fogo da batalha.',
    price: 100,
    coinPrice: 60,
    bodyColor: '#b91c1c',
    capeColor: '#7f1d1d',
    helmetColor: '#dc2626',
    emoji: '🔴'
  },
  {
    id: 'jade',
    name: 'Caçador Jade',
    desc: 'Veloz como a sombra das florestas.',
    price: 150,
    coinPrice: 90,
    bodyColor: '#15803d',
    capeColor: '#14532d',
    helmetColor: '#16a34a',
    emoji: '🟢'
  },
  {
    id: 'obsidian',
    name: 'Fantasma Obsidiana',
    desc: 'Um ser das sombras entre os mundos.',
    price: 200,
    coinPrice: 130,
    bodyColor: '#6d28d9',
    capeColor: '#3b0764',
    helmetColor: '#7c3aed',
    emoji: '🟣'
  },
  {
    id: 'golden',
    name: 'Lendário Dourado',
    desc: 'Apenas os mais bravos merecem este manto.',
    price: 400,
    coinPrice: 250,
    bodyColor: '#d97706',
    capeColor: '#78350f',
    helmetColor: '#f59e0b',
    emoji: '🟡'
  }
];

const SHOP_ATTRIBUTES = [
  {
    id: 'attr_heart',
    name: '+1 Coração',
    desc: 'Aumenta o HP máximo em 2.',
    price: 80,
    coinPrice: 50,
    emoji: '❤️',
    stackable: true,
    maxStack: 4
  },
  {
    id: 'attr_blank',
    name: 'Blank Extra',
    desc: 'Começa cada run com +1 Blank.',
    price: 60,
    coinPrice: 40,
    emoji: '🛡️',
    stackable: true,
    maxStack: 3
  },
  {
    id: 'attr_speed',
    name: 'Botas Velozes',
    desc: 'Velocidade de movimento +30px/s.',
    price: 120,
    coinPrice: 75,
    emoji: '👟',
    stackable: false
  },
  {
    id: 'attr_shotgun',
    name: 'Espingarda Inicial',
    desc: 'Começa com Espingarda no inventário.',
    price: 150,
    coinPrice: 90,
    emoji: '💥',
    stackable: false
  },
  {
    id: 'attr_ak47',
    name: 'AK-47 Inicial',
    desc: 'Começa com o Fuzil AK-Myth no inventário.',
    price: 180,
    coinPrice: 110,
    emoji: '⚡',
    stackable: false
  },
  {
    id: 'attr_sniper',
    name: 'Sniper Inicial',
    desc: 'Começa com o Rifle Sniper M99 no inventário.',
    price: 250,
    coinPrice: 160,
    emoji: '🎯',
    stackable: false
  },
  {
    id: 'attr_katana',
    name: 'Katana Espectral',
    desc: 'Corte em área amplo que fatia inimigos e anula projéteis!',
    price: 260,
    coinPrice: 170,
    emoji: '⚔️',
    stackable: false
  },
  {
    id: 'attr_laser',
    name: 'Canhão Laser',
    desc: 'Feixe contínuo penetrante de alta precisão.',
    price: 240,
    coinPrice: 155,
    emoji: '💠',
    stackable: false
  },
  {
    id: 'attr_minigun',
    name: 'Gatling Vulcano',
    desc: 'Metralhadora rotativa com cadência devastadora.',
    price: 280,
    coinPrice: 185,
    emoji: '🌪️',
    stackable: false
  },
  {
    id: 'attr_flamethrower',
    name: 'Lança-Chamas',
    desc: 'Labaredas em cone contínuo incinerando múltiplos alvos.',
    price: 250,
    coinPrice: 165,
    emoji: '🔥',
    stackable: false
  }
];

const DEFAULT_STATE = {
  runes: 0,                // Meta-currency (dropped by bosses)
  coins: 0,                // Persistent meta-coins bank saved from runs
  selectedSkin: 'default',
  unlockedSkins: ['default'],
  purchasedAttributes: {}, // { attrId: count }
  selectedStartWeapons: [], // IDs of up to 2 starting guns ('shotgun', 'ak47', 'sniper')
  volume: 0.35,
  isMuted: false,
  showFPS: false,
  particlesEnabled: true,
  darkMode: true
};

class GameStateManager {
  constructor() {
    this.data = { ...DEFAULT_STATE };
    this.load();
  }

  load() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        // Merge with defaults to handle new fields added in updates
        this.data = { ...DEFAULT_STATE, ...parsed };
        // Always ensure 'default' skin is unlocked
        if (!this.data.unlockedSkins.includes('default')) {
          this.data.unlockedSkins.push('default');
        }
        if (!Array.isArray(this.data.selectedStartWeapons)) {
          this.data.selectedStartWeapons = [];
        }
        if (typeof this.data.coins !== 'number') {
          this.data.coins = 0;
        }
      }
    } catch (e) {
      console.warn('Failed to load save data, using defaults.', e);
      this.data = { ...DEFAULT_STATE };
    }
  }

  save() {
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(this.data));
    } catch (e) {
      console.warn('Failed to save game state.', e);
    }
  }

  // --- COINS (Persistent Gold) ---
  get coins() { return this.data.coins || 0; }

  addCoins(amount) {
    this.data.coins = Math.max(0, (this.data.coins || 0) + amount);
    this.save();
  }

  // --- RUNES ---
  get runes() { return this.data.runes || 0; }

  addRunes(amount) {
    this.data.runes = Math.max(0, (this.data.runes || 0) + amount);
    this.save();
  }

  // --- SKIN ---
  get selectedSkin() { return this.data.selectedSkin; }
  get unlockedSkins() { return this.data.unlockedSkins; }

  selectSkin(id) {
    if (this.data.unlockedSkins.includes(id)) {
      this.data.selectedSkin = id;
      this.save();
      return true;
    }
    return false;
  }

  buySkin(id) {
    const skin = SKIN_CATALOG.find(s => s.id === id);
    if (!skin) return { success: false, reason: 'Skin não encontrada' };
    if (this.data.unlockedSkins.includes(id)) return { success: false, reason: 'Skin já desbloqueada' };

    const coinCost = skin.coinPrice || Math.round(skin.price * 0.6);
    const runeCost = skin.price;

    // Prioritize Coins if player has enough, otherwise use Runas
    if (this.coins >= coinCost && coinCost > 0) {
      this.data.coins -= coinCost;
      this.data.unlockedSkins.push(id);
      this.save();
      return { success: true, currency: 'coins', amount: coinCost };
    } else if (this.runes >= runeCost && runeCost > 0) {
      this.data.runes -= runeCost;
      this.data.unlockedSkins.push(id);
      this.save();
      return { success: true, currency: 'runes', amount: runeCost };
    }

    return {
      success: false,
      reason: `Necessário: 🪙 ${coinCost} Moedas ou 🔮 ${runeCost} Runas`
    };
  }

  getSkinData(id) {
    return SKIN_CATALOG.find(s => s.id === id) || SKIN_CATALOG[0];
  }

  getActiveSkinData() {
    return this.getSkinData(this.data.selectedSkin);
  }

  // --- ATTRIBUTES & STARTING WEAPONS ---
  get purchasedAttributes() { return this.data.purchasedAttributes; }

  getAttributeCount(id) {
    return this.data.purchasedAttributes[id] || 0;
  }

  buyAttribute(id) {
    const attr = SHOP_ATTRIBUTES.find(a => a.id === id);
    if (!attr) return { success: false, reason: 'Item não encontrado' };
    const currentCount = this.getAttributeCount(id);
    if (attr.stackable && currentCount >= attr.maxStack) {
      return { success: false, reason: 'Limite máximo atingido!' };
    }
    if (!attr.stackable && currentCount >= 1) {
      return { success: false, reason: 'Item já desbloqueado!' };
    }

    const coinCost = attr.coinPrice || Math.round(attr.price * 0.6);
    const runeCost = attr.price;

    const finalizePurchase = (curr, amt) => {
      this.data.purchasedAttributes[id] = currentCount + 1;

      // If this is a weapon, automatically equip in available slot (up to 2 free slots)
      if (['attr_shotgun', 'attr_ak47', 'attr_sniper', 'attr_katana', 'attr_laser', 'attr_minigun', 'attr_flamethrower'].includes(id)) {
        const wKey = id.replace('attr_', '');
        if (!this.data.selectedStartWeapons.includes(wKey)) {
          if (this.data.selectedStartWeapons.length >= 2) {
            this.data.selectedStartWeapons.shift();
          }
          this.data.selectedStartWeapons.push(wKey);
        }
      }
      this.save();
      return { success: true, currency: curr, amount: amt };
    };

    if (this.coins >= coinCost && coinCost > 0) {
      this.data.coins -= coinCost;
      return finalizePurchase('coins', coinCost);
    } else if (this.runes >= runeCost && runeCost > 0) {
      this.data.runes -= runeCost;
      return finalizePurchase('runes', runeCost);
    }

    return {
      success: false,
      reason: `Necessário: 🪙 ${coinCost} Moedas ou 🔮 ${runeCost} Runas`
    };
  }

  toggleStartWeapon(weaponId) {
    if (!this.data.selectedStartWeapons) this.data.selectedStartWeapons = [];
    const idx = this.data.selectedStartWeapons.indexOf(weaponId);
    if (idx >= 0) {
      // Toggle off
      this.data.selectedStartWeapons.splice(idx, 1);
    } else {
      // Maximum 2 bonus starting weapons (Slot 0 is always the Starter Pistol)
      if (this.data.selectedStartWeapons.length >= 2) {
        this.data.selectedStartWeapons.shift(); // remove oldest to make room
      }
      this.data.selectedStartWeapons.push(weaponId);
    }
    this.save();
    return true;
  }

  // Compute active player bonus stats from purchased attributes and selected weapons
  getPlayerBonuses() {
    const selWeapons = this.data.selectedStartWeapons || [];
    const hasShotgun = this.getAttributeCount('attr_shotgun') > 0;
    const hasAK47 = this.getAttributeCount('attr_ak47') > 0;
    const hasSniper = this.getAttributeCount('attr_sniper') > 0;
    const hasKatana = this.getAttributeCount('attr_katana') > 0;
    const hasLaser = this.getAttributeCount('attr_laser') > 0;
    const hasMinigun = this.getAttributeCount('attr_minigun') > 0;
    const hasFlamethrower = this.getAttributeCount('attr_flamethrower') > 0;

    // Default selection if player owns weapons but hasn't picked them yet
    if (selWeapons.length === 0) {
      if (hasKatana && selWeapons.length < 2) selWeapons.push('katana');
      if (hasShotgun && selWeapons.length < 2) selWeapons.push('shotgun');
      if (hasAK47 && selWeapons.length < 2) selWeapons.push('ak47');
      if (hasSniper && selWeapons.length < 2) selWeapons.push('sniper');
      if (hasLaser && selWeapons.length < 2) selWeapons.push('laser');
      if (hasMinigun && selWeapons.length < 2) selWeapons.push('minigun');
      if (hasFlamethrower && selWeapons.length < 2) selWeapons.push('flamethrower');
      this.data.selectedStartWeapons = selWeapons;
    }

    return {
      extraHealth: (this.getAttributeCount('attr_heart')) * 2,
      extraBlanks: this.getAttributeCount('attr_blank'),
      extraSpeed: this.getAttributeCount('attr_speed') > 0 ? 30 : 0,
      startShotgun: hasShotgun && selWeapons.includes('shotgun'),
      startAK47: hasAK47 && selWeapons.includes('ak47'),
      startSniper: hasSniper && selWeapons.includes('sniper'),
      startKatana: hasKatana && selWeapons.includes('katana'),
      startLaser: hasLaser && selWeapons.includes('laser'),
      startMinigun: hasMinigun && selWeapons.includes('minigun'),
      startFlamethrower: hasFlamethrower && selWeapons.includes('flamethrower'),
      unlockedShotgun: hasShotgun,
      unlockedAK47: hasAK47,
      unlockedSniper: hasSniper,
      unlockedKatana: hasKatana,
      unlockedLaser: hasLaser,
      unlockedMinigun: hasMinigun,
      unlockedFlamethrower: hasFlamethrower,
      selectedStartWeapons: [...selWeapons]
    };
  }

  // --- AUDIO ---
  get volume() { return this.data.volume; }
  get isMuted() { return this.data.isMuted; }

  setVolume(v) {
    this.data.volume = Math.max(0, Math.min(1, v));
    this.save();
  }

  toggleMute() {
    this.data.isMuted = !this.data.isMuted;
    this.save();
    return this.data.isMuted;
  }

  // --- SETTINGS ---
  get showFPS() { return this.data.showFPS; }
  get particlesEnabled() { return this.data.particlesEnabled; }
  get darkMode() { return this.data.darkMode; }

  toggleFPS() { this.data.showFPS = !this.data.showFPS; this.save(); }
  toggleParticles() { this.data.particlesEnabled = !this.data.particlesEnabled; this.save(); }
  toggleDarkMode() { this.data.darkMode = !this.data.darkMode; this.save(); }
}

export const gameState = new GameStateManager();
export { SKIN_CATALOG, SHOP_ATTRIBUTES };
