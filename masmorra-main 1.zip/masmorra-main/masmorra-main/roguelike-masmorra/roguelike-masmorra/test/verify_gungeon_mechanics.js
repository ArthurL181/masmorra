import { Player } from '../src/entities/Player.js';
import { WeaponTypes, Weapon } from '../src/combat/Weapons.js';
import { Pickup, PickupType } from '../src/dungeon/Pickup.js';
import { Enemy, EnemyType } from '../src/entities/Enemy.js';

console.log('--- TESTING GUNGEON INVENTORY & AI MECHANICS ---');

// 1. Verify Player starts with permanent infinite starter pistol
const player = new Player(100, 100);
if (player.weapons.length !== 1) throw new Error('Player must start with 1 weapon');
if (player.weapons[0].id !== 'pistol') throw new Error('Starter weapon must be pistol');
if (player.weapons[0].def.maxAmmo !== Infinity) throw new Error('Starter pistol must have infinite ammo');
console.log('✔ Test 1 Passed: Starter pistol has infinite ammo.');

// 2. Verify unlimited weapon capacity (Arsenal)
player.equipWeapon(WeaponTypes.SHOTGUN);
player.equipWeapon(WeaponTypes.AK47);
player.equipWeapon(WeaponTypes.SNIPER);
player.equipWeapon(WeaponTypes.RPG);
player.equipWeapon(WeaponTypes.PLASMA);

if (player.weapons.length !== 6) {
  throw new Error(`Expected 6 weapons in arsenal, but found ${player.weapons.length}`);
}
console.log(`✔ Test 2 Passed: Arsenal holds ${player.weapons.length} weapons without 2-weapon limit.`);

// 3. Verify starter pistol CANNOT be dropped
player.selectWeapon(0); // Select pistol
const dropPistolAttempt = player.dropActiveWeapon();
if (dropPistolAttempt !== null) throw new Error('Starter pistol must NOT be droppable!');
if (player.weapons.length !== 6) throw new Error('Pistol should not have been removed');
console.log('✔ Test 3 Passed: Starter pistol cannot be dropped (player is never left unarmed).');

// 4. Verify non-starter weapons CAN be dropped
player.selectWeapon(1); // Select Shotgun
const droppedShotgun = player.dropActiveWeapon();
if (!droppedShotgun || droppedShotgun.id !== 'shotgun') throw new Error('Failed to drop shotgun');
if (player.weapons.length !== 5) throw new Error('Shotgun was not removed from arsenal');
console.log('✔ Test 4 Passed: Dropping non-starter weapon works properly.');

// 5. Verify dropping creates a floor pickup that can be picked up again
const floorWeaponPickup = new Pickup(120, 120, PickupType.WEAPON, droppedShotgun);
if (floorWeaponPickup.type !== PickupType.WEAPON) throw new Error('Pickup should be WEAPON type');
floorWeaponPickup.collectWeapon(player, null, null, null);
if (player.weapons.length !== 6) throw new Error('Shotgun was not re-added to arsenal on pickup');
console.log('✔ Test 5 Passed: Dropped weapon floor pickup and re-equipping verified.');

// 6. Verify empty weapons are NOT auto-discarded
const akWeapon = player.weapons.find(w => w.id === 'ak47');
akWeapon.currentClip = 0;
akWeapon.reserveAmmo = 0;
player.selectWeapon(player.weapons.indexOf(akWeapon));
// Simulate input with empty gun
player.update(0.016, {
  getMovementVector: () => ({ dx: 0, dy: 0 }),
  mouse: {
    worldX: 200,
    worldY: 200,
    justSelectSlot: -1,
    justNextWeapon: false,
    justPrevWeapon: false,
    justQuickSwitch: false,
    justDropWeapon: false,
    justReloadDown: false
  }
}, null, null, null);

if (!player.weapons.some(w => w.id === 'ak47')) {
  throw new Error('Empty weapon was auto-discarded! It must remain in the arsenal.');
}
console.log('✔ Test 6 Passed: Empty weapons are retained in the inventory (not lost).');

// 7. Verify Ammo Box refills depleted weapon
const ammoBox = new Pickup(100, 100, PickupType.AMMO);
ammoBox.collect(player, null, null, null);
if (akWeapon.reserveAmmo <= 0) {
  throw new Error('Ammo Box failed to restore ammo for depleted weapon!');
}
console.log(`✔ Test 7 Passed: Ammo Box restored ammo to ${akWeapon.reserveAmmo}/${akWeapon.def.maxAmmo}!`);

// 8. Verify Enemy Obstacle Avoidance & Telegraphing
const dummyRoom = {
  x: 0,
  y: 0,
  width: 800,
  height: 600,
  pillars: [{ x: 300, y: 300, radius: 24 }]
};

const enemy = new Enemy(280, 300, EnemyType.PISTOL);
const steeredMove = enemy.getSteeredMove(350, 300, 100, dummyRoom);
if (steeredMove.vx === 0 && steeredMove.vy === 0) {
  throw new Error('Steered movement should not be zero');
}
console.log('✔ Test 8 Passed: Enemy pillar avoidance steering computed properly.');

// 9. Verify Sniper Laser Lock
const sniperEnemy = new Enemy(500, 500, EnemyType.SNIPER);
sniperEnemy.shootTimer = 0.20; // Within lock window (<= 0.28s)
const dummyBullets = [];
sniperEnemy.update(0.016, player, dummyBullets, null, null, dummyRoom);
if (!sniperEnemy.laserLocked) {
  throw new Error('Sniper should have locked laser in place during telegraph window!');
}
console.log('✔ Test 9 Passed: Sniper laser-locking telegraph confirmed.');

console.log('--- ALL GUNGEON MECHANICS VERIFIED WITH 100% SUCCESS! ---');
