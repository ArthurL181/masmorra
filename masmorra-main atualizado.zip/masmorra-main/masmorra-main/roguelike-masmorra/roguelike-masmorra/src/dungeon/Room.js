// Room representation in the procedural dungeon
export const RoomType = {
  START: 'START',
  COMBAT: 'COMBAT',
  CHEST: 'CHEST',
  BOSS: 'BOSS',
  ELEVATOR: 'ELEVATOR'
};

export class Door {
  constructor(dir, x, y, width, height, targetRoom) {
    this.dir = dir; // 'N', 'S', 'E', 'W'
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
    this.targetRoom = targetRoom;
    this.isLocked = false;
    this.isBossExitGate = false;
  }
}

export class Elevator {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.width = 120;
    this.height = 120;
    this.timer = 0;
  }

  update(dt) {
    this.timer += dt * 3.5;
  }

  render(ctx) {
    ctx.save();
    ctx.translate(this.x, this.y);

    const halfW = this.width / 2;
    const halfH = this.height / 2;

    // Outer pit frame
    ctx.fillStyle = '#080a10';
    ctx.fillRect(-halfW, -halfH, this.width, this.height);

    // Deep shaft gradient
    const pit = ctx.createRadialGradient(0, 0, 10, 0, 0, halfW);
    pit.addColorStop(0, '#020305');
    pit.addColorStop(1, '#1b2233');
    ctx.fillStyle = pit;
    ctx.fillRect(-halfW + 6, -halfH + 6, this.width - 12, this.height - 12);

    // Elevator platform border
    ctx.strokeStyle = '#00ddff';
    ctx.lineWidth = 2.5;
    ctx.strokeRect(-halfW + 10, -halfH + 10, this.width - 20, this.height - 20);

    // Hazard yellow/black corners
    ctx.fillStyle = '#ffcc00';
    ctx.fillRect(-halfW, -halfH, 18, 6);
    ctx.fillRect(halfW - 18, -halfH, 18, 6);
    ctx.fillRect(-halfW, halfH - 6, 18, 6);
    ctx.fillRect(halfW - 18, halfH - 6, 18, 6);

    // Glowing animated descent arrows
    const pulse = Math.sin(this.timer) * 0.3 + 0.7;
    ctx.fillStyle = `rgba(0, 221, 255, ${pulse})`;
    ctx.shadowBlur = 16 * pulse;
    ctx.shadowColor = '#00ddff';

    ctx.beginPath();
    ctx.moveTo(-20, -14);
    ctx.lineTo(0, 10);
    ctx.lineTo(20, -14);
    ctx.closePath();
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(-20, 2);
    ctx.lineTo(0, 26);
    ctx.lineTo(20, 2);
    ctx.closePath();
    ctx.fill();

    // Floating banner
    ctx.shadowBlur = 10;
    ctx.shadowColor = '#00ddff';
    ctx.font = "bold 12px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ffd700';
    ctx.textAlign = 'center';
    ctx.fillText('ELEVADOR', 0, -halfH - 22);
    ctx.font = "bold 13px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#ffffff';
    ctx.fillText('PISE OU APERTE [E] PARA DESCER', 0, -halfH - 6);

    ctx.restore();
  }
}

export class Chest {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.width = 44;
    this.height = 36;
    this.isOpen = false;
    this.weaponDrop = null;
    this.glowTimer = 0;
  }

  update(dt) {
    this.glowTimer += dt;
  }

  render(ctx) {
    ctx.save();
    ctx.translate(this.x, this.y);

    // Glow effect
    const glow = Math.sin(this.glowTimer * 3) * 0.2 + 0.8;
    ctx.shadowBlur = this.isOpen ? 4 : 12 * glow;
    ctx.shadowColor = this.isOpen ? '#555' : '#ffcc00';

    if (this.isOpen) {
      // Open chest
      ctx.fillStyle = '#4a3525';
      ctx.fillRect(-22, -18, 44, 36);
      ctx.fillStyle = '#2d1f14';
      ctx.fillRect(-18, -14, 36, 12); // inside darkness
      ctx.fillStyle = '#9e8138';
      ctx.fillRect(-22, -26, 44, 10); // open lid
    } else {
      // Closed chest
      ctx.fillStyle = '#6d4c2b';
      ctx.fillRect(-22, -18, 44, 36);

      // Gold trims
      ctx.fillStyle = '#ffcc00';
      ctx.fillRect(-22, -4, 44, 6);
      ctx.fillRect(-6, -4, 12, 12); // Lock
      ctx.fillStyle = '#222';
      ctx.fillRect(-2, 0, 4, 6); // Keyhole
    }

    ctx.restore();
  }
}

export class Portal {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.radius = 48;
    this.angle = 0;
    this.active = false;
  }

  update(dt) {
    if (this.active) {
      this.angle += dt * 3.5;
    }
  }

  render(ctx) {
    if (!this.active) return;
    ctx.save();
    ctx.translate(this.x, this.y);

    // 1. Vertical Light Beacon rising into the ceiling
    const beam = ctx.createLinearGradient(0, 0, 0, -180);
    beam.addColorStop(0, 'rgba(0, 221, 255, 0.45)');
    beam.addColorStop(1, 'rgba(0, 221, 255, 0)');
    ctx.fillStyle = beam;
    ctx.beginPath();
    ctx.moveTo(-this.radius * 0.7, 0);
    ctx.lineTo(-this.radius * 0.3, -180);
    ctx.lineTo(this.radius * 0.3, -180);
    ctx.lineTo(this.radius * 0.7, 0);
    ctx.closePath();
    ctx.fill();

    // 2. Swirling arcane rings on the ground
    ctx.shadowBlur = 25;
    ctx.shadowColor = '#00ddff';

    for (let r = this.radius; r >= 16; r -= 10) {
      ctx.beginPath();
      const dir = (r % 20 === 0 ? 1 : -1);
      ctx.arc(0, 0, r, this.angle * dir, this.angle * dir + Math.PI * 1.6);
      ctx.strokeStyle = r > 28 ? '#00ddff' : '#ffd700';
      ctx.lineWidth = 4;
      ctx.stroke();
    }

    // 3. Glowing Core
    ctx.beginPath();
    ctx.arc(0, 0, 14, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff';
    ctx.shadowBlur = 30;
    ctx.shadowColor = '#ffffff';
    ctx.fill();

    // 4. Floating Header
    ctx.shadowBlur = 8;
    ctx.shadowColor = '#00ddff';
    ctx.font = "bold 13px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ffd700';
    ctx.textAlign = 'center';
    ctx.fillText('PORTAL', 0, -65);
    ctx.font = "bold 11px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#ffffff';
    ctx.fillText('ENTRE PARA AVANÇAR', 0, -48);

    ctx.restore();
  }
}

export class Room {
  constructor(gridX, gridY, width, height, type = RoomType.COMBAT) {
    this.gridX = gridX;
    this.gridY = gridY;
    this.width = width;
    this.height = height;
    this.type = type;

    // World bounds
    this.x = 0;
    this.y = 0;

    this.doors = []; // List of Door objects
    this.neighbors = {}; // { N, S, E, W } -> Room

    // Room status
    this.visited = false;
    this.cleared = (type === RoomType.START || type === RoomType.CHEST);
    this.isActive = false; // Player currently inside and fighting

    // Room Contents
    this.enemies = [];
    this.pillars = []; // Collision cover objects
    this.traps = [];   // Environmental hazards & traps
    this.chest = null;
    this.portal = null;
    this.elevator = null;
  }

  setWorldPos(x, y) {
    this.x = x;
    this.y = y;
  }

  contains(px, py) {
    return px >= this.x && px <= this.x + this.width &&
           py >= this.y && py <= this.y + this.height;
  }

  lockDoors() {
    this.doors.forEach(d => d.isLocked = true);
  }

  unlockDoors() {
    this.doors.forEach(d => d.isLocked = false);
  }
}
