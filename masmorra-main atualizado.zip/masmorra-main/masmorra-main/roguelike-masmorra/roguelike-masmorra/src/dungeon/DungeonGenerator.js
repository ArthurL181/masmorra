import { Room, RoomType, Door, Chest, Portal, Elevator } from './Room.js';
import { SpikeTrap, FlameVent, SawbladeTrap } from './Trap.js';

export class DungeonGenerator {
  constructor() {
    this.roomWidth = 960;
    this.roomHeight = 680;
    this.corridorLength = 320; // Distance between room walls
    this.cellSpacingX = this.roomWidth + this.corridorLength;
    this.cellSpacingY = this.roomHeight + this.corridorLength;
  }

  generate(floorNumber) {
    // Number of rooms scales with floor
    const targetRoomCount = 5 + floorNumber; // Floor 1: 6, Floor 2: 7, ..., Floor 5: 10
    const grid = new Map(); // key: "gx,gy" -> Room
    const rooms = [];

    const getKey = (gx, gy) => `${gx},${gy}`;

    // 1. Create Start Room at (0, 0)
    const startRoom = new Room(0, 0, this.roomWidth, this.roomHeight, RoomType.START);
    startRoom.visited = true;
    startRoom.cleared = true;
    grid.set(getKey(0, 0), startRoom);
    rooms.push(startRoom);

    // 2. Grow rooms randomly on grid
    const queue = [{ gx: 0, gy: 0 }];
    const directions = [
      { dir: 'N', dx: 0, dy: -1, opp: 'S' },
      { dir: 'S', dx: 0, dy: 1, opp: 'N' },
      { dir: 'E', dx: 1, dy: 0, opp: 'W' },
      { dir: 'W', dx: -1, dy: 0, opp: 'E' }
    ];

    while (rooms.length < targetRoomCount && queue.length > 0) {
      const idx = Math.floor(Math.random() * queue.length);
      const current = queue[idx];
      const currentRoom = grid.get(getKey(current.gx, current.gy));

      const shuffledDirs = [...directions].sort(() => Math.random() - 0.5);
      let added = false;

      for (const d of shuffledDirs) {
        const nx = current.gx + d.dx;
        const ny = current.gy + d.dy;
        const nKey = getKey(nx, ny);

        if (!grid.has(nKey) && rooms.length < targetRoomCount) {
          let neighborCount = 0;
          for (const checkD of directions) {
            if (grid.has(getKey(nx + checkD.dx, ny + checkD.dy))) {
              neighborCount++;
            }
          }

          if (neighborCount <= 1 || Math.random() < 0.2) {
            const newRoom = new Room(nx, ny, this.roomWidth, this.roomHeight, RoomType.COMBAT);
            grid.set(nKey, newRoom);
            rooms.push(newRoom);
            queue.push({ gx: nx, gy: ny });

            currentRoom.neighbors[d.dir] = newRoom;
            newRoom.neighbors[d.opp] = currentRoom;

            added = true;
            break;
          }
        }
      }

      if (!added) {
        queue.splice(idx, 1);
      }
    }

    // 3. Assign Special Rooms (Boss Room furthest away, Chest Room at another leaf)
    let maxDist = -1;
    let bossRoom = null;
    const leafRooms = [];

    rooms.forEach(r => {
      const dist = Math.abs(r.gridX) + Math.abs(r.gridY);
      const neighborCount = Object.keys(r.neighbors).length;

      if (dist > maxDist) {
        maxDist = dist;
        bossRoom = r;
      }

      if (neighborCount === 1 && r !== startRoom) {
        leafRooms.push(r);
      }
    });

    if (bossRoom) {
      bossRoom.type = RoomType.BOSS;
    }

    // Pick a leaf room for Chest (not the boss room, not start)
    const availableForChest = leafRooms.filter(r => r !== bossRoom && r !== startRoom);
    let chestRoom = null;
    if (availableForChest.length > 0) {
      chestRoom = availableForChest[Math.floor(Math.random() * availableForChest.length)];
    } else {
      chestRoom = rooms.find(r => r !== bossRoom && r !== startRoom);
    }

    if (chestRoom) {
      chestRoom.type = RoomType.CHEST;
      chestRoom.cleared = true;
    }

    // 4. Create dedicated ELEVATOR EXIT CHAMBER attached to Boss Room!
    let elevatorRoom = null;
    if (bossRoom) {
      let exDir = 'N';
      let oppDir = 'S';
      let egx = bossRoom.gridX;
      let egy = bossRoom.gridY - 1;

      if (grid.has(getKey(egx, egy))) {
        egx = bossRoom.gridX + 1; egy = bossRoom.gridY; exDir = 'E'; oppDir = 'W';
        if (grid.has(getKey(egx, egy))) {
          egx = bossRoom.gridX - 1; egy = bossRoom.gridY; exDir = 'W'; oppDir = 'E';
          if (grid.has(getKey(egx, egy))) {
            egx = bossRoom.gridX; egy = bossRoom.gridY + 1; exDir = 'S'; oppDir = 'N';
          }
        }
      }

      // Elevator chamber dimensions
      elevatorRoom = new Room(egx, egy, 520, 420, RoomType.ELEVATOR);
      elevatorRoom.cleared = true;
      grid.set(getKey(egx, egy), elevatorRoom);
      rooms.push(elevatorRoom);

      bossRoom.neighbors[exDir] = elevatorRoom;
      elevatorRoom.neighbors[oppDir] = bossRoom;
    }

    // 5. Calculate World Positions & Doors
    rooms.forEach(room => {
      const worldX = room.gridX * this.cellSpacingX;
      const worldY = room.gridY * this.cellSpacingY;
      room.setWorldPos(worldX, worldY);

      const doorWidth = 100;
      const doorDepth = 30;

      const createDoorForNeighbor = (dir, targetRoom, dX, dY, w, h) => {
        const door = new Door(dir, dX, dY, w, h, targetRoom);
        // The gate leading into the Elevator room starts SEALED until the boss dies!
        if (room.type === RoomType.BOSS && targetRoom.type === RoomType.ELEVATOR) {
          door.isBossExitGate = true;
          door.isLocked = true;
        }
        room.doors.push(door);
      };

      if (room.neighbors['N']) {
        const dX = worldX + (room.width - doorWidth) / 2;
        const dY = worldY - doorDepth;
        createDoorForNeighbor('N', room.neighbors['N'], dX, dY, doorWidth, doorDepth);
      }
      if (room.neighbors['S']) {
        const dX = worldX + (room.width - doorWidth) / 2;
        const dY = worldY + room.height;
        createDoorForNeighbor('S', room.neighbors['S'], dX, dY, doorWidth, doorDepth);
      }
      if (room.neighbors['W']) {
        const dX = worldX - doorDepth;
        const dY = worldY + (room.height - doorWidth) / 2;
        createDoorForNeighbor('W', room.neighbors['W'], dX, dY, doorDepth, doorWidth);
      }
      if (room.neighbors['E']) {
        const dX = worldX + room.width;
        const dY = worldY + (room.height - doorWidth) / 2;
        createDoorForNeighbor('E', room.neighbors['E'], dX, dY, doorDepth, doorWidth);
      }

      if (room.type === RoomType.COMBAT) {
        room.pillars = [
          { x: worldX + room.width * 0.28, y: worldY + room.height * 0.3, radius: 24 },
          { x: worldX + room.width * 0.72, y: worldY + room.height * 0.3, radius: 24 },
          { x: worldX + room.width * 0.28, y: worldY + room.height * 0.7, radius: 24 },
          { x: worldX + room.width * 0.72, y: worldY + room.height * 0.7, radius: 24 }
        ];

        // Procedural traps for combat rooms
        room.traps = [];
        const trapLayoutChoice = Math.floor(Math.random() * 4);

        if (trapLayoutChoice === 0) {
          // Central spike cluster
          room.traps.push(new SpikeTrap(worldX + room.width * 0.5 - 56, worldY + room.height * 0.5 - 26, 52, 52));
          room.traps.push(new SpikeTrap(worldX + room.width * 0.5 + 4, worldY + room.height * 0.5 - 26, 52, 52));
        } else if (trapLayoutChoice === 1) {
          // Flame vents
          room.traps.push(new FlameVent(worldX + room.width * 0.5, worldY + room.height * 0.26, 22));
          room.traps.push(new FlameVent(worldX + room.width * 0.5, worldY + room.height * 0.74, 22));
          if (floorNumber >= 3) {
            room.traps.push(new FlameVent(worldX + room.width * 0.5, worldY + room.height * 0.5, 22));
          }
        } else if (trapLayoutChoice === 2 && floorNumber >= 2) {
          // Moving Sawblade track
          if (Math.random() < 0.5) {
            room.traps.push(new SawbladeTrap(
              worldX + room.width * 0.34,
              worldY + room.height * 0.5,
              worldX + room.width * 0.66,
              worldY + room.height * 0.5,
              120 + floorNumber * 10
            ));
          } else {
            room.traps.push(new SawbladeTrap(
              worldX + room.width * 0.5,
              worldY + room.height * 0.34,
              worldX + room.width * 0.5,
              worldY + room.height * 0.66,
              120 + floorNumber * 10
            ));
          }
        } else if (trapLayoutChoice === 3 && floorNumber >= 3) {
          // Combined danger: spikes and central flame vent
          room.traps.push(new SpikeTrap(worldX + room.width * 0.38, worldY + room.height * 0.5 - 26, 52, 52));
          room.traps.push(new SpikeTrap(worldX + room.width * 0.62 - 52, worldY + room.height * 0.5 - 26, 52, 52));
          room.traps.push(new FlameVent(worldX + room.width * 0.5, worldY + room.height * 0.5, 24));
        }
      } else if (room.type === RoomType.BOSS) {
        room.pillars = [
          { x: worldX + room.width * 0.2, y: worldY + room.height * 0.5, radius: 30 },
          { x: worldX + room.width * 0.8, y: worldY + room.height * 0.5, radius: 30 }
        ];
      } else if (room.type === RoomType.CHEST) {
        room.chest = new Chest(worldX + room.width / 2, worldY + room.height / 2);
      } else if (room.type === RoomType.ELEVATOR) {
        // Place Elevator inside the chamber!
        room.elevator = new Elevator(worldX + room.width / 2, worldY + room.height / 2);
      }
    });

    return {
      rooms,
      startRoom,
      bossRoom,
      chestRoom,
      elevatorRoom,
      grid
    };
  }
}
