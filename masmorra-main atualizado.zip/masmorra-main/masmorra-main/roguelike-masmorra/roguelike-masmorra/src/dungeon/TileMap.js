// Renders dungeon floors, walls, corridors, doors, torches, and pillars
export class DungeonRenderer {
  constructor() {
    this.torchTimer = 0;
  }

  update(dt) {
    this.torchTimer += dt * 4;
  }

  getFloorTheme(floorNumber) {
    switch (floorNumber) {
      case 1:
        return {
          floor: '#161922',
          floorGrid: '#1b202c',
          wall: '#2c3345',
          wallTop: '#3d475f',
          accent: '#ffcc00',
          torch: 'rgba(255, 180, 50, 0.15)'
        };
      case 2:
        return {
          floor: '#26201a',
          floorGrid: '#312a22',
          wall: '#4a3b2b',
          wallTop: '#5e4c38',
          accent: '#e69900',
          torch: 'rgba(255, 150, 30, 0.15)'
        };
      case 3:
        return {
          floor: '#131b26',
          floorGrid: '#192433',
          wall: '#263b52',
          wallTop: '#375475',
          accent: '#00ddff',
          torch: 'rgba(50, 200, 255, 0.15)'
        };
      case 4:
        return {
          floor: '#241217',
          floorGrid: '#2e181e',
          wall: '#4a1e27',
          wallTop: '#662734',
          accent: '#ff3344',
          torch: 'rgba(255, 50, 80, 0.18)'
        };
      case 5:
        return {
          floor: '#1f130b',
          floorGrid: '#291b10',
          wall: '#4a2c14',
          wallTop: '#693e1b',
          accent: '#ffaa00',
          torch: 'rgba(255, 120, 0, 0.2)'
        };
      case 6:
        // O Cume Tempestuoso do Olimpo (Zeus): Mármore tempestuoso e relâmpagos celestiais
        return {
          floor: '#151c2c',
          floorGrid: '#1e293b',
          wall: '#334155',
          wallTop: '#64748b',
          accent: '#38bdf8',
          torch: 'rgba(56, 189, 248, 0.26)'
        };
      case 7:
      default:
        // O Vazio Cósmico de Cronos (Cronos): Obsidiana astral e nébula violeta
        return {
          floor: '#110c1f',
          floorGrid: '#1a1330',
          wall: '#2e1847',
          wallTop: '#581c87',
          accent: '#c084fc',
          torch: 'rgba(192, 132, 252, 0.28)'
        };
    }
  }

  render(ctx, dungeon, floorNumber, player) {
    const theme = this.getFloorTheme(floorNumber);
    const flicker = Math.sin(this.torchTimer) * 0.15 + 0.85;

    // 1. Render Corridors between rooms
    dungeon.rooms.forEach(room => {
      // Draw corridors to East and South to avoid duplicate lines
      if (room.neighbors['E']) {
        const nextRoom = room.neighbors['E'];
        const corridorX = room.x + room.width;
        const corridorY = room.y + (room.height - 100) / 2;
        const corridorW = nextRoom.x - corridorX;
        const corridorH = 100;

        ctx.fillStyle = theme.floor;
        ctx.fillRect(corridorX, corridorY, corridorW, corridorH);

        // Corridor walls
        ctx.fillStyle = theme.wall;
        ctx.fillRect(corridorX, corridorY - 14, corridorW, 14);
        ctx.fillRect(corridorX, corridorY + corridorH, corridorW, 14);
      }

      if (room.neighbors['S']) {
        const nextRoom = room.neighbors['S'];
        const corridorX = room.x + (room.width - 100) / 2;
        const corridorY = room.y + room.height;
        const corridorW = 100;
        const corridorH = nextRoom.y - corridorY;

        ctx.fillStyle = theme.floor;
        ctx.fillRect(corridorX, corridorY, corridorW, corridorH);

        // Corridor walls
        ctx.fillStyle = theme.wall;
        ctx.fillRect(corridorX - 14, corridorY, 14, corridorH);
        ctx.fillRect(corridorX + corridorW, corridorY, 14, corridorH);
      }
    });

    // 2. Render Rooms
    dungeon.rooms.forEach(room => {
      // Room floor
      ctx.fillStyle = theme.floor;
      ctx.fillRect(room.x, room.y, room.width, room.height);

      // Floor grid tiles
      ctx.strokeStyle = theme.floorGrid;
      ctx.lineWidth = 1;
      const tileSize = 48;
      for (let x = room.x; x < room.x + room.width; x += tileSize) {
        ctx.beginPath();
        ctx.moveTo(x, room.y);
        ctx.lineTo(x, room.y + room.height);
        ctx.stroke();
      }
      for (let y = room.y; y < room.y + room.height; y += tileSize) {
        ctx.beginPath();
        ctx.moveTo(room.x, y);
        ctx.lineTo(room.x + room.width, y);
        ctx.stroke();
      }

      // Room Walls
      const wallThickness = 24;
      ctx.fillStyle = theme.wall;
      // Top wall
      ctx.fillRect(room.x, room.y - wallThickness, room.width, wallThickness);
      // Bottom wall
      ctx.fillRect(room.x, room.y + room.height, room.width, wallThickness);
      // Left wall
      ctx.fillRect(room.x - wallThickness, room.y, wallThickness, room.height);
      // Right wall
      ctx.fillRect(room.x + room.width, room.y, wallThickness, room.height);

      // Wall tops (highlight)
      ctx.fillStyle = theme.wallTop;
      ctx.fillRect(room.x, room.y - wallThickness, room.width, 6);
      ctx.fillRect(room.x, room.y + room.height + wallThickness - 6, room.width, 6);
      ctx.fillRect(room.x - wallThickness, room.y, 6, room.height);
      ctx.fillRect(room.x + room.width + wallThickness - 6, room.y, 6, room.height);

      // Wall Torches
      const torchOffsets = [
        { x: room.x + 80, y: room.y + 4 },
        { x: room.x + room.width - 80, y: room.y + 4 },
        { x: room.x + 80, y: room.y + room.height - 4 },
        { x: room.x + room.width - 80, y: room.y + room.height - 4 }
      ];

      torchOffsets.forEach(t => {
        // Torch light glow
        const glow = ctx.createRadialGradient(t.x, t.y, 5, t.x, t.y, 90 * flicker);
        glow.addColorStop(0, theme.torch);
        glow.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(t.x, t.y, 90 * flicker, 0, Math.PI * 2);
        ctx.fill();

        // Flame point
        ctx.fillStyle = '#ffcc00';
        ctx.beginPath();
        ctx.arc(t.x, t.y, 4, 0, Math.PI * 2);
        ctx.fill();
      });

      // Cover Pillars
      if (room.pillars) {
        room.pillars.forEach(p => {
          // Shadow
          ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
          ctx.beginPath();
          ctx.ellipse(p.x, p.y + 6, p.radius, p.radius * 0.7, 0, 0, Math.PI * 2);
          ctx.fill();

          // Pillar Body
          ctx.fillStyle = theme.wall;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
          ctx.fill();

          // Pillar Cap
          ctx.fillStyle = theme.wallTop;
          ctx.beginPath();
          ctx.arc(p.x, p.y - 4, p.radius * 0.85, 0, Math.PI * 2);
          ctx.fill();

          // Golden emblem on pillar
          ctx.strokeStyle = theme.accent;
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(p.x, p.y - 4, p.radius * 0.4, 0, Math.PI * 2);
          ctx.stroke();
        });
      }

      // Render Chest
      if (room.chest) {
        room.chest.render(ctx);
      }

      // Render Portal
      if (room.portal) {
        room.portal.render(ctx);
      }

      // Render Elevator (The exit chamber structure!)
      if (room.elevator) {
        room.elevator.render(ctx);
      }

      // Render Doors
      room.doors.forEach(door => {
        if (door.isBossExitGate) {
          // Special Grand Boss Exit Gate
          if (door.isLocked) {
            // Heavily sealed golden skull gate
            ctx.fillStyle = '#2d0f15';
            ctx.fillRect(door.x - 4, door.y - 4, door.width + 8, door.height + 8);

            ctx.strokeStyle = '#ff0033';
            ctx.lineWidth = 4;
            ctx.strokeRect(door.x, door.y, door.width, door.height);

            // Red warning runes
            ctx.fillStyle = '#ff3344';
            ctx.font = "bold 9px 'Press Start 2P', monospace";
            ctx.textAlign = 'center';
            ctx.fillText('SELADO', door.x + door.width / 2, door.y + door.height / 2 + 3);
          } else {
            // Gate is OPEN! Green beacon shining through
            ctx.fillStyle = 'rgba(0, 255, 170, 0.35)';
            ctx.fillRect(door.x - 10, door.y - 10, door.width + 20, door.height + 20);

            ctx.strokeStyle = '#00ffaa';
            ctx.lineWidth = 3;
            ctx.strokeRect(door.x, door.y, door.width, door.height);

            ctx.fillStyle = '#00ffaa';
            ctx.font = "bold 9px 'Press Start 2P', monospace";
            ctx.textAlign = 'center';
            ctx.fillText('ABERTO', door.x + door.width / 2, door.y + door.height / 2 + 3);
          }
          return;
        }

        if (door.isLocked) {
          // Locked Portcullis (Red glowing iron bars)
          ctx.fillStyle = 'rgba(255, 51, 68, 0.85)';
          ctx.fillRect(door.x, door.y, door.width, door.height);

          ctx.strokeStyle = '#ff0022';
          ctx.lineWidth = 3;
          ctx.shadowBlur = 8;
          ctx.shadowColor = '#ff0022';

          if (door.dir === 'N' || door.dir === 'S') {
            for (let bx = door.x + 8; bx < door.x + door.width; bx += 14) {
              ctx.beginPath();
              ctx.moveTo(bx, door.y);
              ctx.lineTo(bx, door.y + door.height);
              ctx.stroke();
            }
          } else {
            for (let by = door.y + 8; by < door.y + door.height; by += 14) {
              ctx.beginPath();
              ctx.moveTo(door.x, by);
              ctx.lineTo(door.x + door.width, by);
              ctx.stroke();
            }
          }
          ctx.shadowBlur = 0;
        } else {
          // Open Door archway
          ctx.fillStyle = theme.floor;
          ctx.fillRect(door.x, door.y, door.width, door.height);
        }
      });
    });
  }
}
