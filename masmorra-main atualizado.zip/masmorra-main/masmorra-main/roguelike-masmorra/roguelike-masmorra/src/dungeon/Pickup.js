// Collectible Pickups: Health Crates and Ammo Crates
export const PickupType = {
  HEALTH: 'health',
  AMMO: 'ammo'
};

export class Pickup {
  constructor(x, y, type = PickupType.HEALTH) {
    this.x = x;
    this.y = y;
    this.type = type;
    this.radius = 16;
    this.timer = Math.random() * Math.PI * 2;
    this.isCollected = false;

    // Slight drift on spawn
    this.vx = (Math.random() - 0.5) * 40;
    this.vy = (Math.random() - 0.5) * 40;
  }

  update(dt, player, audio, particles, ui) {
    if (this.isCollected || !player || player.isDead) return;

    this.timer += dt * 4;

    // Friction for initial spawn drift
    this.x += this.vx * dt;
    this.y += this.vy * dt;
    this.vx *= Math.max(0, 1 - 6 * dt);
    this.vy *= Math.max(0, 1 - 6 * dt);

    const dist = Math.hypot(player.x - this.x, player.y - this.y);

    // Magnetic pull when player gets close
    if (dist < 85 && dist > 0.001) {
      const pullSpeed = (85 - dist) * 4.5;
      this.x += ((player.x - this.x) / dist) * pullSpeed * dt;
      this.y += ((player.y - this.y) / dist) * pullSpeed * dt;
    }

    // Collection collision
    if (dist < (this.radius + player.radius + 6)) {
      this.collect(player, audio, particles, ui);
    }
  }

  collect(player, audio, particles, ui) {
    if (this.type === PickupType.HEALTH) {
      // Heal player
      if (player.health >= player.maxHealth) {
        // Already full health: gives 5 bonus gold coins!
        player.coins += 5;
        this.isCollected = true;
        if (audio) audio.playHit();
        if (particles) {
          particles.createHitSparks(this.x, this.y, '#ffd700');
          particles.createDamageText(player.x, player.y - 14, '+5 🪙', false);
        }
        if (ui) ui.showToast('Vida Cheia! +5 Moedas de Bônus!');
      } else {
        const healAmount = Math.min(2, player.maxHealth - player.health);
        player.health += healAmount;
        this.isCollected = true;
        if (audio) audio.playChestOpen();
        if (particles) {
          particles.createShockwave(this.x, this.y, 40, '#22c55e', 140);
          particles.createHitSparks(this.x, this.y, '#4ade80');
          particles.createDamageText(player.x, player.y - 14, `+${healAmount} HP ❤️`, false);
        }
        if (ui) ui.showToast(`Caixa de Vida Coletada! (+${healAmount} HP)`);
      }
    } else if (this.type === PickupType.AMMO) {
      // Find weapon that needs ammo (non-infinite weapon)
      const needAmmoWeapon = player.weapons.find(w => w.def.maxAmmo !== Infinity && w.reserveAmmo < w.def.maxAmmo);

      if (needAmmoWeapon) {
        const refill = Math.ceil(needAmmoWeapon.def.maxAmmo * 0.5); // Refills 50% max ammo
        needAmmoWeapon.reserveAmmo = Math.min(needAmmoWeapon.def.maxAmmo, needAmmoWeapon.reserveAmmo + refill);
        this.isCollected = true;
        if (audio) audio.playReload();
        if (particles) {
          particles.createShockwave(this.x, this.y, 40, '#f59e0b', 140);
          particles.createHitSparks(this.x, this.y, '#fbbf24');
          particles.createDamageText(player.x, player.y - 14, '+MUNIÇÃO! ⚡', false);
        }
        if (ui) ui.showToast(`Munição Restaurada: +${refill} para ${needAmmoWeapon.name}!`);
      } else {
        // If all weapons have full ammo or only pistol
        const anyLimited = player.weapons.find(w => w.def.maxAmmo !== Infinity);
        if (anyLimited) {
          // Already full
          player.coins += 4;
          this.isCollected = true;
          if (audio) audio.playReload();
          if (ui) ui.showToast('Munição Cheia! +4 Moedas!');
        } else {
          // Only starter pistol: store as bonus coins
          player.coins += 4;
          this.isCollected = true;
          if (audio) audio.playReload();
          if (ui) ui.showToast('Caixa de Munição Coletada! +4 Moedas!');
        }
      }
    }
  }

  render(ctx) {
    if (this.isCollected) return;

    ctx.save();
    const bobbingY = Math.sin(this.timer) * 3;
    ctx.translate(this.x, this.y + bobbingY);

    if (this.type === PickupType.HEALTH) {
      // --- CAIXA DE VIDA (MEDKIT) ---
      // Crimson / Emerald Shadow Glow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
      ctx.beginPath();
      ctx.ellipse(0, 14 - bobbingY, 14, 6, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.shadowBlur = 12;
      ctx.shadowColor = '#22c55e';

      // White Medkit Box with Green Border
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(-13, -10, 26, 20);

      ctx.strokeStyle = '#22c55e';
      ctx.lineWidth = 2;
      ctx.strokeRect(-13, -10, 26, 20);

      // Handle on top
      ctx.fillStyle = '#64748b';
      ctx.fillRect(-5, -14, 10, 4);

      // Red / Green Medical Cross in center
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(-3, -7, 6, 14);
      ctx.fillRect(-7, -3, 14, 6);

      ctx.shadowBlur = 0;
    } else if (this.type === PickupType.AMMO) {
      // --- CAIXA DE MUNIÇÃO (AMMO CRATE) ---
      // Amber Shadow Glow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
      ctx.beginPath();
      ctx.ellipse(0, 14 - bobbingY, 15, 6, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.shadowBlur = 12;
      ctx.shadowColor = '#f59e0b';

      // Olive Drab Military Ammo Case
      ctx.fillStyle = '#166534';
      ctx.fillRect(-14, -11, 28, 22);

      ctx.strokeStyle = '#eab308';
      ctx.lineWidth = 2;
      ctx.strokeRect(-14, -11, 28, 22);

      // Steel latches
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(-12, -8, 4, 16);
      ctx.fillRect(8, -8, 4, 16);

      // Golden Bullet Belt emblem in center
      ctx.fillStyle = '#fbbf24';
      for (let b = -2; b <= 2; b++) {
        ctx.fillRect(b * 4 - 1.5, -4, 3, 8);
        ctx.fillStyle = '#d97706';
        ctx.fillRect(b * 4 - 1.5, -6, 3, 2);
        ctx.fillStyle = '#fbbf24';
      }

      ctx.shadowBlur = 0;
    }

    ctx.restore();
  }
}
