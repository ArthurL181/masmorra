// Bullet and projectile mechanics for player and enemies
export class Bullet {
  constructor({
    x,
    y,
    vx,
    vy,
    damage = 20,
    radius = 5,
    isPlayer = true,
    color = '#ffcc00',
    type = 'normal',
    lifetime = 3.0,
    bounces = 0,
    pierce = 1,
    homing = false,
    target = null
  }) {
    this.x = x;
    this.y = y;
    this.vx = vx;
    this.vy = vy;
    this.damage = damage;
    this.radius = radius;
    this.isPlayer = isPlayer;
    this.color = color;
    this.type = type;
    this.lifetime = lifetime;
    this.remainingLifetime = lifetime;
    this.bounces = bounces;
    this.pierce = pierce;
    this.homing = homing;
    this.target = target;
    this.markedForDeletion = false;

    // Trail history for motion blur / laser lines
    this.trail = [];
    this.maxTrail = 4;
  }

  update(dt, particles) {
    this.remainingLifetime -= dt;
    if (this.remainingLifetime <= 0) {
      this.markedForDeletion = true;
      return;
    }

    // Save trail point
    this.trail.unshift({ x: this.x, y: this.y });
    if (this.trail.length > this.maxTrail) {
      this.trail.pop();
    }

    // Homing behavior
    if (this.homing && this.target && !this.target.isDead) {
      const angleToTarget = Math.atan2(this.target.y - this.y, this.target.x - this.x);
      const currentAngle = Math.atan2(this.vy, this.vx);
      const speed = Math.hypot(this.vx, this.vy);

      // Smooth turn toward target
      let diff = angleToTarget - currentAngle;
      while (diff < -Math.PI) diff += Math.PI * 2;
      while (diff > Math.PI) diff -= Math.PI * 2;

      const newAngle = currentAngle + Math.sign(diff) * Math.min(Math.abs(diff), 4.5 * dt);
      this.vx = Math.cos(newAngle) * speed;
      this.vy = Math.sin(newAngle) * speed;
    }

    // Move
    this.x += this.vx * dt;
    this.y += this.vy * dt;

    // Rocket smoke particles
    if (this.type === 'rocket' && particles && Math.random() < 0.6) {
      particles.createSmoke(this.x, this.y, 4, '#888888');
    }
  }

  render(ctx) {
    ctx.save();

    // Render trail
    if (this.trail.length > 1) {
      ctx.beginPath();
      ctx.moveTo(this.trail[0].x, this.trail[0].y);
      for (let i = 1; i < this.trail.length; i++) {
        ctx.lineTo(this.trail[i].x, this.trail[i].y);
      }
      ctx.strokeStyle = this.color;
      ctx.globalAlpha = 0.4;
      ctx.lineWidth = this.radius * 1.5;
      ctx.stroke();
      ctx.globalAlpha = 1.0;
    }

    // Main Bullet Body
    ctx.shadowBlur = 8;
    ctx.shadowColor = this.color;

    if (this.type === 'sniper') {
      // Piercing beam projectile
      const angle = Math.atan2(this.vy, this.vx);
      ctx.translate(this.x, this.y);
      ctx.rotate(angle);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(-16, -2, 32, 4);
      ctx.fillStyle = this.color;
      ctx.fillRect(-12, -4, 24, 8);
    } else if (this.type === 'rocket' || this.type === 'enemy_rocket') {
      // Missile shape
      const angle = Math.atan2(this.vy, this.vx);
      ctx.translate(this.x, this.y);
      ctx.rotate(angle);
      ctx.fillStyle = this.color;
      ctx.beginPath();
      ctx.moveTo(12, 0);
      ctx.lineTo(-10, -6);
      ctx.lineTo(-6, 0);
      ctx.lineTo(-10, 6);
      ctx.closePath();
      ctx.fill();
    } else {
      // Glowing orb bullet (classic Gungeon bullet hell look)
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
      ctx.fillStyle = this.color;
      ctx.fill();

      // Bright white inner core
      ctx.beginPath();
      ctx.arc(this.x, this.y, Math.max(1.5, this.radius * 0.45), 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
    }

    ctx.restore();
  }
}
