// Particle System for impacts, muzzle flash, brass shells, blood, dust and damage numbers
export class ParticleSystem {
  constructor() {
    this.particles = [];
    this.shells = [];
    this.floatingTexts = [];
    this.shockwaves = [];
  }

  update(dt) {
    // 1. Update general particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.particles.splice(i, 1);
        continue;
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vx *= (1 - p.friction * dt);
      p.vy *= (1 - p.friction * dt);
      if (p.gravity) p.vy += p.gravity * dt;
    }

    // 2. Update brass shells
    for (let i = this.shells.length - 1; i >= 0; i--) {
      const s = this.shells[i];
      s.life -= dt;
      if (s.life <= 0) {
        this.shells.splice(i, 1);
        continue;
      }
      if (s.z > 0) {
        s.x += s.vx * dt;
        s.y += s.vy * dt;
        s.z += s.vz * dt;
        s.vz -= 450 * dt; // gravity
        s.angle += s.vAngle * dt;

        if (s.z <= 0) {
          s.z = 0;
          s.vz = -s.vz * 0.45; // bounce
          s.vx *= 0.5;
          s.vy *= 0.5;
        }
      }
    }

    // 3. Update floating damage numbers
    for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
      const ft = this.floatingTexts[i];
      ft.life -= dt;
      if (ft.life <= 0) {
        this.floatingTexts.splice(i, 1);
        continue;
      }
      ft.y -= 45 * dt;
    }

    // 4. Update shockwaves
    for (let i = this.shockwaves.length - 1; i >= 0; i--) {
      const sw = this.shockwaves[i];
      sw.radius += sw.speed * dt;
      sw.life -= dt;
      if (sw.life <= 0) {
        this.shockwaves.splice(i, 1);
      }
    }
  }

  createMuzzleFlash(x, y, angle) {
    for (let i = 0; i < 5; i++) {
      const spread = (Math.random() - 0.5) * 0.8;
      const speed = 120 + Math.random() * 100;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle + spread) * speed,
        vy: Math.sin(angle + spread) * speed,
        size: 3 + Math.random() * 3,
        color: Math.random() < 0.5 ? '#ffff88' : '#ffaa00',
        life: 0.08 + Math.random() * 0.05,
        maxLife: 0.13,
        friction: 2.0,
        gravity: 0
      });
    }
  }

  createShell(x, y, shootAngle) {
    const ejectAngle = shootAngle + Math.PI / 2 + (Math.random() - 0.5) * 0.4;
    const speed = 70 + Math.random() * 50;
    this.shells.push({
      x,
      y,
      z: 12,
      vx: Math.cos(ejectAngle) * speed,
      vy: Math.sin(ejectAngle) * speed,
      vz: 80 + Math.random() * 50,
      angle: Math.random() * Math.PI * 2,
      vAngle: (Math.random() - 0.5) * 20,
      life: 5.0,
      color: '#d4af37'
    });
  }

  createHitSparks(x, y, color = '#ffcc00') {
    for (let i = 0; i < 8; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 80 + Math.random() * 140;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: 2 + Math.random() * 3,
        color,
        life: 0.2 + Math.random() * 0.2,
        maxLife: 0.4,
        friction: 4.0,
        gravity: 0
      });
    }
  }

  createBlood(x, y, count = 10, color = '#ff2233') {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 50 + Math.random() * 150;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: 3 + Math.random() * 4,
        color,
        life: 0.3 + Math.random() * 0.3,
        maxLife: 0.6,
        friction: 3.5,
        gravity: 80
      });
    }
  }

  createDust(x, y, count = 6) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 25 + Math.random() * 50;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: 4 + Math.random() * 5,
        color: 'rgba(180, 180, 190, 0.4)',
        life: 0.25 + Math.random() * 0.2,
        maxLife: 0.45,
        friction: 2.0,
        gravity: -10
      });
    }
  }

  createSmoke(x, y, size = 6, color = '#888888') {
    this.particles.push({
      x,
      y,
      vx: (Math.random() - 0.5) * 30,
      vy: (Math.random() - 0.5) * 30,
      size,
      color,
      life: 0.4,
      maxLife: 0.4,
      friction: 1.5,
      gravity: -20
    });
  }

  createExplosion(x, y, radius = 60) {
    // Blast shockwave
    this.createShockwave(x, y, radius * 2, '#ff6600', 400);

    // Fire & debris particles
    for (let i = 0; i < 30; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 100 + Math.random() * 250;
      const colors = ['#ffffff', '#ffee33', '#ff6600', '#ff2200', '#555555'];
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: 4 + Math.random() * 8,
        color: colors[Math.floor(Math.random() * colors.length)],
        life: 0.35 + Math.random() * 0.35,
        maxLife: 0.7,
        friction: 3.0,
        gravity: 20
      });
    }
  }

  createShockwave(x, y, maxRadius = 180, color = '#ffffff', speed = 600) {
    this.shockwaves.push({
      x,
      y,
      radius: 10,
      maxRadius,
      speed,
      color,
      life: maxRadius / speed,
      maxLife: maxRadius / speed
    });
  }

  createDamageText(x, y, text, isCrit = false) {
    this.floatingTexts.push({
      x: x + (Math.random() - 0.5) * 16,
      y: y - 10,
      text: String(text),
      isCrit,
      life: 0.7,
      maxLife: 0.7
    });
  }

  render(ctx) {
    // 1. Render shells on floor
    this.shells.forEach(s => {
      ctx.save();
      ctx.translate(s.x, s.y - s.z);
      ctx.rotate(s.angle);
      ctx.fillStyle = s.color;
      ctx.fillRect(-3, -1.5, 6, 3);
      ctx.restore();
    });

    // 2. Render shockwaves
    this.shockwaves.forEach(sw => {
      ctx.save();
      const alpha = Math.max(0, sw.life / sw.maxLife);
      ctx.beginPath();
      ctx.arc(sw.x, sw.y, sw.radius, 0, Math.PI * 2);
      ctx.strokeStyle = sw.color;
      ctx.lineWidth = 4 * alpha;
      ctx.globalAlpha = alpha;
      ctx.stroke();
      ctx.restore();
    });

    // 3. Render particles
    this.particles.forEach(p => {
      ctx.save();
      const alpha = Math.max(0, p.life / p.maxLife);
      ctx.globalAlpha = alpha;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    });

    // 4. Render damage numbers
    this.floatingTexts.forEach(ft => {
      ctx.save();
      const alpha = Math.max(0, ft.life / ft.maxLife);
      ctx.globalAlpha = alpha;
      ctx.font = ft.isCrit ? "bold 16px 'Press Start 2P', monospace" : "bold 13px 'Rajdhani', sans-serif";
      ctx.fillStyle = ft.isCrit ? '#ffcc00' : '#ffffff';
      ctx.shadowBlur = 4;
      ctx.shadowColor = ft.isCrit ? '#ff3300' : '#000000';
      ctx.textAlign = 'center';
      ctx.fillText(ft.text, ft.x, ft.y);
      ctx.restore();
    });
  }
}
