import { Entity } from './Entity.js';
import { Bullet } from '../combat/Bullet.js';

export class Boss extends Entity {
  constructor(x, y, floorNumber) {
    let name = 'Minotauro de Creta';
    let subtitle = 'O Guardião do Labirinto';
    let health = 600;
    let radius = 34;

    if (floorNumber === 2) {
      name = 'Anúbis';
      subtitle = 'O Juiz das Almas';
      health = 900;
      radius = 32;
    } else if (floorNumber === 3) {
      name = 'Fenrir';
      subtitle = 'O Devorador de Deuses';
      health = 1300;
      radius = 36;
    } else if (floorNumber === 4) {
      name = 'Hades';
      subtitle = 'O Lorde do Submundo';
      health = 1800;
      radius = 35;
    } else if (floorNumber === 5) {
      name = 'Fáfnir, o Dragão Ancião';
      subtitle = 'Senhor do Ouro e do Caos';
      health = 2600;
      radius = 55;
    } else if (floorNumber === 6) {
      name = 'Zeus, o Soberano dos Raios';
      subtitle = 'O Rei do Monte Olimpo';
      health = 3500;
      radius = 40;
    } else if (floorNumber >= 7) {
      name = 'Cronos, o Titã do Tempo e Caos';
      subtitle = 'O Devorador de Éons';
      health = 4600;
      radius = 48;
    }

    super(x, y, radius, health);
    this.floorNumber = floorNumber;
    this.name = name;
    this.subtitle = subtitle;

    this.attackTimer = 2.0;
    this.attackPhase = 0;
    this.patternTimer = 0;
    this.isEnraged = false;
    this.chargeVx = 0;
    this.chargeVy = 0;
    this.isCharging = false;
    this.aimAngle = 0;
  }

  update(dt, player, bullets, audio, particles, camera) {
    if (this.isDead || !player || player.isDead) return;

    this.aimAngle = Math.atan2(player.y - this.y, player.x - this.x);
    this.patternTimer += dt;
    this.attackTimer -= dt;

    // Check enrage threshold at 40% HP
    if (!this.isEnraged && this.health <= this.maxHealth * 0.4) {
      this.isEnraged = true;
      if (audio) audio.playBossRoar();
      if (camera) camera.addTrauma(0.6);
      if (particles) particles.createExplosion(this.x, this.y, 80);
    }

    switch (this.floorNumber) {
      case 1:
        this.updateMinotaur(dt, player, bullets, audio, particles, camera);
        break;
      case 2:
        this.updateAnubis(dt, player, bullets, audio, particles, camera);
        break;
      case 3:
        this.updateFenrir(dt, player, bullets, audio, particles, camera);
        break;
      case 4:
        this.updateHades(dt, player, bullets, audio, particles, camera);
        break;
      case 5:
        this.updateFafnirDragon(dt, player, bullets, audio, particles, camera);
        break;
      case 6:
        this.updateZeus(dt, player, bullets, audio, particles, camera);
        break;
      case 7:
      default:
        this.updateCronos(dt, player, bullets, audio, particles, camera);
        break;
    }

    this.updatePhysics(dt);
  }

  // --- FLOOR 1: MINOTAUR (Greek) ---
  updateMinotaur(dt, player, bullets, audio, particles, camera) {
    const dist = Math.hypot(player.x - this.x, player.y - this.y);

    if (this.isCharging) {
      this.vx = this.chargeVx;
      this.vy = this.chargeVy;
      if (particles && Math.random() < 0.5) {
        particles.createDust(this.x, this.y, 4);
      }
      return;
    }

    // Maintain tactical arena distance (200px - 280px)
    const idealDist = 240;
    if (dist > idealDist + 40) {
      this.vx += Math.cos(this.aimAngle) * 95;
      this.vy += Math.sin(this.aimAngle) * 95;
    } else if (dist < idealDist - 40) {
      // Step back to keep breathing room
      this.vx -= Math.cos(this.aimAngle) * 85;
      this.vy -= Math.sin(this.aimAngle) * 85;
    } else {
      // Circle slightly to maintain combat distance
      this.vx += Math.cos(this.aimAngle + Math.PI / 2) * 30;
      this.vy += Math.sin(this.aimAngle + Math.PI / 2) * 30;
    }

    if (this.attackTimer <= 0) {
      this.attackPhase = (this.attackPhase + 1) % 3;
      const speedMult = this.isEnraged ? 1.3 : 1.0;

      if (this.attackPhase === 0) {
        // Shockwave Ring Stomp (creates space)
        this.attackTimer = 2.4 / speedMult;
        if (audio) audio.playExplosion();
        if (camera) camera.addTrauma(0.35);
        if (particles) particles.createShockwave(this.x, this.y, 180, '#ffaa00', 380);

        const count = this.isEnraged ? 18 : 12;
        for (let i = 0; i < count; i++) {
          const a = (i / count) * Math.PI * 2;
          bullets.push(new Bullet({
            x: this.x,
            y: this.y,
            vx: Math.cos(a) * 260 * speedMult,
            vy: Math.sin(a) * 260 * speedMult,
            damage: 1,
            radius: 7,
            isPlayer: false,
            color: '#ff8800',
            type: 'enemy_boss'
          }));
        }
      } else if (this.attackPhase === 1) {
        // Battle Axe Throws (3 spread projectile axes)
        this.attackTimer = 1.8 / speedMult;
        if (audio) audio.playShoot('shotgun');
        for (let i = -1; i <= 1; i++) {
          const a = this.aimAngle + i * 0.35;
          bullets.push(new Bullet({
            x: this.x,
            y: this.y,
            vx: Math.cos(a) * 380,
            vy: Math.sin(a) * 380,
            damage: 1,
            radius: 8,
            isPlayer: false,
            color: '#ff3344',
            type: 'enemy_boss'
          }));
        }
      } else {
        // Bull Charge Slam! Charges in locked straight line PAST player, then recovers
        this.attackTimer = 3.2 / speedMult;
        this.isCharging = true;
        const chargeAngle = this.aimAngle;
        this.chargeVx = Math.cos(chargeAngle) * 520;
        this.chargeVy = Math.sin(chargeAngle) * 520;
        if (audio) audio.playBossRoar();
        if (particles) particles.createDust(this.x, this.y, 10);

        setTimeout(() => {
          this.isCharging = false;
          this.vx = 0;
          this.vy = 0;
          if (camera) camera.addTrauma(0.3);
        }, 650);
      }
    }
  }

  // --- FLOOR 2: ANUBIS (Egyptian) ---
  updateAnubis(dt, player, bullets, audio, particles, camera) {
    // Floats around room in smooth circles
    this.vx += Math.cos(this.patternTimer * 1.5) * 60;
    this.vy += Math.sin(this.patternTimer * 1.5) * 60;

    if (this.attackTimer <= 0) {
      this.attackPhase = (this.attackPhase + 1) % 3;
      const speedMult = this.isEnraged ? 1.3 : 1.0;

      if (this.attackPhase === 0) {
        // Staff Concentric Spiral Vortex
        this.attackTimer = 2.8 / speedMult;
        if (audio) audio.playShoot('plasma');
        for (let i = 0; i < 16; i++) {
          const a = (i / 16) * Math.PI * 2 + this.patternTimer;
          bullets.push(new Bullet({
            x: this.x,
            y: this.y,
            vx: Math.cos(a) * 280,
            vy: Math.sin(a) * 280,
            damage: 1,
            radius: 6,
            isPlayer: false,
            color: '#b845ff',
            type: 'enemy_boss'
          }));
        }
      } else if (this.attackPhase === 1) {
        // Homing Shadow Jackals (3 homing energy orbs)
        this.attackTimer = 2.2 / speedMult;
        if (audio) audio.playShoot('rocket');
        for (let i = -1; i <= 1; i++) {
          const a = this.aimAngle + i * 0.4;
          bullets.push(new Bullet({
            x: this.x,
            y: this.y,
            vx: Math.cos(a) * 220,
            vy: Math.sin(a) * 220,
            damage: 1,
            radius: 8,
            isPlayer: false,
            color: '#e69900',
            type: 'enemy_rocket',
            homing: true,
            target: player,
            lifetime: 3.5
          }));
        }
      } else {
        // Staff Beam Sweep (laser barrage)
        this.attackTimer = 2.0 / speedMult;
        if (audio) audio.playShoot('smg');
        for (let i = -2; i <= 2; i++) {
          const a = this.aimAngle + i * 0.15;
          bullets.push(new Bullet({
            x: this.x,
            y: this.y,
            vx: Math.cos(a) * 500,
            vy: Math.sin(a) * 500,
            damage: 1,
            radius: 5,
            isPlayer: false,
            color: '#ffd700',
            type: 'enemy_boss'
          }));
        }
      }
    }
  }

  // --- FLOOR 3: FENRIR (Norse) ---
  updateFenrir(dt, player, bullets, audio, particles, camera) {
    this.vx += Math.cos(this.aimAngle) * 95;
    this.vy += Math.sin(this.aimAngle) * 95;

    if (this.attackTimer <= 0) {
      this.attackPhase = (this.attackPhase + 1) % 3;

      if (this.attackPhase === 0) {
        // Howling Ice Spiral
        this.attackTimer = 2.5;
        if (audio) audio.playBossRoar();
        if (camera) camera.addTrauma(0.3);
        for (let i = 0; i < 20; i++) {
          const a = (i / 20) * Math.PI * 2;
          bullets.push(new Bullet({
            x: this.x,
            y: this.y,
            vx: Math.cos(a) * 320,
            vy: Math.sin(a) * 320,
            damage: 1,
            radius: 6,
            isPlayer: false,
            color: '#00ffff',
            type: 'enemy_boss'
          }));
        }
      } else if (this.attackPhase === 1) {
        // Frost Claw Lunges (Double spread)
        this.attackTimer = 1.6;
        if (audio) audio.playShoot('shotgun');
        for (let i = -3; i <= 3; i++) {
          const a = this.aimAngle + i * 0.18;
          bullets.push(new Bullet({
            x: this.x,
            y: this.y,
            vx: Math.cos(a) * 440,
            vy: Math.sin(a) * 440,
            damage: 1,
            radius: 6,
            isPlayer: false,
            color: '#77e6ff',
            type: 'enemy_boss'
          }));
        }
      } else {
        // Frost Nova Explosion
        this.attackTimer = 2.2;
        if (audio) audio.playExplosion();
        if (particles) particles.createShockwave(this.x, this.y, 200, '#00ffff', 400);
        for (let i = 0; i < 14; i++) {
          const a = Math.random() * Math.PI * 2;
          const spd = 200 + Math.random() * 200;
          bullets.push(new Bullet({
            x: this.x,
            y: this.y,
            vx: Math.cos(a) * spd,
            vy: Math.sin(a) * spd,
            damage: 1,
            radius: 7,
            isPlayer: false,
            color: '#ffffff',
            type: 'enemy_boss'
          }));
        }
      }
    }
  }

  // --- FLOOR 4: HADES (Greek Underworld) ---
  updateHades(dt, player, bullets, audio, particles, camera) {
    this.vx += Math.cos(this.aimAngle) * 50;
    this.vy += Math.sin(this.aimAngle) * 50;

    if (this.attackTimer <= 0) {
      this.attackPhase = (this.attackPhase + 1) % 3;

      if (this.attackPhase === 0) {
        // Ring of Soul Fire
        this.attackTimer = 2.5;
        if (audio) audio.playShoot('plasma');
        for (let i = 0; i < 24; i++) {
          const a = (i / 24) * Math.PI * 2;
          bullets.push(new Bullet({
            x: this.x,
            y: this.y,
            vx: Math.cos(a) * 290,
            vy: Math.sin(a) * 290,
            damage: 1,
            radius: 7,
            isPlayer: false,
            color: '#ff0055',
            type: 'enemy_boss'
          }));
        }
      } else if (this.attackPhase === 1) {
        // Bident Blast (Focused crimson beams)
        this.attackTimer = 1.8;
        if (audio) audio.playShoot('sniper');
        for (let i = -1; i <= 1; i++) {
          const a = this.aimAngle + i * 0.12;
          bullets.push(new Bullet({
            x: this.x,
            y: this.y,
            vx: Math.cos(a) * 750,
            vy: Math.sin(a) * 750,
            damage: 1,
            radius: 8,
            isPlayer: false,
            color: '#ff2200',
            type: 'sniper'
          }));
        }
      } else {
        // Teleport Strike! (Vanishes in flames, reappears closer)
        this.attackTimer = 3.0;
        if (particles) particles.createExplosion(this.x, this.y, 60);
        if (audio) audio.playExplosion();

        // Reposition
        const angle = Math.random() * Math.PI * 2;
        this.x = player.x + Math.cos(angle) * 220;
        this.y = player.y + Math.sin(angle) * 220;

        if (particles) particles.createExplosion(this.x, this.y, 60);
        if (camera) camera.addTrauma(0.4);

        // Immediate radial retaliation burst
        for (let i = 0; i < 16; i++) {
          const a = (i / 16) * Math.PI * 2;
          bullets.push(new Bullet({
            x: this.x,
            y: this.y,
            vx: Math.cos(a) * 320,
            vy: Math.sin(a) * 320,
            damage: 1,
            radius: 6,
            isPlayer: false,
            color: '#aa00ff',
            type: 'enemy_boss'
          }));
        }
      }
    }
  }

  // --- FLOOR 5: FÁFNIR, THE MYTHOLOGICAL ANCIENT DRAGON (Final Boss) ---
  updateFafnirDragon(dt, player, bullets, audio, particles, camera) {
    // Draconic pacing
    this.vx += Math.cos(this.aimAngle) * 40;
    this.vy += Math.sin(this.aimAngle) * 40;

    // Wing flap shake
    if (Math.floor(this.patternTimer * 2) % 2 === 0 && Math.random() < 0.05) {
      if (camera) camera.addTrauma(0.1);
    }

    if (this.attackTimer <= 0) {
      this.attackPhase = (this.attackPhase + 1) % 4;

      if (this.attackPhase === 0) {
        // 1. Draconic Flamethrower Breath (Arc of fire bullets sweeping back and forth)
        this.attackTimer = 2.8;
        if (audio) audio.playShoot('shotgun');
        const sweepCenter = this.aimAngle;
        for (let i = 0; i < 14; i++) {
          const a = sweepCenter + ((i - 6.5) / 14) * 0.9;
          const spd = 360 + Math.random() * 80;
          bullets.push(new Bullet({
            x: this.x + Math.cos(a) * 40,
            y: this.y + Math.sin(a) * 40,
            vx: Math.cos(a) * spd,
            vy: Math.sin(a) * spd,
            damage: 1,
            radius: 7,
            isPlayer: false,
            color: '#ff3300',
            type: 'enemy_boss'
          }));
        }
      } else if (this.attackPhase === 1) {
        // 2. Meteor Shower (Clusters of explosive dragon orbs)
        this.attackTimer = 3.2;
        if (audio) audio.playBossRoar();
        if (camera) camera.addTrauma(0.5);

        for (let i = 0; i < 4; i++) {
          const offsetAngle = this.aimAngle + (Math.random() - 0.5) * 0.8;
          const rocket = new Bullet({
            x: this.x + Math.cos(offsetAngle) * 30,
            y: this.y + Math.sin(offsetAngle) * 30,
            vx: Math.cos(offsetAngle) * 280,
            vy: Math.sin(offsetAngle) * 280,
            damage: 1,
            radius: 11,
            isPlayer: false,
            color: '#ffaa00',
            type: 'enemy_rocket',
            lifetime: 1.8
          });

          rocket.onDetonate = (spawnList) => {
            if (particles) particles.createExplosion(rocket.x, rocket.y, 60);
            if (audio) audio.playExplosion();
            for (let j = 0; j < 8; j++) {
              const a = (j / 8) * Math.PI * 2;
              spawnList.push(new Bullet({
                x: rocket.x,
                y: rocket.y,
                vx: Math.cos(a) * 260,
                vy: Math.sin(a) * 260,
                damage: 1,
                radius: 6,
                isPlayer: false,
                color: '#ff4400',
                type: 'enemy_boss'
              }));
            }
          };

          bullets.push(rocket);
        }
      } else if (this.attackPhase === 2) {
        // 3. Wing Flap Gust Shockwave Ring
        this.attackTimer = 2.4;
        if (audio) audio.playExplosion();
        if (camera) camera.addTrauma(0.45);
        if (particles) particles.createShockwave(this.x, this.y, 250, '#ffcc00', 500);

        const count = 28; // Massive bullet hell ring!
        for (let i = 0; i < count; i++) {
          const a = (i / count) * Math.PI * 2;
          bullets.push(new Bullet({
            x: this.x,
            y: this.y,
            vx: Math.cos(a) * 300,
            vy: Math.sin(a) * 300,
            damage: 1,
            radius: 7,
            isPlayer: false,
            color: '#ffcc00',
            type: 'enemy_boss'
          }));
        }
      } else {
        // 4. Dragon's Desperation Spiral
        this.attackTimer = 2.5;
        if (audio) audio.playShoot('plasma');
        for (let i = 0; i < 18; i++) {
          const a = (i / 18) * Math.PI * 2 + this.patternTimer * 2;
          bullets.push(new Bullet({
            x: this.x,
            y: this.y,
            vx: Math.cos(a) * 380,
            vy: Math.sin(a) * 380,
            damage: 1,
            radius: 6,
            isPlayer: false,
            color: '#ff0033',
            type: 'enemy_boss'
          }));
        }
      }
    }
  }

  // --- FLOOR 6: ZEUS (Greek Sky God) ---
  updateZeus(dt, player, bullets, audio, particles, camera) {
    const dist = Math.hypot(player.x - this.x, player.y - this.y);
    const speedMult = this.isEnraged ? 1.35 : 1.0;

    // Tactical floating retreat & hover
    const idealDist = 260;
    if (dist > idealDist + 40) {
      this.vx += Math.cos(this.aimAngle) * 95;
      this.vy += Math.sin(this.aimAngle) * 95;
    } else if (dist < idealDist - 40) {
      this.vx -= Math.cos(this.aimAngle) * 90;
      this.vy -= Math.sin(this.aimAngle) * 90;
    } else {
      this.vx += Math.cos(this.aimAngle + Math.PI / 2) * 55;
      this.vy += Math.sin(this.aimAngle + Math.PI / 2) * 55;
    }

    if (particles && Math.random() < 0.3) {
      particles.createHitSparks(this.x + (Math.random() - 0.5) * 30, this.y + (Math.random() - 0.5) * 30, '#38bdf8');
    }

    if (this.attackTimer <= 0) {
      this.attackPhase = (this.attackPhase + 1) % 4;

      if (this.attackPhase === 0) {
        // 1. Lightning Barrage (5 high-speed electric bolts)
        this.attackTimer = 1.9 / speedMult;
        if (audio) audio.playShoot('plasma');
        if (camera) camera.addTrauma(0.25);
        for (let i = -2; i <= 2; i++) {
          const a = this.aimAngle + i * 0.16;
          bullets.push(new Bullet({
            x: this.x + Math.cos(a) * 25,
            y: this.y + Math.sin(a) * 25,
            vx: Math.cos(a) * 580 * speedMult,
            vy: Math.sin(a) * 580 * speedMult,
            damage: 1,
            radius: 7,
            isPlayer: false,
            color: '#38bdf8',
            type: 'sniper'
          }));
        }
      } else if (this.attackPhase === 1) {
        // 2. Storm Plasma Orbs (Expanding spiral nova)
        this.attackTimer = 2.4 / speedMult;
        if (audio) audio.playShoot('rocket');
        if (particles) particles.createShockwave(this.x, this.y, 200, '#38bdf8', 400);

        const count = this.isEnraged ? 18 : 12;
        for (let i = 0; i < count; i++) {
          const a = (i / count) * Math.PI * 2 + this.patternTimer;
          bullets.push(new Bullet({
            x: this.x,
            y: this.y,
            vx: Math.cos(a) * 300 * speedMult,
            vy: Math.sin(a) * 300 * speedMult,
            damage: 1,
            radius: 8,
            isPlayer: false,
            color: '#00eeff',
            type: 'enemy_boss'
          }));
        }
      } else if (this.attackPhase === 2) {
        // 3. Thunderbolts from the Heavens
        this.attackTimer = 2.8 / speedMult;
        if (audio) audio.playBossRoar();
        if (camera) camera.addTrauma(0.45);

        const strikePoints = [
          { x: player.x, y: player.y },
          { x: player.x + (Math.random() - 0.5) * 160, y: player.y + (Math.random() - 0.5) * 160 },
          { x: player.x + (Math.random() - 0.5) * 220, y: player.y + (Math.random() - 0.5) * 220 }
        ];

        strikePoints.forEach((sp, idx) => {
          setTimeout(() => {
            if (this.isDead) return;
            if (particles) {
              particles.createShockwave(sp.x, sp.y, 100, '#38bdf8', 500);
              particles.createExplosion(sp.x, sp.y, 45);
            }
            if (audio) audio.playExplosion();

            for (let b = 0; b < 6; b++) {
              const ba = (b / 6) * Math.PI * 2;
              bullets.push(new Bullet({
                x: sp.x,
                y: sp.y,
                vx: Math.cos(ba) * 240,
                vy: Math.sin(ba) * 240,
                damage: 1,
                radius: 6,
                isPlayer: false,
                color: '#facc15',
                type: 'enemy_pistol'
              }));
            }
          }, 350 + idx * 250);
        });
      } else {
        // 4. Overload Dash
        this.attackTimer = 2.6 / speedMult;
        const dashAngle = this.aimAngle;
        this.vx += Math.cos(dashAngle) * 380;
        this.vy += Math.sin(dashAngle) * 380;
        if (particles) particles.createDust(this.x, this.y, 10);
        if (audio) audio.playShoot('shotgun');

        for (let i = 0; i < 8; i++) {
          const a = dashAngle + (Math.random() - 0.5) * 0.9;
          bullets.push(new Bullet({
            x: this.x,
            y: this.y,
            vx: Math.cos(a) * 350,
            vy: Math.sin(a) * 350,
            damage: 1,
            radius: 6,
            isPlayer: false,
            color: '#38bdf8',
            type: 'enemy_smg'
          }));
        }
      }
    }
  }

  // --- FLOOR 7: CRONOS (Primordial Titan of Time and Chaos) ---
  updateCronos(dt, player, bullets, audio, particles, camera) {
    const dist = Math.hypot(player.x - this.x, player.y - this.y);
    const speedMult = this.isEnraged ? 1.4 : 1.0;

    // Menacing inexorable advance
    this.vx += Math.cos(this.aimAngle) * 60 * speedMult;
    this.vy += Math.sin(this.aimAngle) * 60 * speedMult;

    if (particles && Math.random() < 0.35) {
      particles.createSmoke(this.x + (Math.random() - 0.5) * 35, this.y + (Math.random() - 0.5) * 35, 4, '#581c87');
    }

    if (this.attackTimer <= 0) {
      this.attackPhase = (this.attackPhase + 1) % 4;

      if (this.attackPhase === 0) {
        // 1. Temporal Clock Distortion
        this.attackTimer = 2.6 / speedMult;
        if (audio) audio.playShoot('plasma');
        if (camera) camera.addTrauma(0.3);

        const count = 16;
        for (let i = 0; i < count; i++) {
          const a = (i / count) * Math.PI * 2;
          bullets.push(new Bullet({
            x: this.x,
            y: this.y,
            vx: Math.cos(a) * 260 * speedMult,
            vy: Math.sin(a) * 260 * speedMult,
            damage: 1,
            radius: 8,
            isPlayer: false,
            color: '#c084fc',
            type: 'enemy_boss'
          }));
        }
      } else if (this.attackPhase === 1) {
        // 2. Twin Scythe Slices
        this.attackTimer = 2.2 / speedMult;
        if (audio) audio.playShoot('shotgun');
        if (camera) camera.addTrauma(0.4);

        for (let side = -1; side <= 1; side += 2) {
          const sliceAngle = this.aimAngle + side * 0.45;
          for (let p = -3; p <= 3; p++) {
            const pa = sliceAngle + p * 0.08;
            bullets.push(new Bullet({
              x: this.x + Math.cos(pa) * 32,
              y: this.y + Math.sin(pa) * 32,
              vx: Math.cos(pa) * 440 * speedMult,
              vy: Math.sin(pa) * 440 * speedMult,
              damage: 1,
              radius: 7,
              isPlayer: false,
              color: '#e879f9',
              type: 'enemy_boss'
            }));
          }
        }
      } else if (this.attackPhase === 2) {
        // 3. Singularity Void Burst
        this.attackTimer = 3.0 / speedMult;
        if (audio) audio.playBossRoar();
        if (camera) camera.addTrauma(0.5);
        if (particles) particles.createShockwave(this.x, this.y, 280, '#c084fc', 480);

        const count = this.isEnraged ? 24 : 18;
        for (let i = 0; i < count; i++) {
          const a = (i / count) * Math.PI * 2 + Math.sin(this.patternTimer * 3);
          bullets.push(new Bullet({
            x: this.x + Math.cos(a) * 15,
            y: this.y + Math.sin(a) * 15,
            vx: Math.cos(a) * 320 * speedMult,
            vy: Math.sin(a) * 320 * speedMult,
            damage: 1,
            radius: 8,
            isPlayer: false,
            color: '#a855f7',
            type: 'enemy_boss'
          }));
        }
      } else {
        // 4. Chronos Paradox
        this.attackTimer = 3.2 / speedMult;
        if (audio) audio.playShoot('rocket');
        for (let i = 0; i < 20; i++) {
          const a = (i / 20) * Math.PI * 2;
          const a2 = -a;
          bullets.push(new Bullet({
            x: this.x,
            y: this.y,
            vx: Math.cos(a) * 360,
            vy: Math.sin(a) * 360,
            damage: 1,
            radius: 6,
            isPlayer: false,
            color: '#f43f5e',
            type: 'enemy_smg'
          }));
          bullets.push(new Bullet({
            x: this.x,
            y: this.y,
            vx: Math.cos(a2) * 220,
            vy: Math.sin(a2) * 220,
            damage: 1,
            radius: 6,
            isPlayer: false,
            color: '#c084fc',
            type: 'enemy_smg'
          }));
        }
      }
    }
  }

  render(ctx) {
    ctx.save();
    ctx.translate(this.x, this.y);

    // Hit flash
    if (this.flashTimer > 0) {
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(0, 0, this.radius + 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      return;
    }

    // Shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
    ctx.beginPath();
    ctx.ellipse(0, this.radius - 4, this.radius * 1.1, this.radius * 0.6, 0, 0, Math.PI * 2);
    ctx.fill();

    const isFacingLeft = Math.cos(this.aimAngle) < 0;

    switch (this.floorNumber) {
      case 1:
        // Minotaur (Greek): Horned beast in bronze gladiator harness
        ctx.fillStyle = '#6d4c2b';
        ctx.beginPath();
        ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
        ctx.fill();

        // Bull Horns
        ctx.fillStyle = '#e2e8f0';
        ctx.beginPath();
        ctx.moveTo(-24, -14);
        ctx.quadraticCurveTo(-38, -34, -18, -40);
        ctx.quadraticCurveTo(-22, -26, -14, -20);
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(24, -14);
        ctx.quadraticCurveTo(38, -34, 18, -40);
        ctx.quadraticCurveTo(22, -26, 14, -20);
        ctx.fill();

        // Bronze armor chestplate
        ctx.fillStyle = '#b45309';
        ctx.fillRect(-18, -8, 36, 22);

        // Glowing red bull eyes
        ctx.fillStyle = '#ff0033';
        ctx.shadowBlur = 6;
        ctx.shadowColor = '#ff0033';
        ctx.fillRect(isFacingLeft ? -14 : 2, -14, 6, 6);
        ctx.fillRect(isFacingLeft ? -2 : 10, -14, 6, 6);
        ctx.shadowBlur = 0;

        // Nose ring
        ctx.strokeStyle = '#ffd700';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(0, 8, 7, 0, Math.PI);
        ctx.stroke();
        break;

      case 2:
        // Anubis (Egyptian): Black jackal god with golden nemes headdress
        ctx.fillStyle = '#111827';
        ctx.beginPath();
        ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
        ctx.fill();

        // Jackal Ears
        ctx.fillStyle = '#111827';
        ctx.beginPath();
        ctx.moveTo(-20, -16);
        ctx.lineTo(-28, -46);
        ctx.lineTo(-8, -26);
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(20, -16);
        ctx.lineTo(28, -46);
        ctx.lineTo(8, -26);
        ctx.fill();

        // Gold collar / Pharaonic jewelry
        ctx.fillStyle = '#eab308';
        ctx.fillRect(-22, 10, 44, 12);
        ctx.fillStyle = '#06b6d4';
        ctx.fillRect(-16, 13, 32, 6);

        // Golden glowing eyes
        ctx.fillStyle = '#fbbf24';
        ctx.shadowBlur = 8;
        ctx.shadowColor = '#fbbf24';
        ctx.fillRect(isFacingLeft ? -12 : 2, -8, 6, 6);
        ctx.fillRect(isFacingLeft ? -2 : 8, -8, 6, 6);
        ctx.shadowBlur = 0;
        break;

      case 3:
        // Fenrir (Norse): Giant Dire Wolf of Frost
        ctx.fillStyle = '#334155';
        ctx.beginPath();
        ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
        ctx.fill();

        // Frost fur rime
        ctx.fillStyle = '#06b6d4';
        ctx.fillRect(-28, -4, 56, 8);

        // Wolf snout
        ctx.fillStyle = '#1e293b';
        ctx.beginPath();
        ctx.moveTo(-16, 4);
        ctx.lineTo(0, 24);
        ctx.lineTo(16, 4);
        ctx.fill();

        // Ice blue wolf eyes
        ctx.fillStyle = '#38bdf8';
        ctx.shadowBlur = 10;
        ctx.shadowColor = '#38bdf8';
        ctx.fillRect(isFacingLeft ? -14 : 2, -10, 7, 6);
        ctx.fillRect(isFacingLeft ? -2 : 10, -10, 7, 6);
        ctx.shadowBlur = 0;
        break;

      case 4:
        // Hades (Greek Underworld): Dark obsidian robes, bident, crown of souls
        ctx.fillStyle = '#1c1917';
        ctx.beginPath();
        ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
        ctx.fill();

        // Crown of Underworld Skulls
        ctx.fillStyle = '#450a0a';
        ctx.beginPath();
        ctx.moveTo(-24, -20);
        ctx.lineTo(-12, -42);
        ctx.lineTo(0, -22);
        ctx.lineTo(12, -42);
        ctx.lineTo(24, -20);
        ctx.closePath();
        ctx.fill();

        // Soul fire core
        ctx.fillStyle = '#dc2626';
        ctx.shadowBlur = 12;
        ctx.shadowColor = '#dc2626';
        ctx.beginPath();
        ctx.arc(0, 2, 14, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
        break;

      case 5:
        // FÁFNIR (Norse Dragon): Huge scaled dragon head, horns, massive wings
        ctx.fillStyle = '#78350f'; // Dark amber dragon scales
        ctx.beginPath();
        ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
        ctx.fill();

        // Dragon Spikes / Crest
        ctx.fillStyle = '#451a03';
        for (let i = -3; i <= 3; i++) {
          ctx.beginPath();
          ctx.moveTo(i * 14 - 6, -34);
          ctx.lineTo(i * 14, -58);
          ctx.lineTo(i * 14 + 6, -34);
          ctx.fill();
        }

        // Dragon Horns
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.moveTo(-36, -18);
        ctx.quadraticCurveTo(-60, -50, -40, -65);
        ctx.quadraticCurveTo(-34, -42, -26, -26);
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(36, -18);
        ctx.quadraticCurveTo(60, -50, 40, -65);
        ctx.quadraticCurveTo(34, -42, 26, -26);
        ctx.fill();

        // Draconic fiery eyes
        ctx.fillStyle = '#ff2200';
        ctx.shadowBlur = 14;
        ctx.shadowColor = '#ff3300';
        ctx.fillRect(isFacingLeft ? -22 : 4, -16, 12, 10);
        ctx.fillRect(isFacingLeft ? -4 : 14, -16, 12, 10);

        // Slit pupils
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(isFacingLeft ? -18 : 8, -14, 3, 7);
        ctx.fillRect(isFacingLeft ? 0 : 18, -14, 3, 7);
        ctx.shadowBlur = 0;

        // Snout with smoke nostrils
        ctx.fillStyle = '#571c08';
        ctx.beginPath();
        ctx.arc(0, 24, 18, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#000';
        ctx.fillRect(-8, 22, 5, 8);
        ctx.fillRect(3, 22, 5, 8);
        break;

      case 6:
        // Zeus: Classical celestial God of Thunder with toga, crown of lightning and electric aura
        ctx.fillStyle = '#f8fafc';
        ctx.beginPath();
        ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
        ctx.fill();

        // Golden Greek armor sash
        ctx.fillStyle = '#fbbf24';
        ctx.beginPath();
        ctx.moveTo(-this.radius * 0.7, -this.radius * 0.7);
        ctx.lineTo(this.radius * 0.8, this.radius * 0.8);
        ctx.lineTo(this.radius * 0.5, this.radius * 0.8);
        ctx.lineTo(-this.radius * 0.9, -this.radius * 0.5);
        ctx.closePath();
        ctx.fill();

        // Crown of Celestial Lightning Bolts
        ctx.fillStyle = '#f59e0b';
        ctx.shadowBlur = 10;
        ctx.shadowColor = '#38bdf8';
        for (let i = -2; i <= 2; i++) {
          ctx.beginPath();
          ctx.moveTo(i * 12 - 4, -this.radius + 2);
          ctx.lineTo(i * 12, -this.radius - 22);
          ctx.lineTo(i * 12 + 4, -this.radius + 2);
          ctx.fill();
        }

        // Electric blue eyes of raw lightning
        ctx.fillStyle = '#38bdf8';
        ctx.shadowBlur = 12;
        ctx.shadowColor = '#38bdf8';
        ctx.fillRect(isFacingLeft ? -16 : 2, -10, 8, 7);
        ctx.fillRect(isFacingLeft ? -4 : 12, -10, 8, 7);
        ctx.shadowBlur = 0;

        // Divine golden beard
        ctx.fillStyle = '#eab308';
        ctx.beginPath();
        ctx.moveTo(-16, 8);
        ctx.lineTo(0, 32);
        ctx.lineTo(16, 8);
        ctx.fill();

        // Master Thunderbolt in hand
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 4;
        ctx.shadowBlur = 14;
        ctx.shadowColor = '#38bdf8';
        const tbX = isFacingLeft ? -this.radius - 8 : this.radius + 8;
        ctx.beginPath();
        ctx.moveTo(tbX, -20);
        ctx.lineTo(tbX + 8, 0);
        ctx.lineTo(tbX - 4, 0);
        ctx.lineTo(tbX + 10, 24);
        ctx.stroke();
        ctx.shadowBlur = 0;
        break;

      case 7:
      default:
        // Cronos: Primordial Shadow Titan of Time & Oblivion
        ctx.fillStyle = '#1e1035';
        ctx.beginPath();
        ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = '#c084fc';
        ctx.lineWidth = 3;
        ctx.shadowBlur = 16;
        ctx.shadowColor = '#c084fc';
        ctx.stroke();
        ctx.shadowBlur = 0;

        // Astral Hourglass Core in chest
        ctx.fillStyle = '#a855f7';
        ctx.beginPath();
        ctx.moveTo(-12, -14);
        ctx.lineTo(12, -14);
        ctx.lineTo(0, 0);
        ctx.lineTo(12, 14);
        ctx.lineTo(-12, 14);
        ctx.lineTo(0, 0);
        ctx.closePath();
        ctx.fill();

        // Cosmic Horns of Infinity
        ctx.fillStyle = '#3b0764';
        ctx.beginPath();
        ctx.moveTo(-28, -20);
        ctx.quadraticCurveTo(-50, -56, -30, -68);
        ctx.quadraticCurveTo(-22, -48, -16, -26);
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(28, -20);
        ctx.quadraticCurveTo(50, -56, 30, -68);
        ctx.quadraticCurveTo(22, -48, 16, -26);
        ctx.fill();

        // Star eyes (Nebula Violet & White)
        ctx.fillStyle = '#ffffff';
        ctx.shadowBlur = 14;
        ctx.shadowColor = '#e879f9';
        ctx.beginPath();
        ctx.arc(isFacingLeft ? -14 : 6, -10, 5, 0, Math.PI * 2);
        ctx.arc(isFacingLeft ? -2 : 18, -10, 5, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;

        // Twin Astral Scythes hovering beside him
        ctx.strokeStyle = '#f43f5e';
        ctx.lineWidth = 3.5;
        ctx.shadowBlur = 12;
        ctx.shadowColor = '#f43f5e';
        for (let s = -1; s <= 1; s += 2) {
          const scX = s * (this.radius + 18);
          ctx.beginPath();
          ctx.arc(scX, -6, 22, s === 1 ? -Math.PI * 0.4 : Math.PI * 0.6, s === 1 ? Math.PI * 0.4 : Math.PI * 1.4);
          ctx.stroke();
        }
        ctx.shadowBlur = 0;
        break;
    }

    ctx.restore();
  }
}
