import { Entity } from './Entity.js';
import { Bullet } from '../combat/Bullet.js';

export const EnemyType = {
  PISTOL: 'pistol',
  SMG: 'smg',
  SNIPER: 'sniper',
  BAZOOKA: 'bazooka',
  GATLING: 'gatling',
  MAGE: 'mage',
  BOMBER: 'bomber',
  SHIELD: 'shield',
  SLIME: 'slime'
};

export class Enemy extends Entity {
  constructor(x, y, type = EnemyType.PISTOL) {
    let radius = 16;
    let health = 45;

    if (type === EnemyType.SMG) { radius = 16; health = 60; }
    if (type === EnemyType.SNIPER) { radius = 15; health = 40; }
    if (type === EnemyType.BAZOOKA) { radius = 20; health = 95; }
    if (type === EnemyType.GATLING) { radius = 24; health = 160; }
    if (type === EnemyType.MAGE) { radius = 17; health = 70; }
    if (type === EnemyType.BOMBER) { radius = 14; health = 35; }
    if (type === EnemyType.SHIELD) { radius = 19; health = 125; }
    if (type === EnemyType.SLIME) { radius = 17; health = 80; }

    super(x, y, radius, health);
    this.type = type;

    this.shootTimer = 1.0 + Math.random() * 1.5;
    this.stateTimer = 0;
    this.aimAngle = 0;
    this.speed = 100;

    // Telegraphing for Sniper laser
    this.isAimingLaser = false;
    this.laserTimer = 0;

    // Burst firing for SMG
    this.burstRemaining = 0;
    this.burstTimer = 0;

    // Gatling spinup
    this.isSpinningUp = false;
    this.gatlingStreamTimer = 0;

    // Mage state
    this.teleportCooldown = 2.5;

    // Bomber state
    this.fuseTimer = 3.6;
    this.isTicking = false;

    // Shield state
    this.shieldOpenTimer = 0; // When > 0, shield is lowered to shoot

    // Slime state
    this.squishTimer = 0;
  }

  takeDamage(amount, sourceX = null, sourceY = null) {
    // Frontal shield block
    if (this.type === EnemyType.SHIELD && sourceX !== null && sourceY !== null && this.shieldOpenTimer <= 0) {
      const bulletAngle = Math.atan2(sourceY - this.y, sourceX - this.x);
      let diff = Math.abs(bulletAngle - this.aimAngle);
      while (diff > Math.PI) diff = Math.abs(diff - Math.PI * 2);

      // If bullet is coming from the front (within ~65 degrees of facing direction)
      if (diff < 1.15) {
        this.flashTimer = 0.08;
        return 0; // Completely absorbed by shield!
      }
    }

    return super.takeDamage(amount);
  }

  update(dt, player, bullets, audio, particles) {
    if (this.isDead || !player || player.isDead) return;

    this.stateTimer += dt;
    const distToPlayer = Math.hypot(player.x - this.x, player.y - this.y);
    this.aimAngle = Math.atan2(player.y - this.y, player.x - this.x);

    // AI Behaviors by Enemy Type
    switch (this.type) {
      case EnemyType.PISTOL:
        this.updatePistol(dt, player, distToPlayer, bullets, audio);
        break;
      case EnemyType.SMG:
        this.updateSMG(dt, player, distToPlayer, bullets, audio);
        break;
      case EnemyType.SNIPER:
        this.updateSniper(dt, player, distToPlayer, bullets, audio);
        break;
      case EnemyType.BAZOOKA:
        this.updateBazooka(dt, player, distToPlayer, bullets, audio, particles);
        break;
      case EnemyType.GATLING:
        this.updateGatling(dt, player, distToPlayer, bullets, audio);
        break;
      case EnemyType.MAGE:
        this.updateMage(dt, player, distToPlayer, bullets, audio, particles);
        break;
      case EnemyType.BOMBER:
        this.updateBomber(dt, player, distToPlayer, bullets, audio, particles);
        break;
      case EnemyType.SHIELD:
        this.updateShield(dt, player, distToPlayer, bullets, audio);
        break;
      case EnemyType.SLIME:
        this.updateSlime(dt, player, distToPlayer, bullets, audio, particles);
        break;
    }

    this.updatePhysics(dt);
  }

  // 1. Pistol Kin: Tactical shooter - approaches, stops to aim/fire, backs off if rushed
  updatePistol(dt, player, dist, bullets, audio) {
    const idealMin = 160;
    const idealMax = 260;

    if (dist > idealMax) {
      this.vx += Math.cos(this.aimAngle) * 110;
      this.vy += Math.sin(this.aimAngle) * 110;
    } else if (dist < idealMin) {
      this.vx -= Math.cos(this.aimAngle) * 90;
      this.vy -= Math.sin(this.aimAngle) * 90;
    } else {
      this.vx += Math.cos(this.aimAngle) * 20;
      this.vy += Math.sin(this.aimAngle) * 20;
    }

    this.shootTimer -= dt;
    if (this.shootTimer <= 0) {
      this.shootTimer = 1.1 + Math.random() * 0.5;
      const bSpeed = 360;
      bullets.push(new Bullet({
        x: this.x + Math.cos(this.aimAngle) * 16,
        y: this.y + Math.sin(this.aimAngle) * 16,
        vx: Math.cos(this.aimAngle) * bSpeed,
        vy: Math.sin(this.aimAngle) * bSpeed,
        damage: 1,
        radius: 6,
        isPlayer: false,
        color: '#ff3344',
        type: 'enemy_pistol'
      }));
      if (audio) audio.playShoot('pistol');
    }
  }

  // 2. SMG Sprayer: Advances, halts, fires rapid 4-round burst, then repositions
  updateSMG(dt, player, dist, bullets, audio) {
    const idealMin = 140;
    const idealMax = 220;

    if (dist > idealMax) {
      this.vx += Math.cos(this.aimAngle) * 130;
      this.vy += Math.sin(this.aimAngle) * 130;
    } else if (dist < idealMin) {
      this.vx -= Math.cos(this.aimAngle) * 100;
      this.vy -= Math.sin(this.aimAngle) * 100;
    }

    if (this.burstRemaining > 0) {
      this.vx *= 0.5;
      this.vy *= 0.5;

      this.burstTimer -= dt;
      if (this.burstTimer <= 0) {
        this.burstTimer = 0.08;
        this.burstRemaining--;
        const spread = (Math.random() - 0.5) * 0.25;
        const angle = this.aimAngle + spread;
        const bSpeed = 440;
        bullets.push(new Bullet({
          x: this.x + Math.cos(angle) * 16,
          y: this.y + Math.sin(angle) * 16,
          vx: Math.cos(angle) * bSpeed,
          vy: Math.sin(angle) * bSpeed,
          damage: 1,
          radius: 5,
          isPlayer: false,
          color: '#ff8800',
          type: 'enemy_smg'
        }));
        if (audio) audio.playShoot('smg');
      }
    } else {
      this.shootTimer -= dt;
      if (this.shootTimer <= 0) {
        this.shootTimer = 1.6 + Math.random() * 0.5;
        this.burstRemaining = 4;
        this.burstTimer = 0.04;
      }
    }
  }

  // 3. Sniper Deadeye: Keeps distance, telegraphs red laser for 1.2s before high velocity shot
  updateSniper(dt, player, dist, bullets, audio) {
    const idealDist = 380;
    if (dist < idealDist) {
      this.vx -= Math.cos(this.aimAngle) * 80;
      this.vy -= Math.sin(this.aimAngle) * 80;
    }

    this.shootTimer -= dt;
    if (this.shootTimer <= 1.2) {
      this.isAimingLaser = true;
    }

    if (this.shootTimer <= 0) {
      this.shootTimer = 3.2;
      this.isAimingLaser = false;

      const bSpeed = 950;
      bullets.push(new Bullet({
        x: this.x + Math.cos(this.aimAngle) * 20,
        y: this.y + Math.sin(this.aimAngle) * 20,
        vx: Math.cos(this.aimAngle) * bSpeed,
        vy: Math.sin(this.aimAngle) * bSpeed,
        damage: 1,
        radius: 7,
        isPlayer: false,
        color: '#ff0033',
        type: 'sniper'
      }));
      if (audio) audio.playShoot('sniper');
    }
  }

  // 4. Bazooka Bombardier: Fires slow rocket that explodes into 6 shrapnel bullets
  updateBazooka(dt, player, dist, bullets, audio, particles) {
    if (dist > 280) {
      this.vx += Math.cos(this.aimAngle) * 60;
      this.vy += Math.sin(this.aimAngle) * 60;
    }

    this.shootTimer -= dt;
    if (this.shootTimer <= 0) {
      this.shootTimer = 3.0 + Math.random() * 0.8;
      const bSpeed = 240;
      const rocket = new Bullet({
        x: this.x + Math.cos(this.aimAngle) * 20,
        y: this.y + Math.sin(this.aimAngle) * 20,
        vx: Math.cos(this.aimAngle) * bSpeed,
        vy: Math.sin(this.aimAngle) * bSpeed,
        damage: 1,
        radius: 9,
        isPlayer: false,
        color: '#ff4400',
        type: 'enemy_rocket',
        lifetime: 2.2
      });

      rocket.onDetonate = (spawnList) => {
        if (particles) particles.createExplosion(rocket.x, rocket.y, 50);
        if (audio) audio.playExplosion();
        for (let i = 0; i < 6; i++) {
          const sAngle = (i / 6) * Math.PI * 2;
          spawnList.push(new Bullet({
            x: rocket.x,
            y: rocket.y,
            vx: Math.cos(sAngle) * 260,
            vy: Math.sin(sAngle) * 260,
            damage: 1,
            radius: 5,
            isPlayer: false,
            color: '#ff7700',
            type: 'enemy_pistol'
          }));
        }
      };

      bullets.push(rocket);
      if (audio) audio.playShoot('rocket');
    }
  }

  // 5. Heavy Gatling Behemoth: Wind up, sustained bullet hell stream
  updateGatling(dt, player, dist, bullets, audio) {
    this.vx += Math.cos(this.aimAngle) * 45;
    this.vy += Math.sin(this.aimAngle) * 45;

    if (this.gatlingStreamTimer > 0) {
      this.gatlingStreamTimer -= dt;
      if (Math.random() < 0.35) {
        const sweepAngle = this.aimAngle + (Math.sin(this.stateTimer * 6) * 0.4);
        bullets.push(new Bullet({
          x: this.x + Math.cos(sweepAngle) * 24,
          y: this.y + Math.sin(sweepAngle) * 24,
          vx: Math.cos(sweepAngle) * 380,
          vy: Math.sin(sweepAngle) * 380,
          damage: 1,
          radius: 5,
          isPlayer: false,
          color: '#ff2255',
          type: 'enemy_smg'
        }));
        if (audio && Math.random() < 0.3) audio.playShoot('smg');
      }
    } else {
      this.shootTimer -= dt;
      if (this.shootTimer <= 0) {
        this.shootTimer = 3.5;
        this.gatlingStreamTimer = 1.8;
      }
    }
  }

  // 6. Arcane Mage: Floats, casts 3 homing arcane bolts, teleports away if rushed
  updateMage(dt, player, dist, bullets, audio, particles) {
    // Gentle floating motion
    const floatOffset = Math.sin(this.stateTimer * 4) * 30;
    this.vx += (Math.cos(this.aimAngle + Math.PI / 2) * floatOffset);
    this.vy += (Math.sin(this.aimAngle + Math.PI / 2) * floatOffset);

    // Keep distance
    if (dist > 300) {
      this.vx += Math.cos(this.aimAngle) * 75;
      this.vy += Math.sin(this.aimAngle) * 75;
    } else if (dist < 180) {
      this.vx -= Math.cos(this.aimAngle) * 85;
      this.vy -= Math.sin(this.aimAngle) * 85;
    }

    // Emergency Teleport if player gets too close
    this.teleportCooldown -= dt;
    if (dist < 110 && this.teleportCooldown <= 0) {
      this.teleportCooldown = 3.5;
      if (particles) particles.createShockwave(this.x, this.y, 80, '#c084fc', 220);
      if (audio) audio.playDodgeRoll();

      // Teleport away from player
      const tpAngle = this.aimAngle + Math.PI + (Math.random() - 0.5) * 0.8;
      this.x += Math.cos(tpAngle) * 220;
      this.y += Math.sin(tpAngle) * 220;
      if (particles) particles.createShockwave(this.x, this.y, 60, '#c084fc', 200);
    }

    // Cast Arcane Homing Orbs
    this.shootTimer -= dt;
    if (this.shootTimer <= 0) {
      this.shootTimer = 2.4 + Math.random() * 0.6;
      if (audio) audio.playShoot('plasma');

      for (let i = -1; i <= 1; i++) {
        const spreadAngle = this.aimAngle + i * 0.35;
        const bSpeed = 220;
        bullets.push(new Bullet({
          x: this.x + Math.cos(spreadAngle) * 18,
          y: this.y + Math.sin(spreadAngle) * 18,
          vx: Math.cos(spreadAngle) * bSpeed,
          vy: Math.sin(spreadAngle) * bSpeed,
          damage: 1,
          radius: 6,
          isPlayer: false,
          color: '#c084fc',
          type: 'enemy_mage',
          homing: true,
          target: player,
          lifetime: 3.2
        }));
      }
    }
  }

  // 7. Bomber Kin: Relentless fast sprint, ticking fuse, explodes on reach or death
  updateBomber(dt, player, dist, bullets, audio, particles) {
    // Sprint straight at player
    const bSpeed = 195;
    this.vx += Math.cos(this.aimAngle) * bSpeed;
    this.vy += Math.sin(this.aimAngle) * bSpeed;

    this.fuseTimer -= dt;
    this.isTicking = true;

    // Sparks from fuse
    if (particles && Math.random() < 0.4) {
      particles.createHitSparks(this.x, this.y - 14, '#f59e0b');
    }

    // Detonate when reaching player or when fuse ends
    if (dist < (this.radius + player.radius + 6) || this.fuseTimer <= 0) {
      this.detonateBomber(player, bullets, audio, particles);
    }
  }

  detonateBomber(player, bullets, audio, particles) {
    if (this.isDead) return;
    this.isDead = true;

    if (particles) {
      particles.createExplosion(this.x, this.y, 75);
      particles.createShockwave(this.x, this.y, 140, '#ff4400', 350);
    }
    if (audio) audio.playExplosion();

    // Damage player directly if close and not rolling
    const distToPlayer = Math.hypot(player.x - this.x, player.y - this.y);
    if (distToPlayer < 75 && !player.isRolling && !player.isInvulnerable) {
      player.takeDamage(1);
      audio.playPlayerHurt();
      if (particles) particles.createBlood(player.x, player.y, 12);
    }

    // Disperse 8 shrapnel bullets in a ring
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      bullets.push(new Bullet({
        x: this.x,
        y: this.y,
        vx: Math.cos(a) * 260,
        vy: Math.sin(a) * 260,
        damage: 1,
        radius: 5,
        isPlayer: false,
        color: '#ff5500',
        type: 'enemy_pistol'
      }));
    }
  }

  // 8. Shield Phalanx: Tower shield blocks frontal shots; occasionally lowers shield to fire shotgun burst
  updateShield(dt, player, dist, bullets, audio) {
    if (this.shieldOpenTimer > 0) {
      this.shieldOpenTimer -= dt;
    }

    // Steady advance
    if (dist > 160) {
      this.vx += Math.cos(this.aimAngle) * 75;
      this.vy += Math.sin(this.aimAngle) * 75;
    } else if (dist < 100) {
      this.vx -= Math.cos(this.aimAngle) * 60;
      this.vy -= Math.sin(this.aimAngle) * 60;
    }

    this.shootTimer -= dt;
    if (this.shootTimer <= 0) {
      this.shootTimer = 2.6 + Math.random() * 0.6;
      this.shieldOpenTimer = 0.55; // Lower shield to shoot!

      if (audio) audio.playShoot('shotgun');
      // Fire 3-spread heavy pellets
      for (let i = -1; i <= 1; i++) {
        const a = this.aimAngle + i * 0.22;
        bullets.push(new Bullet({
          x: this.x + Math.cos(a) * 18,
          y: this.y + Math.sin(a) * 18,
          vx: Math.cos(a) * 360,
          vy: Math.sin(a) * 360,
          damage: 1,
          radius: 6,
          isPlayer: false,
          color: '#e2e8f0',
          type: 'enemy_smg'
        }));
      }
    }
  }

  // 9. Toxic Slime: Squirms and spits poisonous globs
  updateSlime(dt, player, dist, bullets, audio, particles) {
    this.squishTimer += dt * 5;

    // Wobble toward player
    if (dist > 180) {
      this.vx += Math.cos(this.aimAngle) * 90;
      this.vy += Math.sin(this.aimAngle) * 90;
    } else if (dist < 120) {
      this.vx -= Math.cos(this.aimAngle) * 70;
      this.vy -= Math.sin(this.aimAngle) * 70;
    }

    this.shootTimer -= dt;
    if (this.shootTimer <= 0) {
      this.shootTimer = 2.2 + Math.random() * 0.5;
      if (audio) audio.playShoot('plasma');

      // Spit parabolic acid blob
      const bSpeed = 280;
      bullets.push(new Bullet({
        x: this.x + Math.cos(this.aimAngle) * 16,
        y: this.y + Math.sin(this.aimAngle) * 16,
        vx: Math.cos(this.aimAngle) * bSpeed,
        vy: Math.sin(this.aimAngle) * bSpeed,
        damage: 1,
        radius: 8,
        isPlayer: false,
        color: '#10b981',
        type: 'enemy_acid',
        lifetime: 2.5
      }));
    }
  }

  render(ctx) {
    ctx.save();
    ctx.translate(this.x, this.y);

    // Hit flash
    if (this.flashTimer > 0) {
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(0, 0, this.radius + 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      return;
    }

    // Shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
    ctx.beginPath();
    ctx.ellipse(0, this.radius - 2, this.radius * 0.9, this.radius * 0.5, 0, 0, Math.PI * 2);
    ctx.fill();

    const isFacingLeft = Math.cos(this.aimAngle) < 0;

    // Body rendering by enemy type
    switch (this.type) {
      case EnemyType.PISTOL:
        // Bullet kin shape (bronze bullet shell with eyes)
        ctx.fillStyle = '#d97706';
        ctx.beginPath();
        ctx.arc(0, -4, 12, Math.PI, 0);
        ctx.lineTo(12, 10);
        ctx.lineTo(-12, 10);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#fef3c7';
        ctx.fillRect(-12, 8, 24, 4);

        ctx.fillStyle = '#ffffff';
        const pEyeX = isFacingLeft ? -4 : 2;
        ctx.fillRect(pEyeX, -6, 4, 6);
        ctx.fillRect(pEyeX + (isFacingLeft ? -5 : 5), -6, 4, 6);
        ctx.fillStyle = '#000';
        ctx.fillRect(pEyeX + (isFacingLeft ? 0 : 2), -4, 2, 3);
        ctx.fillRect(pEyeX + (isFacingLeft ? -5 : 7), -4, 2, 3);
        break;

      case EnemyType.SMG:
        ctx.fillStyle = '#1e3a8a';
        ctx.beginPath();
        ctx.arc(0, -4, 13, Math.PI, 0);
        ctx.lineTo(13, 10);
        ctx.lineTo(-13, 10);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#dc2626';
        ctx.fillRect(-13, -7, 26, 5);

        ctx.fillStyle = '#fff';
        const sEyeX = isFacingLeft ? -3 : 2;
        ctx.fillRect(sEyeX, -2, 4, 4);
        ctx.fillRect(sEyeX + (isFacingLeft ? -5 : 5), -2, 4, 4);
        break;

      case EnemyType.SNIPER:
        ctx.fillStyle = '#7f1d1d';
        ctx.beginPath();
        ctx.arc(0, -2, 13, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#00ffff';
        ctx.shadowBlur = 6;
        ctx.shadowColor = '#00ffff';
        ctx.beginPath();
        ctx.arc(isFacingLeft ? -5 : 5, -3, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
        break;

      case EnemyType.BAZOOKA:
        ctx.fillStyle = '#166534';
        ctx.fillRect(-16, -14, 32, 26);
        ctx.fillStyle = '#14532d';
        ctx.fillRect(-18, -4, 36, 10);
        ctx.fillStyle = '#facc15';
        ctx.fillRect(-8, -10, 16, 4);
        break;

      case EnemyType.GATLING:
        ctx.fillStyle = '#374151';
        ctx.beginPath();
        ctx.arc(0, 0, 20, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#1f2937';
        ctx.fillRect(-14, -6, 28, 14);

        ctx.fillStyle = '#ff0033';
        ctx.shadowBlur = 8;
        ctx.shadowColor = '#ff0033';
        ctx.fillRect(-10, -6, 20, 4);
        ctx.shadowBlur = 0;
        break;

      case EnemyType.MAGE:
        // Arcane Cultist Mage
        ctx.fillStyle = '#4c1d95';
        ctx.beginPath();
        ctx.arc(0, -5, 13, Math.PI, 0);
        ctx.lineTo(14, 12);
        ctx.lineTo(-14, 12);
        ctx.closePath();
        ctx.fill();

        // Mystic Hood Rim
        ctx.fillStyle = '#7c3aed';
        ctx.beginPath();
        ctx.arc(0, -5, 14, Math.PI * 0.9, Math.PI * 0.1, true);
        ctx.lineWidth = 3;
        ctx.strokeStyle = '#c084fc';
        ctx.stroke();

        // Glowing Purple Eyes
        ctx.fillStyle = '#e879f9';
        ctx.shadowBlur = 8;
        ctx.shadowColor = '#e879f9';
        const mEyeX = isFacingLeft ? -5 : 1;
        ctx.fillRect(mEyeX, -6, 4, 4);
        ctx.fillRect(mEyeX + (isFacingLeft ? -5 : 6), -6, 4, 4);
        ctx.shadowBlur = 0;

        // Floating Arcane Rune Orb beside mage
        const orbAngle = this.stateTimer * 3.5;
        const orbX = Math.cos(orbAngle) * 22;
        const orbY = Math.sin(orbAngle) * 8 - 4;
        ctx.fillStyle = '#c084fc';
        ctx.shadowBlur = 10;
        ctx.shadowColor = '#c084fc';
        ctx.beginPath();
        ctx.arc(orbX, orbY, 5, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
        break;

      case EnemyType.BOMBER:
        // Explosive Red Bomber Kin with blinking spark
        const isBlinking = (Math.sin(this.stateTimer * 16) > 0);
        ctx.fillStyle = isBlinking ? '#ff1100' : '#b91c1c';
        ctx.beginPath();
        ctx.arc(0, 0, 13, 0, Math.PI * 2);
        ctx.fill();

        // Warning bands
        ctx.fillStyle = '#fbbf24';
        ctx.fillRect(-10, -3, 20, 6);

        // Fuse on top
        ctx.strokeStyle = '#78350f';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(0, -12);
        ctx.quadraticCurveTo(6, -18, 4, -22);
        ctx.stroke();

        // Spark flame at tip
        ctx.fillStyle = '#facc15';
        ctx.shadowBlur = 8;
        ctx.shadowColor = '#f59e0b';
        ctx.beginPath();
        ctx.arc(4, -22, 3.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;

        // Wild eyes
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(isFacingLeft ? -6 : 1, -4, 5, 5);
        ctx.fillRect(isFacingLeft ? 0 : 7, -4, 5, 5);
        ctx.fillStyle = '#000000';
        ctx.fillRect(isFacingLeft ? -4 : 3, -3, 2, 2);
        ctx.fillRect(isFacingLeft ? 2 : 9, -3, 2, 2);
        break;

      case EnemyType.SHIELD:
        // Phalanx Knight with tower shield
        ctx.fillStyle = '#475569';
        ctx.beginPath();
        ctx.arc(0, 0, 14, 0, Math.PI * 2);
        ctx.fill();

        // Helmet crest
        ctx.fillStyle = '#94a3b8';
        ctx.fillRect(-8, -12, 16, 5);

        // Massive Tower Shield in front
        ctx.save();
        ctx.rotate(this.aimAngle);
        ctx.fillStyle = this.shieldOpenTimer > 0 ? '#64748b' : '#0284c7';
        ctx.strokeStyle = '#e2e8f0';
        ctx.lineWidth = 2.5;

        // Offset shield forward
        ctx.beginPath();
        ctx.roundRect(10, -16, 8, 32, 4);
        ctx.fill();
        ctx.stroke();

        // Golden Shield Boss / Emblem
        ctx.fillStyle = '#facc15';
        ctx.beginPath();
        ctx.arc(14, 0, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
        break;

      case EnemyType.SLIME:
        // Bouncing toxic slime
        const squishX = 1 + Math.sin(this.squishTimer) * 0.15;
        const squishY = 1 - Math.sin(this.squishTimer) * 0.15;
        ctx.scale(squishX, squishY);

        ctx.fillStyle = 'rgba(16, 185, 129, 0.85)';
        ctx.beginPath();
        ctx.arc(0, 0, 15, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = '#34d399';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Inner glowing core
        ctx.fillStyle = '#a7f3d0';
        ctx.beginPath();
        ctx.arc(isFacingLeft ? -4 : 4, -2, 5, 0, Math.PI * 2);
        ctx.fill();

        // Eye
        ctx.fillStyle = '#064e3b';
        ctx.fillRect(isFacingLeft ? -6 : 2, -3, 3, 3);
        ctx.fillRect(isFacingLeft ? 0 : 8, -3, 3, 3);
        break;
    }

    // Health bar above enemy head (if damaged)
    if (this.health < this.maxHealth) {
      const pct = this.health / this.maxHealth;
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(-16, -this.radius - 12, 32, 5);
      ctx.fillStyle = '#ff3344';
      ctx.fillRect(-15, -this.radius - 11, 30 * pct, 3);
    }

    ctx.restore();

    // Render Sniper Laser Telegraph in World coordinates
    if (this.type === EnemyType.SNIPER && this.isAimingLaser) {
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(this.x, this.y);
      ctx.lineTo(this.x + Math.cos(this.aimAngle) * 600, this.y + Math.sin(this.aimAngle) * 600);
      ctx.strokeStyle = 'rgba(255, 0, 50, 0.65)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([6, 6]);
      ctx.shadowBlur = 6;
      ctx.shadowColor = '#ff0033';
      ctx.stroke();
      ctx.restore();
    }
  }
}

// Spawner helper according to floor progression
export function spawnEnemiesForFloor(floorNumber, room) {
  const enemies = [];
  const padding = 120;
  const count = 3 + floorNumber; // 4 enemies on floor 1, up to 10 on floor 7

  const availableTypes = [EnemyType.PISTOL];

  if (floorNumber === 2) {
    availableTypes.push(EnemyType.SMG, EnemyType.SNIPER, EnemyType.BOMBER);
  } else if (floorNumber === 3) {
    availableTypes.push(EnemyType.SMG, EnemyType.SNIPER, EnemyType.BAZOOKA, EnemyType.BOMBER, EnemyType.SLIME);
  } else if (floorNumber === 4) {
    availableTypes.push(EnemyType.SMG, EnemyType.SNIPER, EnemyType.BAZOOKA, EnemyType.GATLING, EnemyType.SHIELD, EnemyType.MAGE);
  } else if (floorNumber === 5) {
    availableTypes.push(EnemyType.SNIPER, EnemyType.BAZOOKA, EnemyType.GATLING, EnemyType.SHIELD, EnemyType.MAGE, EnemyType.BOMBER);
  } else if (floorNumber === 6) {
    // Floor 6: Storm Olympus - heavy artillery, mages, bombers, gatlings
    availableTypes.push(EnemyType.BAZOOKA, EnemyType.GATLING, EnemyType.SHIELD, EnemyType.MAGE, EnemyType.BOMBER, EnemyType.SLIME);
  } else if (floorNumber >= 7) {
    // Floor 7: Cosmic Void - all lethal elite squads!
    availableTypes.push(EnemyType.GATLING, EnemyType.BAZOOKA, EnemyType.SHIELD, EnemyType.MAGE, EnemyType.SNIPER, EnemyType.BOMBER, EnemyType.SLIME);
  }

  for (let i = 0; i < count; i++) {
    const rx = room.x + padding + Math.random() * (room.width - padding * 2);
    const ry = room.y + padding + Math.random() * (room.height - padding * 2);

    const type = availableTypes[Math.floor(Math.random() * availableTypes.length)];
    enemies.push(new Enemy(rx, ry, type));
  }

  return enemies;
}
