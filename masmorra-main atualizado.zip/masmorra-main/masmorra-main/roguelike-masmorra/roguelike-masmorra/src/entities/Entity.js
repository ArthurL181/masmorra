// Base Entity class
export class Entity {
  constructor(x, y, radius = 16, health = 100) {
    this.x = x;
    this.y = y;
    this.vx = 0;
    this.vy = 0;
    this.radius = radius;
    this.maxHealth = health;
    this.health = health;
    this.isDead = false;
    this.friction = 8.0;

    // Visual flash on hit
    this.flashTimer = 0;
  }

  takeDamage(amount) {
    if (this.isDead) return 0;
    this.health -= amount;
    this.flashTimer = 0.12;

    if (this.health <= 0) {
      this.health = 0;
      this.isDead = true;
    }
    return amount;
  }

  updatePhysics(dt) {
    this.x += this.vx * dt;
    this.y += this.vy * dt;

    this.vx *= Math.max(0, 1 - this.friction * dt);
    this.vy *= Math.max(0, 1 - this.friction * dt);

    if (this.flashTimer > 0) {
      this.flashTimer -= dt;
    }
  }

  // Resolve collision against room boundaries, corridors, and pillars
  resolveEnvironmentCollisions(currentRoom, allRooms) {
    if (!currentRoom) return;

    // 1. Pillar collisions
    if (currentRoom.pillars) {
      currentRoom.pillars.forEach(pillar => {
        const dx = this.x - pillar.x;
        const dy = this.y - pillar.y;
        const dist = Math.hypot(dx, dy);
        const minDist = this.radius + pillar.radius;

        if (dist < minDist && dist > 0) {
          const overlap = minDist - dist;
          this.x += (dx / dist) * overlap;
          this.y += (dy / dist) * overlap;
        }
      });
    }

    // 2. Room wall collisions
    // If room doors are locked, player cannot leave room boundaries
    const isLocked = currentRoom.doors.some(d => d.isLocked);

    if (isLocked) {
      // Clamp strictly inside room
      this.x = Math.max(currentRoom.x + this.radius, Math.min(currentRoom.x + currentRoom.width - this.radius, this.x));
      this.y = Math.max(currentRoom.y + this.radius, Math.min(currentRoom.y + currentRoom.height - this.radius, this.y));
    } else {
      // When unlocked, check if player is near a doorway corridor
      // Check N/S/W/E door openings
      const doorOpenWidth = 90;
      let inDoorCorridor = false;

      // Check all doors in current room
      for (const door of currentRoom.doors) {
        if (door.dir === 'N' || door.dir === 'S') {
          if (this.x >= door.x && this.x <= door.x + door.width) {
            inDoorCorridor = true;
            break;
          }
        } else {
          if (this.y >= door.y && this.y <= door.y + door.height) {
            inDoorCorridor = true;
            break;
          }
        }
      }

      // If not in a door corridor, clamp to room walls or corridor walls
      if (!inDoorCorridor) {
        // Clamp to current room
        const minX = currentRoom.x + this.radius;
        const maxX = currentRoom.x + currentRoom.width - this.radius;
        const minY = currentRoom.y + this.radius;
        const maxY = currentRoom.y + currentRoom.height - this.radius;

        // If outside room, clamp to closest valid room or corridor
        if (this.x < minX || this.x > maxX || this.y < minY || this.y > maxY) {
          // Check if player is currently in any neighboring corridor
          let inAnyRoom = allRooms.some(r => r.contains(this.x, this.y));
          if (!inAnyRoom) {
            // Check corridors
            let inCorridor = false;
            for (const r of allRooms) {
              if (r.neighbors['E']) {
                const nextR = r.neighbors['E'];
                const cX = r.x + r.width;
                const cY = r.y + (r.height - 100) / 2;
                const cW = nextR.x - cX;
                const cH = 100;
                if (this.x >= cX && this.x <= cX + cW && this.y >= cY && this.y <= cY + cH) {
                  inCorridor = true;
                  // Clamp inside corridor height
                  this.y = Math.max(cY + this.radius, Math.min(cY + cH - this.radius, this.y));
                  break;
                }
              }
              if (r.neighbors['S']) {
                const nextR = r.neighbors['S'];
                const cX = r.x + (r.width - 100) / 2;
                const cY = r.y + r.height;
                const cW = 100;
                const cH = nextR.y - cY;
                if (this.x >= cX && this.x <= cX + cW && this.y >= cY && this.y <= cY + cH) {
                  inCorridor = true;
                  // Clamp inside corridor width
                  this.x = Math.max(cX + this.radius, Math.min(cX + cW - this.radius, this.x));
                  break;
                }
              }
            }
            if (!inCorridor) {
              this.x = Math.max(minX, Math.min(maxX, this.x));
              this.y = Math.max(minY, Math.min(maxY, this.y));
            }
          }
        }
      }
    }
  }

  // Push apart from other entity to avoid stacking
  resolveSeparation(other, padding = 4) {
    if (!other || other === this || other.isDead) return;
    const dx = this.x - other.x;
    const dy = this.y - other.y;
    const dist = Math.hypot(dx, dy);
    const minDist = this.radius + other.radius + padding;

    if (dist < minDist && dist > 0.001) {
      const overlap = (minDist - dist) * 0.5;
      const nx = dx / dist;
      const ny = dy / dist;
      this.x += nx * overlap;
      this.y += ny * overlap;
      other.x -= nx * overlap;
      other.y -= ny * overlap;
    }
  }
}
