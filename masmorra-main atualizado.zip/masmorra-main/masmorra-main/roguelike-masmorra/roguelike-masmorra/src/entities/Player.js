import { Entity } from './Entity.js';
import { Weapon, WeaponTypes } from '../combat/Weapons.js';

export class Player extends Entity {
  constructor(x, y, config = {}) {
    const baseHealth = 6 + (config.extraHealth || 0); // 6 = 3 full hearts base
    super(x, y, 16, baseHealth);
    this.speed = 260 + (config.extraSpeed || 0);

    // Dodge Roll (Enter the Gungeon core mechanic)
    this.isRolling = false;
    this.rollDuration = 0.38;
    this.rollTimer = 0;
    this.rollCooldown = 0.45;
    this.cooldownTimer = 0;
    this.rollDirX = 0;
    this.rollDirY = 0;
    this.rollSpeed = 520;
    this.isInvulnerable = false;
    this.invulnerableTimer = 0;

    // Blanks (Screen-clearing bomb)
    this.blanks = 2 + (config.extraBlanks || 0);

    // Coins & Keys
    this.coins = 0;
    this.keys = 1;

    // Skin data for rendering
    this.skinData = config.skinData || {
      bodyColor: '#2b6cb0',
      capeColor: '#1c3d5a',
      helmetColor: '#3182ce'
    };

    // Weapons
    this.weapons = [new Weapon(WeaponTypes.PISTOL)];
    this.activeWeaponIndex = 0;

    // Add bonus starting weapons from shop upgrades
    if (config.startShotgun) this.equipWeapon(WeaponTypes.SHOTGUN);
    if (config.startAK47) this.equipWeapon(WeaponTypes.AK47);
    if (config.startSniper) this.equipWeapon(WeaponTypes.SNIPER);

    // Always switch back to pistol as first active weapon
    this.activeWeaponIndex = 0;

    // Aim angle
    this.aimAngle = 0;
  }

  get activeWeapon() {
    return this.weapons[this.activeWeaponIndex];
  }

  selectWeapon(index, audio) {
    if (index >= 0 && index < this.weapons.length && index !== this.activeWeaponIndex) {
      this.activeWeaponIndex = index;
      if (audio) audio.playReload();
      return true;
    }
    return false;
  }

  cycleWeapon(audio) {
    if (this.weapons.length <= 1) return false;
    this.activeWeaponIndex = (this.activeWeaponIndex + 1) % this.weapons.length;
    if (audio) audio.playReload();
    return true;
  }

  equipWeapon(weaponDef) {
    // Check if player already has this weapon
    const existing = this.weapons.find(w => w.id === weaponDef.id);
    if (existing) {
      existing.reserveAmmo = Math.min(existing.def.maxAmmo, existing.reserveAmmo + weaponDef.maxAmmo);
      return { added: false, discarded: null, weapon: existing };
    }

    const newWeapon = new Weapon(weaponDef);

    if (this.weapons.length < 2) {
      // Add as second weapon in slot 1
      this.weapons.push(newWeapon);
      this.activeWeaponIndex = this.weapons.length - 1;
      return { added: true, discarded: null, weapon: newWeapon };
    } else {
      // Already has 2 weapons: the currently active weapon in hand is discarded!
      const discardedWeapon = this.weapons[this.activeWeaponIndex];
      this.weapons[this.activeWeaponIndex] = newWeapon;
      return { added: true, discarded: discardedWeapon, weapon: newWeapon };
    }
  }

  discardActiveWeapon(audio, particles) {
    const discarded = this.weapons.splice(this.activeWeaponIndex, 1)[0];
    if (this.weapons.length === 0) {
      this.weapons = [new Weapon(WeaponTypes.PISTOL)];
    }
    this.activeWeaponIndex = Math.max(0, this.weapons.length - 1);
    if (audio) audio.playReload();
    if (particles) particles.createHitSparks(this.x, this.y, '#94a3b8');
    return discarded;
  }

  triggerDodgeRoll(moveDir, audio, particles) {
    if (this.isRolling || this.cooldownTimer > 0) return false;

    this.isRolling = true;
    this.isInvulnerable = true;
    this.rollTimer = this.rollDuration;

    // If moving, roll in movement direction; otherwise roll towards aim
    if (moveDir.dx !== 0 || moveDir.dy !== 0) {
      this.rollDirX = moveDir.dx;
      this.rollDirY = moveDir.dy;
    } else {
      this.rollDirX = Math.cos(this.aimAngle);
      this.rollDirY = Math.sin(this.aimAngle);
    }

    if (audio) audio.playDodgeRoll();
    if (particles) particles.createDust(this.x, this.y, 8);

    return true;
  }

  triggerBlank(audio, particles, camera, allBullets, enemies) {
    if (this.blanks <= 0) return false;

    this.blanks--;
    if (audio) audio.playBlank();
    if (camera) camera.addTrauma(0.7);

    if (particles) {
      particles.createShockwave(this.x, this.y, 700, '#00ddff', 1200);
      particles.createExplosion(this.x, this.y, 40);
    }

    // Destroy all active enemy bullets
    for (const b of allBullets) {
      if (!b.isPlayer) {
        b.markedForDeletion = true;
        if (particles) particles.createHitSparks(b.x, b.y, '#00ddff');
      }
    }

    // Push enemies back and deal damage
    for (const enemy of enemies) {
      if (!enemy.isDead) {
        enemy.takeDamage(25);
        const edx = enemy.x - this.x;
        const edy = enemy.y - this.y;
        const dist = Math.hypot(edx, edy) || 1;
        enemy.vx += (edx / dist) * 450;
        enemy.vy += (edy / dist) * 450;
      }
    }

    return true;
  }

  takeDamage(amount) {
    if (this.isDead || this.isInvulnerable || this.isRolling) return 0;

    super.takeDamage(amount);
    this.isInvulnerable = true;
    this.invulnerableTimer = 0.85; // Hurt i-frames

    return amount;
  }

  update(dt, input, audio, particles, camera) {
    // 1. Update i-frames and cooldowns
    if (this.cooldownTimer > 0) {
      this.cooldownTimer -= dt;
    }

    if (this.invulnerableTimer > 0) {
      this.invulnerableTimer -= dt;
      if (this.invulnerableTimer <= 0 && !this.isRolling) {
        this.isInvulnerable = false;
      }
    }

    // 2. Handle Dodge Roll
    if (this.isRolling) {
      this.rollTimer -= dt;
      this.vx = this.rollDirX * this.rollSpeed;
      this.vy = this.rollDirY * this.rollSpeed;

      // Spawn dust trail
      if (particles && Math.random() < 0.4) {
        particles.createDust(this.x, this.y, 2);
      }

      if (this.rollTimer <= 0) {
        this.isRolling = false;
        this.isInvulnerable = false;
        this.cooldownTimer = this.rollCooldown;
        if (particles) particles.createDust(this.x, this.y, 6);
      }
    } else {
      // Normal WASD movement
      const move = input.getMovementVector();
      this.vx = move.dx * this.speed;
      this.vy = move.dy * this.speed;

      // Dodge Roll Trigger
      if (input.mouse.justRightDown) {
        this.triggerDodgeRoll(move, audio, particles);
      }
    }

    // 3. Aim angle
    this.aimAngle = Math.atan2(input.mouse.worldY - this.y, input.mouse.worldX - this.x);

    // 4. Weapon Switching (1, 2, or Mouse Wheel)
    if (input.mouse.justSwitchSlot1) {
      this.selectWeapon(0, audio);
    } else if (input.mouse.justSwitchSlot2) {
      if (this.weapons.length > 1) {
        this.selectWeapon(1, audio);
      }
    } else if (input.mouse.justNextWeapon || input.mouse.justPrevWeapon) {
      this.cycleWeapon(audio);
    }

    // 5. Update Active Weapon
    this.activeWeapon.update(dt, audio);

    // Reload trigger
    if (input.mouse.justReloadDown) {
      this.activeWeapon.startReload(audio);
    }

    // Auto-discard if weapon ammo is completely exhausted
    const curW = this.activeWeapon;
    if (curW && curW.def.maxAmmo !== Infinity && curW.currentClip <= 0 && curW.reserveAmmo <= 0 && !curW.isReloading) {
      this.lastDiscardedWeapon = this.discardActiveWeapon(audio, particles);
    } else {
      this.lastDiscardedWeapon = null;
    }

    // 6. Update physics
    this.updatePhysics(dt);
  }

  render(ctx) {
    ctx.save();
    ctx.translate(this.x, this.y);

    // Flashing effect when hurt / invulnerable
    if (this.isInvulnerable && !this.isRolling && Math.floor(Date.now() / 60) % 2 === 0) {
      ctx.globalAlpha = 0.4;
    }

    // Floor Shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
    ctx.beginPath();
    ctx.ellipse(0, 14, 16, 8, 0, 0, Math.PI * 2);
    ctx.fill();

    // Dodge Roll Rotation
    if (this.isRolling) {
      const progress = 1 - (this.rollTimer / this.rollDuration);
      const rollAngle = progress * Math.PI * 2 * (this.rollDirX >= 0 ? 1 : -1);
      ctx.rotate(rollAngle);
    }

    // Body (Enter the Gungeon style explorer in cloak)
    const isFacingLeft = Math.cos(this.aimAngle) < 0;
    const skin = this.skinData;

    // Cape / Trenchcoat
    ctx.fillStyle = skin.capeColor;
    ctx.beginPath();
    ctx.ellipse(isFacingLeft ? 4 : -4, 4, 13, 15, 0, 0, Math.PI * 2);
    ctx.fill();

    // Torso / Tunic
    ctx.fillStyle = skin.bodyColor;
    ctx.beginPath();
    ctx.arc(0, 0, 11, 0, Math.PI * 2);
    ctx.fill();

    // Bandolier strap & Gold buckle
    ctx.strokeStyle = '#6d4c2b';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(-8, -8);
    ctx.lineTo(8, 8);
    ctx.stroke();

    ctx.fillStyle = '#ffcc00';
    ctx.fillRect(-2, -2, 4, 4);

    // Head / Helmet
    ctx.fillStyle = skin.helmetColor;
    ctx.beginPath();
    ctx.arc(0, -9, 8, 0, Math.PI * 2);
    ctx.fill();

    // Eyes / Visor
    ctx.fillStyle = '#ffffff';
    const eyeOffset = isFacingLeft ? -3 : 3;
    ctx.fillRect(eyeOffset - 1, -11, 3, 3);
    ctx.fillRect(eyeOffset + (isFacingLeft ? -4 : 4) - 1, -11, 3, 3);

    // Render Held Weapon (if not rolling)
    if (!this.isRolling) {
      ctx.save();
      const gunDistance = 14;
      const gunX = Math.cos(this.aimAngle) * gunDistance;
      const gunY = Math.sin(this.aimAngle) * gunDistance;

      ctx.translate(gunX, gunY);
      ctx.rotate(this.aimAngle);

      if (isFacingLeft) {
        ctx.scale(1, -1); // Flip gun when aiming left
      }

      // Gun Kickback recoil
      const kick = this.activeWeapon.kickback;
      ctx.translate(-kick, 0);

      // Gun Sprite rendering
      this.renderGun(ctx, this.activeWeapon.id);

      ctx.restore();
    }

    // Floating Reload Gauge
    if (this.activeWeapon.isReloading) {
      const pct = this.activeWeapon.getReloadProgress();
      ctx.save();
      ctx.translate(0, -28);

      // Circular reload ring
      ctx.beginPath();
      ctx.arc(0, 0, 10, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(0, 0, 0, 0.5)';
      ctx.lineWidth = 3;
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(0, 0, 10, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * pct);
      ctx.strokeStyle = '#ffcc00';
      ctx.lineWidth = 3;
      ctx.stroke();
      ctx.restore();
    }

    ctx.restore();
  }

  renderGun(ctx, weaponId) {
    ctx.fillStyle = '#222';
    switch (weaponId) {
      case 'shotgun':
        ctx.fillStyle = '#4a3525';
        ctx.fillRect(-6, -3, 8, 6); // wooden stock
        ctx.fillStyle = '#777';
        ctx.fillRect(2, -3, 14, 5); // double barrel
        break;
      case 'ak47':
        ctx.fillStyle = '#7a4f28';
        ctx.fillRect(-7, -2, 7, 5); // stock
        ctx.fillStyle = '#333';
        ctx.fillRect(0, -3, 16, 5); // receiver/barrel
        ctx.fillStyle = '#222';
        ctx.fillRect(2, 2, 4, 6); // curved magazine
        break;
      case 'sniper':
        ctx.fillStyle = '#111';
        ctx.fillRect(-6, -2, 24, 4); // long barrel
        ctx.fillStyle = '#00ddff';
        ctx.fillRect(2, -6, 8, 3); // scope
        break;
      case 'rpg':
        ctx.fillStyle = '#2a4d2a';
        ctx.fillRect(-8, -4, 22, 8); // olive green tube
        ctx.fillStyle = '#ff3300';
        ctx.beginPath();
        ctx.moveTo(14, 0);
        ctx.lineTo(8, -5);
        ctx.lineTo(8, 5);
        ctx.fill();
        break;
      case 'plasma':
        ctx.fillStyle = '#1a2a40';
        ctx.fillRect(-4, -4, 14, 7);
        ctx.fillStyle = '#00ffcc';
        ctx.shadowBlur = 6;
        ctx.shadowColor = '#00ffcc';
        ctx.fillRect(2, -2, 8, 3); // glowing core
        break;
      case 'pistol':
      default:
        ctx.fillStyle = '#333';
        ctx.fillRect(-2, -3, 9, 6);
        ctx.fillStyle = '#111';
        ctx.fillRect(-3, 1, 4, 4);
        break;
    }
  }
}
