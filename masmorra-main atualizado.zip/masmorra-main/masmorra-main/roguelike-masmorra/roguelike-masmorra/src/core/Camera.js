// Camera system with smooth following, mouse look-ahead, and screen shake
export class Camera {
  constructor(viewportWidth, viewportHeight) {
    this.x = 0;
    this.y = 0;
    this.viewportWidth = viewportWidth;
    this.viewportHeight = viewportHeight;

    this.targetX = 0;
    this.targetY = 0;

    // Screen Shake (Trauma model)
    this.trauma = 0; // 0 to 1
    this.maxShakeOffset = 16;
    this.shakeOffsetX = 0;
    this.shakeOffsetY = 0;
  }

  resize(width, height) {
    this.viewportWidth = width;
    this.viewportHeight = height;
  }

  addTrauma(amount) {
    this.trauma = Math.min(1.0, this.trauma + amount);
  }

  update(player, mouseScreenX, mouseScreenY, dt) {
    if (!player) return;

    // Slight look-ahead toward mouse cursor
    const mouseOffsetX = (mouseScreenX - this.viewportWidth / 2) * 0.25;
    const mouseOffsetY = (mouseScreenY - this.viewportHeight / 2) * 0.25;

    // Target center is player center + mouse look-ahead - half viewport
    const desiredX = player.x + mouseOffsetX - this.viewportWidth / 2;
    const desiredY = player.y + mouseOffsetY - this.viewportHeight / 2;

    // Smooth lerp
    const lerpSpeed = 8.0;
    this.x += (desiredX - this.x) * Math.min(1.0, lerpSpeed * dt);
    this.y += (desiredY - this.y) * Math.min(1.0, lerpSpeed * dt);

    // Apply Screen Shake
    if (this.trauma > 0) {
      const shakePower = Math.pow(this.trauma, 2);
      this.shakeOffsetX = (Math.random() * 2 - 1) * this.maxShakeOffset * shakePower;
      this.shakeOffsetY = (Math.random() * 2 - 1) * this.maxShakeOffset * shakePower;

      // Decay trauma
      this.trauma = Math.max(0, this.trauma - dt * 1.8);
    } else {
      this.shakeOffsetX = 0;
      this.shakeOffsetY = 0;
    }
  }

  // Returns rendering offset including shake
  getRenderOffset() {
    return {
      x: Math.round(this.x + this.shakeOffsetX),
      y: Math.round(this.y + this.shakeOffsetY)
    };
  }
}
