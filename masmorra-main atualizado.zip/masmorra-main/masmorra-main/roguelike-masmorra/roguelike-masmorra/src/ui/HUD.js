// HUD Manager for Hearts, Ammo, Blanks, Boss Health Bar, and Interaction prompts
export class HUD {
  constructor() {
    this.healthBarEl = document.getElementById('health-bar');
    this.blanksTextEl = document.getElementById('blanks-text');
    this.keysTextEl = document.getElementById('keys-text');
    this.coinsTextEl = document.getElementById('coins-text');

    this.floorNumberEl = document.getElementById('floor-number');
    this.floorNameEl = document.getElementById('floor-name');

    this.weaponEmojiEl = document.getElementById('weapon-emoji');
    this.weaponNameEl = document.getElementById('weapon-name');
    this.clipAmmoEl = document.getElementById('clip-ammo');
    this.reserveAmmoEl = document.getElementById('reserve-ammo');
    this.reloadIndicatorEl = document.getElementById('reload-indicator');
    this.dodgeCooldownFillEl = document.getElementById('dodge-cooldown-fill');

    this.bossHudEl = document.getElementById('boss-hud');
    this.bossNameEl = document.getElementById('boss-name');
    this.bossSubtitleEl = document.getElementById('boss-subtitle');
    this.bossHealthFillEl = document.getElementById('boss-health-fill');

    this.interactionPromptEl = document.getElementById('interaction-prompt');
    this.interactionTextEl = document.getElementById('interaction-text');
    this.toastEl = document.getElementById('game-toast');
  }

  update(player, floorNumber, floorName, activeBoss) {
    if (!player) return;

    // 1. Health Bar (Hearts: 2 HP per heart container)
    const maxHearts = Math.ceil(player.maxHealth / 2);
    let heartsHtml = '';
    for (let i = 0; i < maxHearts; i++) {
      const heartHp = player.health - i * 2;
      if (heartHp >= 2) {
        heartsHtml += '<span class="heart-icon" title="Coração Cheio">❤️</span>';
      } else if (heartHp === 1) {
        heartsHtml += '<span class="heart-icon" title="Meio Coração">💔</span>';
      } else {
        heartsHtml += '<span class="heart-icon empty" style="opacity: 0.25; filter: grayscale(1);" title="Vazio">🖤</span>';
      }
    }
    if (this.healthBarEl.innerHTML !== heartsHtml) {
      this.healthBarEl.innerHTML = heartsHtml;
    }

    // 2. Blanks, Keys, Coins
    this.blanksTextEl.textContent = `x${player.blanks}`;
    this.keysTextEl.textContent = `x${player.keys}`;
    this.coinsTextEl.textContent = `${player.coins}`;

    // 3. Floor Info
    this.floorNumberEl.textContent = `ANDAR ${floorNumber}`;
    this.floorNameEl.textContent = floorName;

    // 4. Weapon & Ammo
    const weapon = player.activeWeapon;
    this.weaponEmojiEl.textContent = weapon.emoji;
    this.weaponNameEl.textContent = weapon.name;
    this.clipAmmoEl.textContent = weapon.currentClip;
    this.reserveAmmoEl.textContent = weapon.def.maxAmmo === Infinity ? '∞' : weapon.reserveAmmo;

    // Reload indicator
    if (weapon.isReloading) {
      this.reloadIndicatorEl.classList.remove('hidden');
      const pct = weapon.getReloadProgress() * 100;
      this.reloadIndicatorEl.style.setProperty('--reload-pct', `${pct}%`);
    } else {
      this.reloadIndicatorEl.classList.add('hidden');
    }

    // Dodge Roll Cooldown Bar
    if (player.cooldownTimer > 0) {
      const fillPct = (1 - (player.cooldownTimer / player.rollCooldown)) * 100;
      this.dodgeCooldownFillEl.style.width = `${fillPct}%`;
    } else {
      this.dodgeCooldownFillEl.style.width = '100%';
    }

    // 5. Boss Bar
    if (activeBoss && !activeBoss.isDead) {
      this.bossHudEl.classList.remove('hidden');
      this.bossNameEl.textContent = activeBoss.name.toUpperCase();
      this.bossSubtitleEl.textContent = activeBoss.subtitle.toUpperCase();
      const bossHpPct = Math.max(0, (activeBoss.health / activeBoss.maxHealth) * 100);
      this.bossHealthFillEl.style.width = `${bossHpPct}%`;
    } else {
      this.bossHudEl.classList.add('hidden');
    }
  }

  showInteractionPrompt(text) {
    this.interactionTextEl.textContent = text;
    this.interactionPromptEl.classList.remove('hidden');
  }

  hideInteractionPrompt() {
    this.interactionPromptEl.classList.add('hidden');
  }

  showToast(text) {
    this.toastEl.textContent = text;
    this.toastEl.classList.remove('hidden');
    // Re-trigger CSS animation
    this.toastEl.style.animation = 'none';
    void this.toastEl.offsetWidth;
    this.toastEl.style.animation = 'toastFade 2s forwards';

    setTimeout(() => {
      this.toastEl.classList.add('hidden');
    }, 2000);
  }
}
