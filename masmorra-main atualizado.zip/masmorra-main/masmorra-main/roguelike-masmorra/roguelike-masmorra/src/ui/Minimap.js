// Minimap with dynamic room discovery, fog of war, and special room markers
import { RoomType } from '../dungeon/Room.js';

export class Minimap {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.blinkTimer = 0;
  }

  update(dt) {
    this.blinkTimer += dt * 5;
  }

  render(dungeon, currentRoom, player) {
    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;

    ctx.clearRect(0, 0, w, h);

    if (!dungeon || !dungeon.rooms) return;

    // 1. Calculate grid boundaries
    let minGX = Infinity, maxGX = -Infinity;
    let minGY = Infinity, maxGY = -Infinity;

    dungeon.rooms.forEach(r => {
      minGX = Math.min(minGX, r.gridX);
      maxGX = Math.max(maxGX, r.gridX);
      minGY = Math.min(minGY, r.gridY);
      maxGY = Math.max(maxGY, r.gridY);
    });

    const gridSpanX = Math.max(1, maxGX - minGX + 1);
    const gridSpanY = Math.max(1, maxGY - minGY + 1);

    const roomSize = Math.min(22, Math.floor(Math.min(w / (gridSpanX + 1), h / (gridSpanY + 1)) * 0.75));
    const spacing = roomSize + 8;

    const centerX = w / 2 - ((minGX + maxGX) / 2) * spacing;
    const centerY = h / 2 - ((minGY + maxGY) / 2) * spacing;

    // 2. Render corridor connections for visited rooms
    dungeon.rooms.forEach(room => {
      if (!room.visited) return;
      const rx = centerX + room.gridX * spacing;
      const ry = centerY + room.gridY * spacing;

      if (room.neighbors['E'] && (room.neighbors['E'].visited || room.visited)) {
        const nextX = centerX + room.neighbors['E'].gridX * spacing;
        ctx.strokeStyle = '#444c66';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(rx, ry);
        ctx.lineTo(nextX, ry);
        ctx.stroke();
      }

      if (room.neighbors['S'] && (room.neighbors['S'].visited || room.visited)) {
        const nextY = centerY + room.neighbors['S'].gridY * spacing;
        ctx.strokeStyle = '#444c66';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(rx, ry);
        ctx.lineTo(rx, nextY);
        ctx.stroke();
      }
    });

    // 3. Render rooms
    dungeon.rooms.forEach(room => {
      const rx = centerX + room.gridX * spacing;
      const ry = centerY + room.gridY * spacing;

      const isCurrent = (room === currentRoom);

      // Check if room is visible (visited OR adjacent to visited)
      const isAdjacentToVisited = Object.values(room.neighbors).some(n => n.visited);

      if (room.visited) {
        // Explored Room Fill
        ctx.fillStyle = isCurrent ? '#2a3b5c' : '#171b26';
        ctx.fillRect(rx - roomSize / 2, ry - roomSize / 2, roomSize, roomSize);

        // Border
        ctx.strokeStyle = isCurrent ? '#00ddff' : (room.cleared ? '#4b5563' : '#ff3344');
        ctx.lineWidth = isCurrent ? 2 : 1.5;
        ctx.strokeRect(rx - roomSize / 2, ry - roomSize / 2, roomSize, roomSize);

        // Special room icon
        if (room.type === RoomType.BOSS) {
          ctx.font = '10px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('☠️', rx, ry);
        } else if (room.type === RoomType.CHEST) {
          ctx.font = '10px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('📦', rx, ry);
        }
      } else if (isAdjacentToVisited) {
        // Fog of War: Unvisited adjacent room (dashed outline)
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
        ctx.lineWidth = 1;
        ctx.setLineDash([2, 2]);
        ctx.strokeRect(rx - roomSize / 2, ry - roomSize / 2, roomSize, roomSize);
        ctx.setLineDash([]);
      }

      // 4. Render Player Marker inside current room
      if (isCurrent && player) {
        const relX = (player.x - room.x) / room.width;
        const relY = (player.y - room.y) / room.height;
        const px = (rx - roomSize / 2) + relX * roomSize;
        const py = (ry - roomSize / 2) + relY * roomSize;

        const blink = Math.sin(this.blinkTimer) > 0;
        ctx.fillStyle = blink ? '#ffffff' : '#00ddff';
        ctx.beginPath();
        ctx.arc(px, py, 3, 0, Math.PI * 2);
        ctx.fill();
      }
    });
  }
}
